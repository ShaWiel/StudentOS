-- StudentOS V7.1 - Supabase/Postgres schema
-- Voer dit uit in de Supabase SQL Editor.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Student',
  age integer check (age is null or (age between 3 and 120)),
  stage text not null default 'volwassene',
  primary_goal text,
  subjects text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  tasks jsonb not null default '[]'::jsonb,
  goals jsonb not null default '[]'::jsonb,
  activity jsonb not null default '[]'::jsonb,
  learned jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.user_state enable row level security;

-- Each authenticated user may only read/write their own profile.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
on public.profiles for select
to authenticated
using ((select auth.uid()) = id);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
on public.profiles for insert
to authenticated
with check ((select auth.uid()) = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

-- Snapshot state.
drop policy if exists "state_select_own" on public.user_state;
create policy "state_select_own"
on public.user_state for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "state_insert_own" on public.user_state;
create policy "state_insert_own"
on public.user_state for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "state_update_own" on public.user_state;
create policy "state_update_own"
on public.user_state for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Optional production-grade normalized tables for later migration.
create table if not exists public.study_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  subject text,
  due_date date,
  planned_minutes integer check (planned_minutes is null or planned_minutes between 1 and 1440),
  priority text not null default 'normaal',
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.learning_goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  why text,
  target_date date,
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.study_tasks enable row level security;
alter table public.learning_goals enable row level security;

drop policy if exists "tasks_own_all" on public.study_tasks;
create policy "tasks_own_all"
on public.study_tasks
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "goals_own_all" on public.learning_goals;
create policy "goals_own_all"
on public.learning_goals
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);


-- V10 projects
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  project_type text not null,
  name text not null,
  project_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.projects enable row level security;

drop policy if exists "projects_own_all" on public.projects;
create policy "projects_own_all"
on public.projects
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);


-- V11 project collaboration/versioning
create table if not exists public.project_versions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  version_name text,
  project_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.project_comments (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.project_share_links (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.project_versions enable row level security;
alter table public.project_comments enable row level security;
alter table public.project_share_links enable row level security;

drop policy if exists "project_versions_own_all" on public.project_versions;
create policy "project_versions_own_all"
on public.project_versions
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "project_comments_own_all" on public.project_comments;
create policy "project_comments_own_all"
on public.project_comments
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "project_share_links_own_all" on public.project_share_links;
create policy "project_share_links_own_all"
on public.project_share_links
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);


-- V12 education + adaptive learning

create table if not exists public.learning_mastery (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stage text not null,
  subject text not null,
  topic text not null,
  mastery_score integer not null default 0 check (mastery_score between 0 and 100),
  attempts integer not null default 0,
  correct_attempts integer not null default 0,
  last_practiced_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(user_id, stage, subject, topic)
);

create table if not exists public.practice_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stage text not null,
  subject text not null,
  topic text not null,
  difficulty integer,
  question_id text,
  correct boolean not null,
  created_at timestamptz not null default now()
);

create table if not exists public.education_resources (
  id uuid primary key default gen_random_uuid(),
  stage text not null,
  subject text not null,
  topic text,
  title text not null,
  resource_type text,
  source_url text,
  is_official boolean not null default false,
  last_verified_at date
);

create table if not exists public.school_directory (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  region text,
  place text,
  levels text[] not null default '{}',
  streams text[] not null default '{}',
  programs text[] not null default '{}',
  official_source_url text,
  last_verified_at date,
  is_active boolean not null default true
);

alter table public.learning_mastery enable row level security;
alter table public.practice_attempts enable row level security;

drop policy if exists "mastery_own_all" on public.learning_mastery;
create policy "mastery_own_all"
on public.learning_mastery
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "attempts_own_all" on public.practice_attempts;
create policy "attempts_own_all"
on public.practice_attempts
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- education_resources and school_directory are intended as read-only reference data.
alter table public.education_resources enable row level security;
alter table public.school_directory enable row level security;

drop policy if exists "education_resources_read" on public.education_resources;
create policy "education_resources_read"
on public.education_resources
for select
to authenticated
using (true);

drop policy if exists "school_directory_read" on public.school_directory;
create policy "school_directory_read"
on public.school_directory
for select
to authenticated
using (is_active = true);


-- V16 AI usage quota
create table if not exists public.ai_usage_daily (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null default current_date,
  text_requests integer not null default 0,
  image_requests integer not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_id, usage_date)
);
alter table public.ai_usage_daily enable row level security;
drop policy if exists "ai_usage_own_read" on public.ai_usage_daily;
create policy "ai_usage_own_read" on public.ai_usage_daily for select to authenticated using ((select auth.uid())=user_id);

create or replace function public.consume_ai_quota(p_kind text)
returns table(allowed boolean, remaining integer, kind text)
language plpgsql
security definer
set search_path=public
as $$
declare
  uid uuid := auth.uid();
  t integer;
  i integer;
  text_limit constant integer := 100;
  image_limit constant integer := 8;
begin
  if uid is null then
    return query select false,0,p_kind;
    return;
  end if;
  insert into public.ai_usage_daily(user_id,usage_date) values(uid,current_date)
  on conflict(user_id,usage_date) do nothing;
  select text_requests,image_requests into t,i from public.ai_usage_daily where user_id=uid and usage_date=current_date for update;
  if p_kind='image' then
    if i>=image_limit then return query select false,0,'image'::text; return; end if;
    update public.ai_usage_daily set image_requests=image_requests+1,updated_at=now() where user_id=uid and usage_date=current_date returning image_requests into i;
    return query select true,greatest(image_limit-i,0),'image'::text;
  else
    if t>=text_limit then return query select false,0,'text'::text; return; end if;
    update public.ai_usage_daily set text_requests=text_requests+1,updated_at=now() where user_id=uid and usage_date=current_date returning text_requests into t;
    return query select true,greatest(text_limit-t,0),'text'::text;
  end if;
end;
$$;
revoke all on function public.consume_ai_quota(text) from public;
grant execute on function public.consume_ai_quota(text) to authenticated;

create index if not exists projects_user_updated_idx on public.projects(user_id,updated_at desc);
create index if not exists mastery_user_updated_idx on public.learning_mastery(user_id,updated_at desc);
