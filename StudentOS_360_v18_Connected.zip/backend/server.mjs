import "dotenv/config";
import express from "express";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cors from "cors";
import OpenAI from "openai";
import { createClient } from "@supabase/supabase-js";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const ROOT_DIR=path.resolve(__dirname,"..");
const APP_VERSION="16.0.0";
app.set("trust proxy",1);

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map(x => x.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Requests from local file:// pages may arrive with no Origin / "null".
    if (!origin || allowedOrigins.includes(origin) || allowedOrigins.includes("null")) {
      return callback(null, true);
    }
    return callback(new Error("Origin not allowed by StudentOS CORS policy."));
  }
}));
app.use(express.json({ limit: "48kb" }));

app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:false,crossOriginResourcePolicy:false}));
app.use(compression());
app.use((req,res,next)=>{
  req.requestId=crypto.randomUUID();
  res.setHeader("X-Request-ID",req.requestId);
  next();
});
const apiLimiter=rateLimit({windowMs:15*60*1000,limit:300,standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Te veel verzoeken. Probeer het later opnieuw."}});
const guestAiLimiter=rateLimit({windowMs:24*60*60*1000,limit:Number(process.env.GUEST_DAILY_AI_LIMIT||25),standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Daglimiet voor gast-AI bereikt. Log in of probeer morgen opnieuw."}});
const guestImageLimiter=rateLimit({windowMs:24*60*60*1000,limit:Number(process.env.GUEST_DAILY_IMAGE_LIMIT||5),standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Daglimiet voor gast-afbeeldingen bereikt."}});
app.use("/api",apiLimiter);


const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const supabase = (process.env.SUPABASE_URL && process.env.SUPABASE_PUBLISHABLE_KEY)
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

function cleanString(value, max = 2000) {
  return String(value ?? "").trim().slice(0, max);
}

function ageBand(age, stage) {
  const a = Number(age);
  if (stage === "peuter" || a <= 6) return "early_childhood";
  if (stage === "basis" || a <= 12) return "child";
  if (stage === "voj" || stage === "vos" || a <= 17) return "teen";
  if (stage === "senior") return "senior";
  return "adult";
}

async function authenticateOptional(req) {
  if (!supabase) return null;
  const auth = req.get("authorization") || "";
  if (!auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7);
  const { data, error } = await supabase.auth.getUser(token);
  if (error) return null;
  return data.user || null;
}



function getBearer(req){
  const auth=req.get("authorization")||"";
  return auth.startsWith("Bearer ")?auth.slice(7):"";
}
function safetyIdentifier(req,user){
  const raw=user?.id||`${req.ip}|${req.get("user-agent")||"guest"}`;
  return "sos_"+crypto.createHash("sha256").update(raw).digest("hex").slice(0,32);
}
async function moderateText(text){
  if(!openai||!text)return {flagged:false};
  const result=await openai.moderations.create({model:"omni-moderation-latest",input:text});
  return {flagged:Boolean(result.results?.[0]?.flagged),categories:result.results?.[0]?.categories||{}};
}
async function consumeCloudQuota(req,kind){
  const token=getBearer(req);
  if(!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_PUBLISHABLE_KEY)return null;
  const r=await fetch(`${process.env.SUPABASE_URL}/rest/v1/rpc/consume_ai_quota`,{
    method:"POST",
    headers:{"Content-Type":"application/json","apikey":process.env.SUPABASE_PUBLISHABLE_KEY,"Authorization":`Bearer ${token}`},
    body:JSON.stringify({p_kind:kind})
  });
  if(!r.ok)return null;
  const data=await r.json();
  return Array.isArray(data)?data[0]:data;
}
async function enforceAiAccess(req,res,next,kind="text"){
  try{
    const user=await authenticateOptional(req);
    req.studentosUser=user;
    req.safetyIdentifier=safetyIdentifier(req,user);
    if(user){
      const quota=await consumeCloudQuota(req,kind);
      if(quota&&quota.allowed===false)return res.status(429).json({message:"Je gratis daglimiet is bereikt.",remaining:quota.remaining??0});
      req.quota=quota;
      return next();
    }
    return (kind==="image"?guestImageLimiter:guestAiLimiter)(req,res,next);
  }catch(err){return next(err);}
}
async function safeInputOrReject(req,res,text){
  try{
    const mod=await moderateText(text);
    if(mod.flagged){res.status(400).json({message:"Deze invoer kan niet via StudentOS AI worden verwerkt. Probeer de vraag veiliger of educatiever te formuleren."});return false;}
    return true;
  }catch(err){console.warn("Moderation unavailable",err);return true;}
}


function tutorInstructions({ profile, explanationLevel, learningStyle }) {
  const age = Number(profile.age) || null;
  const stage = cleanString(profile.stage, 40) || "volwassene";
  const band = ageBand(age, stage);
  const goal = cleanString(profile.goal, 120);
  const subjects = cleanString(profile.subjects, 300);

  return `
You are StudentOS Tutor, a Dutch-language educational tutor designed for users in Suriname across many life stages.

USER CONTEXT
- Display name: ${cleanString(profile.name, 60) || "gebruiker"}
- Age: ${age ?? "unknown"}
- Learning stage: ${stage}
- Age band: ${band}
- Main goal: ${goal || "general learning"}
- Relevant subjects: ${subjects || "not specified"}
- Requested explanation depth: ${cleanString(explanationLevel, 30)}
- Preferred learning style: ${cleanString(learningStyle, 30)}

CORE TEACHING RULES
1. Respond in clear Dutch unless the learner explicitly asks for another language.
2. Adapt vocabulary, sentence length, examples, and conceptual depth to the learner's age/stage.
3. Teach; do not merely dump an answer. Explain the reasoning at an appropriate level, then give a small check-for-understanding or next step when useful.
4. When the user asks for schoolwork, help them learn how to do it. Do not falsely claim their work is factually verified if it is not.
5. If information is uncertain or depends on a school/institution's current rules, say that it must be verified from the official institution.
6. Do not shame mistakes. Correct them clearly and concretely.
7. For very young learners, keep answers short, concrete, playful, and easy to read with an adult.
8. For senior users, prioritize simple step-by-step practical instructions and avoid jargon.
9. Never ask the user to reveal passwords, verification codes, exact home address, banking credentials, or other unnecessary sensitive information.
10. For dangerous, illegal, self-harm, sexual, or other age-inappropriate requests, follow platform safety rules and redirect toward safe educational help.
11. Do not pretend to have completed real-world actions (submitting forms, sending emails, enrolling at school, paying bills) unless the application actually performed them.
12. Avoid overlong introductions. Start with the explanation.

OUTPUT STYLE
- Use plain text with short headings where useful.
- Prefer concise paragraphs and numbered steps.
- If learning_style is "quiz", end with 2–3 short questions but do not reveal answers immediately.
- If learning_style is "voorbeeld", include at least one concrete example.
- If learning_style is "stappen", use an explicit step-by-step sequence.
`.trim();
}

app.get("/api/public-config",(_req,res)=>{
  res.setHeader("Cache-Control","no-store");
  res.json({
    SUPABASE_URL:process.env.SUPABASE_URL||"",
    SUPABASE_PUBLISHABLE_KEY:process.env.SUPABASE_PUBLISHABLE_KEY||"",
    API_BASE_URL:"",
    cloud_enabled:Boolean(process.env.SUPABASE_URL&&process.env.SUPABASE_PUBLISHABLE_KEY)
  });
});

app.get("/api/health", (_req, res) => {
  res.setHeader("Cache-Control","no-store");
  res.json({
    ok:true,version:`V${APP_VERSION}`,uptime_seconds:Math.round(process.uptime()),
    ai_configured:Boolean(openai),auth_verification_configured:Boolean(supabase),
    model:process.env.OPENAI_MODEL||"gpt-5.6",environment:process.env.NODE_ENV||"development"
  });
});

app.post("/api/tutor", (req,res,next)=>enforceAiAccess(req,res,next,"text"), async (req, res) => {
  try {
    const question = cleanString(req.body?.question, 5000);
    if (!question) return res.status(400).json({ message: "Stel eerst een vraag." });
    if (!openai) return res.status(503).json({ message: "OPENAI_API_KEY is nog niet ingesteld op de server." });

    const profile = req.body?.profile || {};
    if(!(await safeInputOrReject(req,res,question)))return;
    const user = req.studentosUser || null;

    const instructions = tutorInstructions({
      profile,
      explanationLevel: req.body?.explanation_level || "normaal",
      learningStyle: req.body?.learning_style || "stappen"
    });

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      instructions,
      input: question,
      safety_identifier:req.safetyIdentifier
    });

    const answer = response.output_text?.trim();
    if (!answer) return res.status(502).json({ message: "De AI leverde geen tekstantwoord." });

    // Tiny topic label for progress tracking. We avoid a second model call.
    const topic = question
      .replace(/[?.!,]/g, " ")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 5)
      .join(" ")
      .slice(0, 80);

    res.json({
      ok: true,
      answer,
      topic,
      authenticated: Boolean(user)
    });
  } catch (error) {
    console.error("Tutor error:", error);
    res.status(500).json({
      message: "De Tutor kon deze vraag niet verwerken.",
      detail: process.env.NODE_ENV === "development" ? String(error?.message || error) : undefined
    });
  }
});



/* ===========================
   STUDENTOS V8 — STUDIO API
   =========================== */

function uniqueCitations(response){
  const out=[];
  const seen=new Set();
  for(const item of response.output || []){
    if(item.type !== "message") continue;
    for(const content of item.content || []){
      for(const ann of content.annotations || []){
        if(ann.type === "url_citation" && ann.url && !seen.has(ann.url)){
          seen.add(ann.url);
          out.push({ title: ann.title || ann.url, url: ann.url });
        }
      }
    }
  }
  return out;
}

function studioAgeRules(profile={}){
  const age=Number(profile.age)||null;
  const stage=cleanString(profile.stage,40)||"volwassene";
  return `
The user may be a minor. Age: ${age ?? "unknown"}, stage: ${stage}.
Adapt content to age and learning level.
For minors, keep content age-appropriate, educational, privacy-conscious and safe.
Do not request unnecessary personal information.
`.trim();
}

function reasoningNote(mode){
  if(mode==="deep") return "Think carefully and provide a rigorous answer, but do not expose private chain-of-thought. Give concise reasoning summaries when useful.";
  if(mode==="balanced") return "Balance speed and depth. Check assumptions before answering.";
  return "Answer efficiently and clearly.";
}

async function runStudioText({prompt,instructions,useWeb=false,mode="balanced",safetyIdentifier=""}){
  if(!openai) throw new Error("OPENAI_API_KEY is niet ingesteld.");
  const response=await openai.responses.create({
    model:process.env.OPENAI_MODEL || "gpt-5.6",
    instructions:`${instructions}\n\n${reasoningNote(mode)}`,
    ...(useWeb ? {tools:[{type:"web_search"}]} : {}),
    input:prompt,
    ...(safetyIdentifier?{safety_identifier:safetyIdentifier}:{})
  });
  return {
    answer:response.output_text?.trim() || "",
    citations:uniqueCitations(response)
  };
}

app.post("/api/studio/chat",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,8000);
    if(!prompt)return res.status(400).json({message:"Typ eerst een vraag."});
    const profile=req.body?.profile||{};
    const verify=Boolean(req.body?.verify_web);
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      prompt,
      useWeb:verify,
      safetyIdentifier:req.safetyIdentifier,
      mode:req.body?.mode||"balanced",
      instructions:`
You are StudentOS Studio AI, a versatile Dutch-language assistant.
Answer accurately, clearly and directly.
If web search is enabled, use it whenever freshness or factual verification matters.
Do not invent sources, statistics or current facts.
Separate known facts from estimates or opinions.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Ask AI kon de vraag niet verwerken."});
  }
});

app.post("/api/studio/research",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,8000);
    if(!prompt)return res.status(400).json({message:"Vul een onderzoeksvraag in."});
    const level=cleanString(req.body?.level,30);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      prompt,
      useWeb:true,
      safetyIdentifier:req.safetyIdentifier,
      mode:"deep",
      instructions:`
You are the StudentOS Research assistant.
Research the user's question on the live web before answering.
Prioritize primary sources, official institutions, peer-reviewed research, government sources, reputable universities, recognized international organizations, and credible reporting when appropriate.
Cross-check important claims when feasible.
If reliable sources disagree, say so.
Do not fabricate references.
Write in Dutch.
Research depth: ${level}.
Use concise headings and a clear conclusion.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Research kon niet worden uitgevoerd."});
  }
});

app.post("/api/studio/report",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,12000);
    if(!prompt)return res.status(400).json({message:"Vul een onderwerp of opdracht in."});
    const useWeb=Boolean(req.body?.verify_web);
    const type=cleanString(req.body?.type,30);
    const length=cleanString(req.body?.length,30);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      prompt,
      useWeb,
      safetyIdentifier:req.safetyIdentifier,
      mode:"deep",
      instructions:`
You are StudentOS Research-first Writer.
Create a well-structured Dutch ${type} report draft.
Desired length: ${length}.
${useWeb ? `
Before writing, research relevant factual claims on the web.
Use reliable sources and avoid unsupported claims.
If facts cannot be verified, flag them rather than inventing them.
` : `
Do not claim facts were web-verified. Mark uncertain current facts for verification.
`}
Write with natural rhythm, varied sentence structure, appropriate transitions and vocabulary that fits the user's stage.
Do not fabricate personal experiences or pretend the user personally conducted research they did not conduct.
Do not write for the purpose of bypassing plagiarism or AI-detection systems.
Where appropriate, include an introduction, logical body sections, conclusion and a short source note.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Het verslag kon niet worden gemaakt."});
  }
});

app.post("/api/studio/rewrite",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const text=cleanString(req.body?.text,16000);
    if(!text)return res.status(400).json({message:"Plak eerst tekst."});
    const style=cleanString(req.body?.style,40);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,text)))return;
    const result=await runStudioText({
      prompt:text,
      useWeb:false,
      safetyIdentifier:req.safetyIdentifier,
      mode:"balanced",
      instructions:`
You are StudentOS Natural Rewrite.
Rewrite the supplied text in Dutch while preserving its meaning and factual content.
Style: ${style}.
Improve natural flow, sentence variety, clarity and tone.
Avoid repetitive AI-like filler, excessive headings and inflated vocabulary.
Do not invent personal anecdotes, qualifications, sources, events or facts.
Do not claim that the output is undetectable as AI and do not optimize for evading detection systems.
Return only the improved text unless clarification is essential.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"De tekst kon niet worden herschreven."});
  }
});

function parseDeckJson(text){
  const cleaned=String(text||"")
    .replace(/^```json\s*/i,"")
    .replace(/^```\s*/,"")
    .replace(/\s*```$/,"")
    .trim();
  return JSON.parse(cleaned);
}

app.post("/api/studio/presentation",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    const topic=cleanString(req.body?.topic,500);
    if(!topic)return res.status(400).json({message:"Vul een onderwerp in."});
    const audience=cleanString(req.body?.audience,200);
    const count=Math.max(4,Math.min(15,Number(req.body?.slide_count)||8));
    const style=cleanString(req.body?.style,30)||"modern";
    const useWeb=Boolean(req.body?.verify_web);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,topic)))return;

    const response=await openai.responses.create({
      model:process.env.OPENAI_MODEL || "gpt-5.6",
      instructions:`
You are StudentOS Presentation Architect.
Create a compelling slide narrative, not a document broken into slides.
Audience: ${audience || "general"}.
Number of slides: exactly ${count}.
Style: ${style}.
${useWeb ? "Use web search to verify relevant factual claims before constructing the deck. Do not fabricate facts." : "Do not pretend current facts were verified."}
Each slide must have ONE clear message and concise body copy.
Return ONLY valid JSON, no markdown fences:
{
  "title":"...",
  "style":"${style}",
  "slides":[
    {"title":"...","body":"...","layout":"hero|content|comparison|quote|closing"}
  ]
}
Body copy should be concise enough for a real presentation.
${studioAgeRules(profile)}
      `.trim(),
      ...(useWeb?{tools:[{type:"web_search"}]}:{}),
      input:`Maak een presentatie over: ${topic}`,
      safety_identifier:req.safetyIdentifier
    });

    let deck;
    try{
      deck=parseDeckJson(response.output_text);
    }catch{
      return res.status(502).json({message:"De presentatie-inhoud kwam niet in geldig JSON-formaat terug."});
    }
    if(!Array.isArray(deck.slides))return res.status(502).json({message:"Ongeldige deckstructuur."});
    deck.slides=deck.slides.slice(0,count);
    res.json({ok:true,deck,citations:uniqueCitations(response)});
  }catch(err){
    console.error(err);res.status(500).json({message:"De presentatie kon niet worden gegenereerd."});
  }
});

app.post("/api/studio/poster",(req,res,next)=>enforceAiAccess(req,res,next,"image"),async(req,res)=>{
  try{
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    const title=cleanString(req.body?.title,300);
    const subtitle=cleanString(req.body?.subtitle,600);
    const visual=cleanString(req.body?.visual,1200);
    const format=cleanString(req.body?.format,30)||"portrait";
    if(!(await safeInputOrReject(req,res,[title,subtitle,visual].filter(Boolean).join("\n"))))return;
    const size=format==="landscape"?"1536x1024":format==="square"?"1024x1024":"1024x1536";

    // Generate artwork WITHOUT critical text: StudentOS overlays crisp editable text in-browser.
    const prompt=`
Create premium poster artwork/background for a design titled "${title}".
Visual brief: ${visual || "modern, professional, high-impact editorial design"}.
Supporting context: ${subtitle}.
Do NOT render logos or brand marks of Canva, Gamma, ChatGPT, Gemini, DeepSeek, or other third-party products.
Do NOT put essential readable headline text in the image; leave strong negative space for typography overlay.
Composition should work as a ${format} poster.
High visual hierarchy, polished professional advertising quality.
`.trim();

    const result=await openai.images.generate({
      model:process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
      prompt,
      size
    });
    const b64=result.data?.[0]?.b64_json;
    if(!b64)return res.status(502).json({message:"Geen afbeelding ontvangen."});
    res.json({ok:true,image_data_url:`data:image/png;base64,${b64}`});
  }catch(err){
    console.error(err);res.status(500).json({message:"De posterafbeelding kon niet worden gegenereerd."});
  }
});




app.post("/api/studio/design-edit",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const kind=cleanString(req.body?.kind,30);
    const instruction=cleanString(req.body?.instruction,1200);
    const content=req.body?.content||{};
    const context=req.body?.context||{};
    if(!instruction)return res.status(400).json({message:"Geef een ontwerp-instructie."});
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    if(!(await safeInputOrReject(req,res,instruction)))return;

    const response=await openai.responses.create({
      model:process.env.OPENAI_MODEL || "gpt-5.6",
      instructions:`
You are StudentOS Design Assist.
You improve content structure and design direction without copying another brand's proprietary interface or assets.
Return ONLY valid JSON and no markdown fences.

If kind is "slide", return:
{"title":"...","body":"..."}

If kind is "poster", return:
{"title":"...","subtitle":"...","visual":"..."}

Keep the user's meaning, but make the content clearer, stronger, more visually usable and appropriate for the audience.
Do not invent factual claims.
`.trim(),
      input:JSON.stringify({kind,instruction,content,context}),
      safety_identifier:req.safetyIdentifier
    });

    const raw=String(response.output_text||"").replace(/^```json\s*/i,"").replace(/^```\s*/,"").replace(/\s*```$/,"").trim();
    const data=JSON.parse(raw);
    res.json({ok:true,...data});
  }catch(err){
    console.error(err);res.status(500).json({message:"Design Assist kon de wijziging niet uitvoeren."});
  }
});


app.use(express.static(ROOT_DIR,{extensions:["html"],maxAge:process.env.NODE_ENV==="production"?"1h":0}));
app.get(/^(?!\/api).*/,(_req,res)=>res.sendFile(path.join(ROOT_DIR,"index.html")));
app.use((err,req,res,_next)=>{
  console.error(`[${req.requestId||"no-id"}]`,err);
  res.status(500).json({message:"Er ging iets mis op de StudentOS-server.",request_id:req.requestId});
});

app.listen(PORT, () => {
  console.log(`StudentOS V16 Online MVP: http://localhost:${PORT}`);
});
