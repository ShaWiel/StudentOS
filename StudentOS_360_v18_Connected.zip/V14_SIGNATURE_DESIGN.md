# StudentOS 360 — V14 Signature Design

V14 is de grootste visuele redesign van StudentOS tot nu toe.

## Publieke homepage
- premium marketing hero
- live-looking StudentOS productmockup
- zwevende Studio AI/mastery cards
- bento feature-grid
- adaptive-learning showcase
- Studio AI product showcase
- studie/toekomst showcase
- sterke call-to-action secties
- complete premium profielsetup

## Merkbeleving
- eigen StudentOS-signatuur
- violet + lime accents
- dark ink surfaces
- League Spartan + Inter
- glass, soft gradients en gecontroleerde shadows
- veel meer witruimte en typografische hiërarchie

## Micro-interacties
- reveal-on-scroll
- floating cards
- animated AI typing state
- hover lift
- responsive transformations

## App UX
- Ctrl/Cmd + K command palette
- snel navigeren naar alle hoofdmodules
- sterkere sidebar active state
- subtiele app background depth

## Bestaande functionaliteit
Alle V13/V12/V11-functies blijven behouden, waaronder:
- adaptive learning
- mastery
- school finder
- toekomstnavigator
- AI Tutor
- Studio AI
- presentation/poster editors
- projecten
- planner/doelen

Geen ouderdashboard, docentdashboard of rapportcijfers toegevoegd.
