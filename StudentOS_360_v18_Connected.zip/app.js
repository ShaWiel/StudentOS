
const STORAGE = {
  profile: "studentos_v7_profile",
  tasks: "studentos_v7_tasks",
  goals: "studentos_v7_goals",
  activity: "studentos_v7_activity",
  learned: "studentos_v7_learned"
};

let profile = JSON.parse(localStorage.getItem(STORAGE.profile) || "null");
let tasks = JSON.parse(localStorage.getItem(STORAGE.tasks) || "[]");
let goals = JSON.parse(localStorage.getItem(STORAGE.goals) || "[]");
let activity = JSON.parse(localStorage.getItem(STORAGE.activity) || "[]");
let learned = JSON.parse(localStorage.getItem(STORAGE.learned) || "[]");

const stageNames = {
  peuter:"Peuter / kleuter",
  basis:"Basisonderwijs",
  voj:"VOJ",
  vos:"VOS / middelbaar",
  student:"Student",
  volwassene:"Volwassene",
  senior:"Senior"
};

const goalNames = {
  beter_begrijpen:"leerstof beter begrijpen",
  hogere_cijfers:"je resultaten verbeteren",
  studiekeuze:"je volgende school of studie kiezen",
  carriere:"ontdekken wat je later wilt worden",
  digitale_skills:"beter worden met computer en ICT",
  werk:"praktische werkvaardigheden ontwikkelen"
};

const localTutorKnowledge = {
  breuken:{
    simple:"Een breuk is een deel van iets. Denk aan een pizza die in gelijke stukken is gesneden. Als je 1 van 2 stukken hebt, heb je 1/2: de helft.",
    normal:"Een breuk bestaat uit een teller en een noemer. De noemer zegt in hoeveel gelijke delen het geheel is verdeeld. De teller zegt hoeveel van die delen je gebruikt.",
    deep:"Breuken representeren rationale getallen als verhouding a/b, waarbij b niet nul is. Je kunt ze vereenvoudigen, vergelijken, optellen via gelijke noemers en converteren naar decimalen of percentages.",
    quiz:["Wat betekent de noemer?","Wat is groter: 1/2 of 1/4?","Hoeveel kwartjes vormen één geheel?"]
  },
  inflatie:{
    simple:"Inflatie betekent dat veel prijzen gemiddeld hoger worden. Als een brood eerst 20 kostte en later 24, heb je meer geld nodig voor hetzelfde brood.",
    normal:"Inflatie is een algemene stijging van het prijsniveau. Daardoor neemt de koopkracht van geld af: met hetzelfde bedrag kun je gemiddeld minder kopen.",
    deep:"Inflatie is een aanhoudende stijging van het algemene prijsniveau. Ze kan samenhangen met vraagdruk, hogere productiekosten, geld- en kredietontwikkeling, verwachtingen en externe prijs- of wisselkoersschokken.",
    quiz:["Wat gebeurt er met koopkracht bij inflatie?","Is één product dat duurder wordt automatisch inflatie?","Noem één mogelijk gevolg van hoge inflatie."]
  },
  fotosynthese:{
    simple:"Een plant gebruikt licht, water en lucht om zelf voeding te maken. Daarbij komt zuurstof vrij.",
    normal:"Bij fotosynthese gebruiken planten lichtenergie om uit water en koolstofdioxide glucose te maken. Daarbij komt zuurstof vrij.",
    deep:"Fotosynthese zet lichtenergie om in chemische energie. In chloroplasten wordt onder invloed van chlorofyl uit CO₂ en H₂O glucose gevormd, met O₂ als bijproduct.",
    quiz:["Welke drie dingen gebruikt een plant?","Wat maakt de plant als voeding?","Welk gas komt vrij?"]
  }
};

function localSaveAll(){
  localStorage.setItem(STORAGE.profile, JSON.stringify(profile));
  localStorage.setItem(STORAGE.tasks, JSON.stringify(tasks));
  localStorage.setItem(STORAGE.goals, JSON.stringify(goals));
  localStorage.setItem(STORAGE.activity, JSON.stringify(activity));
  localStorage.setItem(STORAGE.learned, JSON.stringify(learned));
}

function addActivity(text){
  activity.unshift({text, date:new Date().toISOString()});
  activity = activity.slice(0,30);
  saveAll();
}

function todayISO(){
  return new Date().toISOString().slice(0,10);
}

function init(){
  if(profile){
    document.getElementById("onboarding").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    loadProfileUI();
    renderAll();
  } else {
    document.getElementById("onboarding").classList.remove("hidden");
    document.getElementById("app").classList.add("hidden");
  }
}

document.getElementById("profileForm").addEventListener("submit", e=>{
  e.preventDefault();
  profile = {
    name:document.getElementById("nameInput").value.trim(),
    age:Number(document.getElementById("ageInput").value),
    stage:document.getElementById("stageInput").value,
    goal:document.getElementById("goalInput").value,
    subjects:document.getElementById("subjectsInput").value.trim()
  };
  addActivity("Persoonlijk StudentOS-profiel aangemaakt.");
  saveAll();
  init();
});

function loadProfileUI(){
  document.getElementById("sidebarName").textContent = profile.name;
  document.getElementById("sidebarStage").textContent = stageNames[profile.stage];
  document.getElementById("avatarLetter").textContent = (profile.name[0] || "S").toUpperCase();
  document.getElementById("welcomeName").textContent = profile.name + " 👋";
  document.getElementById("welcomeMessage").textContent = `Je werkt momenteel aan ${goalNames[profile.goal]}. Kies vandaag één concrete stap.`;
  document.getElementById("tutorIntro").textContent = `Hoi ${profile.name}! Vertel me wat je niet begrijpt. Ik pas mijn uitleg aan op ${stageNames[profile.stage]}.`;

  document.getElementById("editName").value = profile.name;
  document.getElementById("editAge").value = profile.age;
  document.getElementById("editStage").value = profile.stage;
  document.getElementById("editGoal").value = profile.goal;
  document.getElementById("editSubjects").value = profile.subjects || "";

  if(profile.stage==="senior") document.body.classList.add("large-text");
}

document.getElementById("editProfileForm").addEventListener("submit", e=>{
  e.preventDefault();
  profile.name = document.getElementById("editName").value.trim();
  profile.age = Number(document.getElementById("editAge").value);
  profile.stage = document.getElementById("editStage").value;
  profile.goal = document.getElementById("editGoal").value;
  profile.subjects = document.getElementById("editSubjects").value.trim();
  addActivity("Profiel bijgewerkt.");
  saveAll();
  loadProfileUI();
  renderAll();
  alert("Profiel opgeslagen.");
});

const titles = {
  dashboard:"Dashboard",
  projects:"Mijn Projecten",
  tutor:"AI Tutor",
  studio:"Studio AI",
  planner:"Planner",
  progress:"Voortgang",
  goals:"Doelen",
  profile:"Profiel"
};

function goView(view){
  document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));
  document.getElementById("view-"+view).classList.remove("hidden");
  document.querySelectorAll(".side-nav button").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  document.getElementById("viewTitle").textContent = titles[view];
  if(view==="progress") renderProgress();
}
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>goView(b.dataset.view));
document.querySelectorAll("[data-go-view]").forEach(b=>b.onclick=()=>goView(b.dataset.goView));
document.getElementById("quickAskBtn").onclick=()=>goView("tutor");

function renderTasks(){
  const today = todayISO();
  const todayList = tasks.filter(t=>t.date===today);
  renderTaskList("todayTasks", todayList, true);
  renderTaskList("plannerTasks", tasks.sort((a,b)=>a.date.localeCompare(b.date)), false);

  const completedToday = todayList.filter(t=>t.done).length;
  const pct = todayList.length ? Math.round(completedToday/todayList.length*100) : 0;
  document.getElementById("todayScore").textContent = pct+"%";
}

function renderTaskList(id,list,compact){
  const el=document.getElementById(id);
  if(!list.length){
    el.innerHTML=`<div class="empty">${compact?"Nog niets gepland voor vandaag.":"Nog geen taken toegevoegd."}</div>`;
    return;
  }
  el.innerHTML=list.map(t=>`
    <div class="task-item ${t.done?"done":""}">
      <button class="task-check ${t.done?"checked":""}" data-toggle-task="${t.id}">${t.done?"✓":""}</button>
      <div class="task-body">
        <span class="task-title">${escapeHtml(t.title)}</span>
        <span class="task-meta">${escapeHtml(t.subject||"Algemeen")} • ${t.minutes} min • ${formatDate(t.date)}</span>
      </div>
      <span class="priority ${t.priority}">${t.priority}</span>
      ${compact?"":`<button class="remove-btn" data-remove-task="${t.id}">×</button>`}
    </div>
  `).join("");

  el.querySelectorAll("[data-toggle-task]").forEach(b=>b.onclick=()=>toggleTask(b.dataset.toggleTask));
  el.querySelectorAll("[data-remove-task]").forEach(b=>b.onclick=()=>removeTask(b.dataset.removeTask));
}

document.getElementById("taskForm").addEventListener("submit", e=>{
  e.preventDefault();
  const task={
    id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    title:document.getElementById("taskTitle").value.trim(),
    subject:document.getElementById("taskSubject").value.trim(),
    date:document.getElementById("taskDate").value,
    minutes:Number(document.getElementById("taskMinutes").value)||30,
    priority:document.getElementById("taskPriority").value,
    done:false
  };
  tasks.push(task);
  addActivity(`Taak gepland: ${task.title}`);
  saveAll();
  document.getElementById("taskForm").reset();
  document.getElementById("taskMinutes").value=30;
  renderAll();
});

function toggleTask(id){
  const t=tasks.find(x=>x.id===id); if(!t)return;
  t.done=!t.done;
  if(t.done)addActivity(`Taak afgerond: ${t.title}`);
  saveAll();renderAll();
}
function removeTask(id){tasks=tasks.filter(x=>x.id!==id);saveAll();renderAll();}
document.getElementById("clearCompletedBtn").onclick=()=>{tasks=tasks.filter(t=>!t.done);saveAll();renderAll();};

function renderGoals(){
  const el=document.getElementById("goalsList");
  if(!goals.length){el.innerHTML=`<div class="empty">Nog geen doelen. Voeg één concreet doel toe.</div>`;return;}
  el.innerHTML=goals.map(g=>`
    <div class="goal-item">
      <div class="goal-item-top"><h4>${escapeHtml(g.title)}</h4><small>${g.done?"Afgerond":"Actief"}</small></div>
      <p>${escapeHtml(g.why||"Geen reden toegevoegd.")}</p>
      <div class="goal-progress"><div style="width:${g.done?100:35}%"></div></div>
      <div class="goal-actions">
        <button class="done-goal" data-goal-done="${g.id}">${g.done?"Heropen":"Markeer afgerond"}</button>
        <button class="delete-goal" data-goal-delete="${g.id}">Verwijder</button>
      </div>
    </div>`).join("");
  el.querySelectorAll("[data-goal-done]").forEach(b=>b.onclick=()=>toggleGoal(b.dataset.goalDone));
  el.querySelectorAll("[data-goal-delete]").forEach(b=>b.onclick=()=>deleteGoal(b.dataset.goalDelete));
}

document.getElementById("goalForm").addEventListener("submit",e=>{
  e.preventDefault();
  const g={
    id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    title:document.getElementById("goalTitle").value.trim(),
    why:document.getElementById("goalWhy").value.trim(),
    date:document.getElementById("goalDate").value,
    done:false
  };
  goals.push(g);addActivity(`Nieuw doel: ${g.title}`);saveAll();
  e.target.reset();renderAll();
});
function toggleGoal(id){const g=goals.find(x=>x.id===id);if(!g)return;g.done=!g.done;if(g.done)addActivity(`Doel behaald: ${g.title}`);saveAll();renderAll();}
function deleteGoal(id){goals=goals.filter(x=>x.id!==id);saveAll();renderAll();}

function renderMetrics(){
  document.getElementById("metricLearned").textContent=learned.length;
  document.getElementById("metricTasks").textContent=tasks.filter(t=>t.done).length;
  document.getElementById("metricMinutes").textContent=tasks.reduce((s,t)=>s+(t.minutes||0),0);
  document.getElementById("metricGoals").textContent=goals.filter(g=>!g.done).length;
  document.getElementById("streakCount").textContent = Math.max(1,Math.min(7,activity.length))+" dag"+(activity.length===1?"":"en");
}

function renderRecommendations(){
  const recs=[];
  if(!tasks.some(t=>t.date===todayISO())) recs.push(["📅","Plan één taak voor vandaag","Een kleine concrete taak maakt beginnen makkelijker.","planner"]);
  if(profile.subjects) recs.push(["📚","Werk aan "+profile.subjects.split(",")[0],"Vraag de Tutor om één moeilijk onderdeel uit te leggen.","tutor"]);
  if(goals.length===0) recs.push(["🎯","Maak één leerdoel","Een doel geeft je planning richting.","goals"]);
  recs.push(["🧠","Test je begrip","Laat de Tutor je na de uitleg 3 vragen stellen.","tutor"]);
  document.getElementById("recommendationCards").innerHTML=recs.slice(0,4).map(r=>`
    <button class="recommend-item" data-rec-view="${r[3]}" style="width:100%;text-align:left;background:white">
      <span>${r[0]}</span><div><strong>${r[1]}</strong><small>${r[2]}</small></div>
    </button>`).join("");
  document.querySelectorAll("[data-rec-view]").forEach(b=>b.onclick=()=>goView(b.dataset.recView));
}

function renderProgress(){
  const totalTasks=tasks.length;
  const doneTasks=tasks.filter(t=>t.done).length;
  const goalDone=goals.filter(g=>g.done).length;
  const score=Math.min(100,Math.round(
    (learned.length*8) + (doneTasks*6) + (goalDone*15)
  ));
  document.getElementById("overallProgress").textContent=score+"%";

  const bars=[
    ["Leren",Math.min(100,learned.length*15)],
    ["Taken",totalTasks?Math.round(doneTasks/totalTasks*100):0],
    ["Doelen",goals.length?Math.round(goalDone/goals.length*100):0],
    ["Planning",Math.min(100,tasks.length*10)]
  ];
  document.getElementById("activityBars").innerHTML=bars.map(b=>`
    <div class="bar-row"><div class="bar-label"><span>${b[0]}</span><span>${b[1]}%</span></div><div class="bar-track"><div style="width:${b[1]}%"></div></div></div>
  `).join("");

  document.getElementById("activityFeed").innerHTML=activity.length?activity.slice(0,8).map(a=>`
    <div class="activity-item"><strong>${escapeHtml(a.text)}</strong><small>${formatDateTime(a.date)}</small></div>
  `).join(""):`<div class="empty">Je activiteit verschijnt hier zodra je StudentOS gebruikt.</div>`;
}

function normalizeTutorTopic(text){
  const t=text.toLowerCase();
  if(t.includes("breuk"))return "breuken";
  if(t.includes("inflatie"))return "inflatie";
  if(t.includes("foto")||t.includes("plant"))return "fotosynthese";
  return null;
}
function tutorMode(){
  const level=document.getElementById("tutorLevel").value;
  if(level==="heel_simpel")return "simple";
  if(level==="diepgaand")return "deep";
  return "normal";
}
function tutorStyle(){return document.querySelector('input[name="tutorStyle"]:checked').value;}

function addMessage(role,html){
  const wrap=document.getElementById("chatMessages");
  const div=document.createElement("div");
  div.className="message "+role;
  div.innerHTML=`<div class="bubble">${html}</div>`;
  wrap.appendChild(div);wrap.scrollTop=wrap.scrollHeight;
}

function localTutorReply(prompt){
  const topic=normalizeTutorTopic(prompt);
  const mode=tutorMode();
  const style=tutorStyle();

  if(prompt.toLowerCase().includes("powerpoint")){
    return `<strong>We bouwen hem samen.</strong><ol><li>Wat is je onderwerp?</li><li>Wie is je publiek?</li><li>Hoe lang moet je presenteren?</li><li>Wat moet het publiek na afloop begrijpen?</li></ol><p>Begin daarna met: titel → waarom belangrijk → 2–3 kernpunten → voorbeeld → conclusie → bronnen.</p>`;
  }
  if(prompt.toLowerCase().includes("planning")||prompt.toLowerCase().includes("toets")){
    return `<strong>Maak eerst overzicht.</strong><ol><li>Schrijf de toetsdatum op.</li><li>Verdeel de stof in kleine onderdelen.</li><li>Plan korte blokken per dag.</li><li>Plan vóór de toets minstens één oefenmoment zonder boek.</li></ol><p>Gebruik daarna de Planner om elke sessie in te voeren.</p>`;
  }
  if(topic){
    const data=localTutorKnowledge[topic];
    let html=`<strong>${topic[0].toUpperCase()+topic.slice(1)}</strong><p>${data[mode]}</p>`;
    if(style==="voorbeeld")html+=`<p><strong>Voorbeeld:</strong> Probeer het onderwerp nu te koppelen aan iets uit je dagelijks leven. Dat maakt onthouden makkelijker.</p>`;
    if(style==="stappen")html+=`<ol><li>Lees de uitleg.</li><li>Schrijf drie kernwoorden op.</li><li>Leg het zonder spieken in je eigen woorden uit.</li></ol>`;
    if(style==="quiz")html+=`<p><strong>Controleer jezelf:</strong></p><ol>${data.quiz.map(q=>`<li>${q}</li>`).join("")}</ol>`;
    if(!learned.includes(topic)){learned.push(topic);addActivity(`Onderwerp geleerd met Tutor: ${topic}`);saveAll();}
    return html;
  }
  return `<strong>Ik kan je hiermee helpen, maar deze V7 gebruikt nog geen live AI-model.</strong><p>De interface en backend-route zijn al voorbereid. Voor willekeurige onderwerpen zal de volgende technische stap een server-side AI-koppeling zijn.</p><p>Tot die tijd kun je je vraag opdelen in:</p><ol><li>Wat begrijp ik al?</li><li>Waar raak ik precies de draad kwijt?</li><li>Welk voorbeeld zou helpen?</li></ol>`;
}

document.getElementById("chatForm").addEventListener("submit",e=>{
  e.preventDefault();
  const input=document.getElementById("chatInput");
  const text=input.value.trim(); if(!text)return;
  addMessage("user",`<p>${escapeHtml(text)}</p>`);
  input.value="";
  const reply=localTutorReply(text);
  setTimeout(()=>{addMessage("assistant",`<strong>StudentOS Tutor</strong>${reply}`);renderAll();},180);
});
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{document.getElementById("chatInput").value=b.dataset.prompt;document.getElementById("chatForm").requestSubmit();});

function renderAll(){
  if(!profile)return;
  renderTasks();
  renderGoals();
  renderMetrics();
  renderRecommendations();
  renderProgress();
}

document.getElementById("focusModeBtn").onclick=()=>{
  document.body.classList.toggle("focus-mode");
  document.getElementById("focusModeBtn").textContent=document.body.classList.contains("focus-mode")?"Normale modus":"Focusmodus";
};
document.getElementById("largeTextBtn").onclick=()=>{
  document.body.classList.toggle("large-text");
  document.getElementById("largeTextBtn").textContent=document.body.classList.contains("large-text")?"A− Tekst":"A+ Tekst";
};
document.getElementById("resetDemoBtn").onclick=()=>{
  if(confirm("Wil je alle lokale StudentOS V7-data wissen?")){
    Object.values(STORAGE).forEach(k=>localStorage.removeItem(k));
    location.reload();
  }
};

function escapeHtml(s){return String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function formatDate(d){
  if(!d)return "";
  return new Date(d+"T00:00:00").toLocaleDateString("nl-NL",{day:"numeric",month:"short"});
}
function formatDateTime(d){
  return new Date(d).toLocaleDateString("nl-NL",{day:"numeric",month:"short",year:"numeric"});
}

document.getElementById("taskDate").value=todayISO();
init();


/* ===========================
   V7.1 CLOUD + LIVE AI LAYER
   =========================== */

let V71_CONFIG = window.STUDENTOS_CONFIG || {};
let supabaseClient = null;
let currentUser = null;
let cloudReady = false;
let cloudSyncTimer = null;

async function loadRuntimeConfig(){
  const hasHttp=location.protocol==="http:"||location.protocol==="https:";
  if(V71_CONFIG.SUPABASE_URL && V71_CONFIG.SUPABASE_PUBLISHABLE_KEY) return;
  if(!hasHttp) return;
  try{
    const r=await fetch(location.origin+"/api/public-config",{cache:"no-store"});
    if(!r.ok)return;
    const cfg=await r.json();
    V71_CONFIG={...V71_CONFIG,...cfg,API_BASE_URL:V71_CONFIG.API_BASE_URL||location.origin};
    window.STUDENTOS_CONFIG=V71_CONFIG;
  }catch(err){console.warn("Runtime config niet beschikbaar",err);}
}

function apiBaseUrl(){
  if(V71_CONFIG.API_BASE_URL)return String(V71_CONFIG.API_BASE_URL).replace(/\/$/,"");
  if(location.protocol==="http:"||location.protocol==="https:")return location.origin;
  return "http://localhost:3000";
}


function isSupabaseConfigured(){
  return Boolean(V71_CONFIG.SUPABASE_URL && V71_CONFIG.SUPABASE_PUBLISHABLE_KEY && window.supabase);
}

async function initCloud(){
  if(!isSupabaseConfigured()){
    setConnectionState("demo","Demo");
    document.getElementById("cloudStatus").textContent="☁️ Lokale opslag";
    return;
  }

  try{
    supabaseClient = window.supabase.createClient(
      V71_CONFIG.SUPABASE_URL,
      V71_CONFIG.SUPABASE_PUBLISHABLE_KEY
    );

    const { data:{ session } } = await supabaseClient.auth.getSession();
    currentUser = session?.user || null;

    supabaseClient.auth.onAuthStateChange(async (_event, session)=>{
      currentUser = session?.user || null;
      updateAuthUI();
      if(currentUser){
        await pullCloudData();
        if(typeof pullCloudProjects==="function") await pullCloudProjects().catch(console.warn);
        if(window.studentosPullMasteryFromCloud) await window.studentosPullMasteryFromCloud().catch(console.warn);
        renderAll();
      }
    });

    cloudReady = true;
    setConnectionState("live","Cloud-ready");
    updateAuthUI();

    if(currentUser){
      await pullCloudData();
      if(typeof pullCloudProjects==="function") await pullCloudProjects().catch(console.warn);
      if(window.studentosPullMasteryFromCloud) await window.studentosPullMasteryFromCloud().catch(console.warn);
      renderAll();
    }
  }catch(err){
    console.error("Supabase init fout",err);
    setConnectionState("offline","Offline");
    document.getElementById("cloudStatus").textContent="⚠️ Cloud niet bereikbaar";
  }
}

function setConnectionState(kind,text){
  const badge=document.getElementById("connectionBadge");
  if(!badge)return;
  badge.className="connection-badge "+kind;
  badge.textContent=text;
}

function updateAuthUI(){
  const btn=document.getElementById("authBtn");
  if(!btn)return;
  if(currentUser){
    btn.textContent="Uitloggen";
    document.getElementById("cloudStatus").textContent="☁️ Gesynchroniseerd account";
    setConnectionState("live","Online");
  }else if(cloudReady){
    btn.textContent="Inloggen";
    document.getElementById("cloudStatus").textContent="☁️ Cloud beschikbaar";
  }else{
    btn.textContent="Inloggen";
  }
}

function saveAll(){
  // V7 blijft offline-first.
  localSaveAll();

  if(currentUser && cloudReady){
    clearTimeout(cloudSyncTimer);
    cloudSyncTimer=setTimeout(()=>pushCloudData().catch(console.error),350);
  }
}

async function pushCloudData(){
  if(!currentUser || !supabaseClient)return;

  const uid=currentUser.id;

  if(profile){
    const { error } = await supabaseClient.from("profiles").upsert({
      id:uid,
      display_name:profile.name,
      age:profile.age,
      stage:profile.stage,
      primary_goal:profile.goal,
      subjects: profile.subjects ? profile.subjects.split(",").map(x=>x.trim()).filter(Boolean) : [],
      updated_at:new Date().toISOString()
    });
    if(error) throw error;
  }

  // Voor dit prototype synchroniseren we snapshots. Dit houdt de code overzichtelijk.
  const snapshot={
    user_id:uid,
    tasks,
    goals,
    activity,
    learned,
    updated_at:new Date().toISOString()
  };
  const { error:snapError } = await supabaseClient.from("user_state").upsert(snapshot,{onConflict:"user_id"});
  if(snapError) throw snapError;

  showSyncToast("Cloud opgeslagen");
}

async function pullCloudData(){
  if(!currentUser || !supabaseClient)return;

  const uid=currentUser.id;
  const [{data:p,error:pErr},{data:s,error:sErr}] = await Promise.all([
    supabaseClient.from("profiles").select("*").eq("id",uid).maybeSingle(),
    supabaseClient.from("user_state").select("*").eq("user_id",uid).maybeSingle()
  ]);

  if(pErr) console.warn(pErr);
  if(sErr) console.warn(sErr);

  if(p){
    profile={
      name:p.display_name,
      age:p.age,
      stage:p.stage,
      goal:p.primary_goal,
      subjects:(p.subjects||[]).join(", ")
    };
  }
  if(s){
    tasks=Array.isArray(s.tasks)?s.tasks:tasks;
    goals=Array.isArray(s.goals)?s.goals:goals;
    activity=Array.isArray(s.activity)?s.activity:activity;
    learned=Array.isArray(s.learned)?s.learned:learned;
  }

  localSaveAll();
  loadProfileUI();
}

function showSyncToast(text,kind=""){
  const old=document.querySelector(".sync-toast");
  if(old)old.remove();
  const t=document.createElement("div");
  t.className="sync-toast "+kind;
  t.textContent=text;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),1600);
}

/* ---------- AUTH UI ---------- */

const authModal=document.getElementById("authModal");
const authMessage=document.getElementById("authMessage");

function openAuth(){
  if(!isSupabaseConfigured()){
    alert("Supabase is nog niet geconfigureerd. Vul config.js in met je project-URL en publishable key.");
    return;
  }
  authMessage.textContent="";
  authModal.classList.remove("hidden");
}
function closeAuth(){authModal.classList.add("hidden");}

document.getElementById("authBtn").addEventListener("click",async()=>{
  if(currentUser && supabaseClient){
    await pushCloudData().catch(()=>{});
    await supabaseClient.auth.signOut();
    currentUser=null;
    updateAuthUI();
    return;
  }
  openAuth();
});
document.querySelectorAll("[data-close-auth]").forEach(x=>x.onclick=closeAuth);

document.querySelectorAll("[data-auth-tab]").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll("[data-auth-tab]").forEach(x=>x.classList.toggle("active",x===btn));
  const signup=btn.dataset.authTab==="signup";
  document.getElementById("loginForm").classList.toggle("hidden",signup);
  document.getElementById("signupForm").classList.toggle("hidden",!signup);
  document.getElementById("authTitle").textContent=signup?"Account maken":"Inloggen";
  authMessage.textContent="";
});

document.getElementById("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();
  authMessage.className="auth-message";
  authMessage.textContent="Bezig met inloggen…";
  const {error}=await supabaseClient.auth.signInWithPassword({
    email:document.getElementById("loginEmail").value.trim(),
    password:document.getElementById("loginPassword").value
  });
  if(error){authMessage.textContent=error.message;return;}
  authMessage.className="auth-message success";
  authMessage.textContent="Ingelogd.";
  setTimeout(closeAuth,500);
});

document.getElementById("signupForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const pw=document.getElementById("signupPassword").value;
  const pw2=document.getElementById("signupPassword2").value;
  if(pw!==pw2){authMessage.textContent="De wachtwoorden zijn niet hetzelfde.";return;}
  authMessage.className="auth-message";
  authMessage.textContent="Account wordt aangemaakt…";

  const {data,error}=await supabaseClient.auth.signUp({
    email:document.getElementById("signupEmail").value.trim(),
    password:pw
  });
  if(error){authMessage.textContent=error.message;return;}
  authMessage.className="auth-message success";
  authMessage.textContent=data.session
    ?"Account aangemaakt en ingelogd."
    :"Account aangemaakt. Controleer je e-mail als bevestiging is ingeschakeld.";
});

/* ---------- LIVE TUTOR ---------- */

async function askLiveTutor(question){
  const base=apiBaseUrl();

  let accessToken="";
  if(currentUser && supabaseClient){
    const {data:{session}}=await supabaseClient.auth.getSession();
    accessToken=session?.access_token||"";
  }

  const response=await fetch(base+"/api/tutor",{
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      ...(accessToken?{"Authorization":"Bearer "+accessToken}:{})
    },
    body:JSON.stringify({
      question,
      profile:{
        name:profile?.name||"Gebruiker",
        age:profile?.age||null,
        stage:profile?.stage||"volwassene",
        goal:profile?.goal||"",
        subjects:profile?.subjects||""
      },
      explanation_level:document.getElementById("tutorLevel").value,
      learning_style:tutorStyle()
    })
  });

  if(!response.ok){
    const detail=await response.json().catch(()=>({}));
    throw new Error(detail.message||"Tutor-backend niet beschikbaar.");
  }
  return response.json();
}

// Vervang de V7 chat submit door een live-first handler.
// De oude handler blijft geregistreerd in het bestand, daarom blokkeren we hem in capture-fase.
const chatFormV71=document.getElementById("chatForm");
chatFormV71.addEventListener("submit",async e=>{
  if(!window.__V71_CHAT_ACTIVE)return;
  e.preventDefault();
  e.stopImmediatePropagation();

  const input=document.getElementById("chatInput");
  const text=input.value.trim();
  if(!text)return;

  addMessage("user",`<p>${escapeHtml(text)}</p>`);
  input.value="";
  addMessage("assistant",`<strong>StudentOS Tutor</strong><p>Ik denk even met je mee…</p>`);
  const waiting=document.querySelector("#chatMessages .message:last-child");

  try{
    const data=await askLiveTutor(text);
    waiting.remove();
    const safe=escapeHtml(data.answer||"Geen antwoord ontvangen.").replace(/\n/g,"<br>");
    addMessage("assistant",`<strong>StudentOS Tutor</strong><p>${safe}</p>`);
    const topic=(data.topic||"").trim();
    if(topic && !learned.includes(topic)){
      learned.push(topic);
      addActivity(`Onderwerp geleerd met AI Tutor: ${topic}`);
    }
    document.getElementById("tutorStatusNote").textContent="Live AI Tutor actief via server-side verbinding.";
    saveAll();renderAll();
  }catch(err){
    waiting.remove();
    const fallback=localTutorReply(text);
    addMessage("assistant",`<strong>StudentOS Tutor — offline fallback</strong>${fallback}`);
    document.getElementById("tutorStatusNote").textContent="Live AI niet bereikbaar; lokale demokennis wordt gebruikt.";
    console.warn(err);
    renderAll();
  }
},true);

window.__V71_CHAT_ACTIVE=true;

// Init cloud after original V7 initialization has run.
setTimeout(async()=>{await loadRuntimeConfig();await initCloud();refreshSystemStatus().catch(()=>{});},0);


/* ==============================
   STUDENTOS V8 — STUDIO AI
   ============================== */

let studioTab="chat";
let answerMode="fast";
let currentDeck=null;
let currentSlide=0;
let posterImageData="";

document.querySelectorAll("[data-studio-tab]").forEach(btn=>btn.addEventListener("click",()=>{
  studioTab=btn.dataset.studioTab;
  document.querySelectorAll("[data-studio-tab]").forEach(x=>x.classList.toggle("active",x===btn));
  document.querySelectorAll(".studio-pane").forEach(x=>x.classList.add("hidden"));
  document.getElementById("studio-"+studioTab).classList.remove("hidden");
}));

document.querySelectorAll("[data-answer-mode]").forEach(btn=>btn.addEventListener("click",()=>{
  answerMode=btn.dataset.answerMode;
  document.querySelectorAll("[data-answer-mode]").forEach(x=>x.classList.toggle("active",x===btn));
}));

function apiBase(){ return apiBaseUrl(); }

async function authHeaders(){
  let token="";
  if(currentUser && supabaseClient){
    const {data:{session}}=await supabaseClient.auth.getSession();
    token=session?.access_token||"";
  }
  return {
    "Content-Type":"application/json",
    ...(token?{"Authorization":"Bearer "+token}:{})
  };
}

async function studioFetch(path,payload){
  if(!apiBase())throw new Error("Geen backend ingesteld.");
  const r=await fetch(apiBase()+path,{
    method:"POST",
    headers:await authHeaders(),
    body:JSON.stringify(payload)
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(data.message||"Studio AI is niet bereikbaar.");
  return data;
}

function loading(el,text="StudentOS AI werkt…"){
  el.innerHTML=`<div class="loading-box"><span class="loading-dot"></span>${escapeHtml(text)}</div>`;
}

function renderSources(citations=[]){
  const unique=[];
  const seen=new Set();
  citations.forEach(c=>{
    if(c?.url && !seen.has(c.url)){seen.add(c.url);unique.push(c);}
  });
  if(!unique.length)return "";
  return `<div class="sources-box"><strong>Bronnen</strong><div class="source-list">${
    unique.slice(0,12).map(c=>`<a href="${escapeHtml(c.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(c.title||c.url)}</a>`).join("")
  }</div></div>`;
}

function renderAnswer(el,data,title="Antwoord"){
  const answer=escapeHtml(data.answer||"").replace(/\n/g,"<br>");
  el.innerHTML=`<div class="studio-result"><div class="eyebrow">${escapeHtml(title)}</div><p>${answer}</p>${renderSources(data.citations||[])}</div>`;
}

document.getElementById("studioChatBtn").addEventListener("click",async()=>{
  const q=document.getElementById("studioChatPrompt").value.trim();
  if(!q)return alert("Typ eerst een vraag.");
  const out=document.getElementById("studioChatOutput");
  loading(out,document.getElementById("chatVerifyWeb").checked?"Vraag beantwoorden en feiten controleren…":"Vraag beantwoorden…");
  try{
    const data=await studioFetch("/api/studio/chat",{
      prompt:q,
      mode:answerMode,
      verify_web:document.getElementById("chatVerifyWeb").checked,
      profile
    });
    renderAnswer(out,data,"StudentOS AI");
  }catch(err){
    out.innerHTML=`<div class="studio-result"><h3>Demo fallback</h3><p>${escapeHtml(localTutorReply(q).replace(/<[^>]+>/g," "))}</p><p><small>${escapeHtml(err.message)}</small></p></div>`;
  }
});

document.getElementById("researchBtn").addEventListener("click",async()=>{
  const q=document.getElementById("researchPrompt").value.trim();
  if(!q)return alert("Vul een onderzoeksvraag in.");
  const out=document.getElementById("researchOutput");
  loading(out,"Webbronnen zoeken en vergelijken…");
  try{
    const data=await studioFetch("/api/studio/research",{
      prompt:q,
      level:document.getElementById("researchLevel").value,
      profile
    });
    renderAnswer(out,data,"Research");
  }catch(err){
    out.innerHTML=`<div class="studio-result"><h3>Research-backend niet bereikbaar</h3><p>${escapeHtml(err.message)}</p></div>`;
  }
});

document.getElementById("reportBtn").addEventListener("click",async()=>{
  const q=document.getElementById("reportPrompt").value.trim();
  if(!q)return alert("Vul eerst de opdracht of het onderwerp in.");
  const out=document.getElementById("reportOutput");
  loading(out,document.getElementById("reportVerify").checked?"Eerst bronnen controleren, daarna schrijven…":"Concept schrijven…");
  try{
    const data=await studioFetch("/api/studio/report",{
      prompt:q,
      type:document.getElementById("reportType").value,
      length:document.getElementById("reportLength").value,
      verify_web:document.getElementById("reportVerify").checked,
      profile
    });
    renderAnswer(out,data,"Conceptverslag");
  }catch(err){
    out.innerHTML=`<div class="studio-result"><h3>Writer niet bereikbaar</h3><p>${escapeHtml(err.message)}</p></div>`;
  }
});

document.getElementById("rewriteBtn").addEventListener("click",async()=>{
  const text=document.getElementById("rewriteInput").value.trim();
  if(!text)return alert("Plak eerst tekst om te herschrijven.");
  const out=document.getElementById("rewriteOutput");
  loading(out,"Flow, woordkeuze en toon verbeteren…");
  try{
    const data=await studioFetch("/api/studio/rewrite",{
      text,
      style:document.getElementById("rewriteStyle").value,
      profile
    });
    renderAnswer(out,data,"Natuurlijk herschreven");
  }catch(err){
    out.innerHTML=`<div class="studio-result"><h3>Natural Rewrite niet bereikbaar</h3><p>${escapeHtml(err.message)}</p></div>`;
  }
});

/* ---- PRESENTATIONS ---- */

document.getElementById("presentationBtn").addEventListener("click",async()=>{
  const topic=document.getElementById("presentationTopic").value.trim();
  if(!topic)return alert("Vul eerst een onderwerp in.");
  document.getElementById("deckStatus").textContent="Bezig met genereren…";
  document.getElementById("slideCanvas").innerHTML=`<div class="loading-box"><span class="loading-dot"></span>Structuur, inhoud en slides maken…</div>`;
  document.getElementById("slideThumbs").innerHTML="";
  try{
    const data=await studioFetch("/api/studio/presentation",{
      topic,
      audience:document.getElementById("presentationAudience").value.trim(),
      slide_count:Number(document.getElementById("presentationSlides").value),
      style:document.getElementById("presentationStyle").value,
      verify_web:document.getElementById("presentationResearch").checked,
      profile
    });
    currentDeck=data.deck;
    currentSlide=0;
    renderDeck();
    const sources=document.getElementById("deckSources");
    if(data.citations?.length){
      sources.classList.remove("hidden");
      sources.innerHTML=renderSources(data.citations);
    }else sources.classList.add("hidden");
    document.getElementById("exportPptxBtn").disabled=false;
  }catch(err){
    // A functional demo deck even without backend
    currentDeck=demoDeck(topic,Number(document.getElementById("presentationSlides").value));
    renderDeck();
    document.getElementById("deckStatus").textContent="Demo deck — verbind backend voor AI-content";
    document.getElementById("exportPptxBtn").disabled=false;
  }
});

function demoDeck(topic,count=8){
  const templates=[
    ["Titel",`${topic}\nEen heldere introductie`],
    ["Waarom dit belangrijk is","Context • relevantie • hoofdvraag"],
    ["De kern in één beeld","Wat moet je publiek als eerste begrijpen?"],
    ["Kernpunt 1","Belangrijk inzicht met één sterk voorbeeld."],
    ["Kernpunt 2","Tweede inzicht met bewijs of vergelijking."],
    ["Wat betekent dit?","Vertaal informatie naar impact of toepassing."],
    ["Conclusie","Vat de 3 belangrijkste boodschappen samen."],
    ["Vragen","Bedankt • bronnen • discussie"]
  ];
  return {
    title:topic,
    style:"modern",
    slides:Array.from({length:count},(_,i)=>{
      const t=templates[i]||[`Inzicht ${i+1}`,"Eén duidelijke boodschap per slide."];
      return {title:t[0],body:t[1],layout:i===0?"hero":"content"};
    })
  };
}

function renderDeck(){
  if(!currentDeck?.slides?.length)return;
  document.getElementById("deckTitle").textContent=currentDeck.title||"Presentatie";
  document.getElementById("deckStatus").textContent=currentDeck.slides.length+" slides";
  document.getElementById("slideThumbs").innerHTML=currentDeck.slides.map((s,i)=>`
    <button class="slide-thumb ${i===currentSlide?"active":""}" data-slide-index="${i}">
      <strong>${i+1}. ${escapeHtml(s.title||"")}</strong>
      <p>${escapeHtml((s.body||"").slice(0,90))}</p>
    </button>`).join("");
  document.querySelectorAll("[data-slide-index]").forEach(b=>b.onclick=()=>{currentSlide=Number(b.dataset.slideIndex);renderDeck();});
  const s=currentDeck.slides[currentSlide];
  const light=currentDeck.style==="academic";
  document.getElementById("slideCanvas").innerHTML=`
    <div class="slide-render ${light?"light":""}">
      <h2 contenteditable="true" id="editableSlideTitle">${escapeHtml(s.title||"")}</h2>
      <p contenteditable="true" id="editableSlideBody">${escapeHtml(s.body||"")}</p>
      <span class="slide-number">${currentSlide+1} / ${currentDeck.slides.length}</span>
    </div>`;
  document.getElementById("editableSlideTitle").addEventListener("input",e=>currentDeck.slides[currentSlide].title=e.target.innerText);
  document.getElementById("editableSlideBody").addEventListener("input",e=>currentDeck.slides[currentSlide].body=e.target.innerText);
}

document.getElementById("exportPptxBtn").addEventListener("click",async()=>{
  if(!currentDeck?.slides?.length)return;
  if(typeof PptxGenJS==="undefined")return alert("PPTX-exportbibliotheek kon niet laden.");
  const pptx=new PptxGenJS();
  pptx.layout="LAYOUT_WIDE";
  pptx.author="StudentOS Studio";
  pptx.subject=currentDeck.title||"StudentOS Presentation";
  pptx.title=currentDeck.title||"StudentOS Presentation";
  pptx.company="StudentOS";
  pptx.lang="nl-NL";
  currentDeck.slides.forEach((s,i)=>{
    const slide=pptx.addSlide();
    const dark=currentDeck.style!=="academic";
    slide.background={color:dark?"17191F":"F7F8FB"};
    slide.addText(s.title||"",{
      x:.7,y:1.0,w:11.7,h:1.25,
      fontFace:"Aptos Display",fontSize:i===0?32:27,bold:true,
      color:dark?"FFFFFF":"17191F",margin:0
    });
    slide.addText(s.body||"",{
      x:.75,y:2.5,w:10.8,h:3.2,
      fontFace:"Aptos",fontSize:17,
      color:dark?"D8D9E1":"4E5562",breakLine:false,margin:0.02,
      valign:"mid"
    });
    slide.addText(String(i+1),{x:12.2,y:6.8,w:.3,h:.2,fontSize:7,color:dark?"7F8490":"999999",margin:0});
    slide.addShape(pptx.ShapeType.rect,{x:.7,y:6.65,w:1.25,h:.06,fill:{color:"C9FF6A"},line:{color:"C9FF6A"}});
  });
  await pptx.writeFile({fileName:(currentDeck.title||"StudentOS_Presentation").replace(/[^\w\- ]+/g,"").replace(/\s+/g,"_")+".pptx"});
});

/* ---- POSTER DESIGN ---- */

["posterTitle","posterSubtitle","posterFormat"].forEach(id=>document.getElementById(id).addEventListener("input",updatePosterPreview));
function updatePosterPreview(){
  document.getElementById("posterPreviewTitle").textContent=document.getElementById("posterTitle").value||"Jouw titel";
  document.getElementById("posterPreviewSubtitle").textContent=document.getElementById("posterSubtitle").value||"Subtekst verschijnt hier.";
  const canvas=document.getElementById("posterCanvas");
  canvas.classList.remove("portrait","square","landscape");
  canvas.classList.add(document.getElementById("posterFormat").value);
}
document.getElementById("posterFormat").addEventListener("change",updatePosterPreview);

document.getElementById("posterBtn").addEventListener("click",async()=>{
  const title=document.getElementById("posterTitle").value.trim();
  const visual=document.getElementById("posterVisual").value.trim();
  if(!title && !visual)return alert("Vul een titel of visueel concept in.");
  const art=document.getElementById("posterArt");
  art.style.backgroundImage="";
  art.innerHTML=`<div class="loading-box" style="color:white"><span class="loading-dot"></span>Artwork genereren…</div>`;
  try{
    const data=await studioFetch("/api/studio/poster",{
      title,
      subtitle:document.getElementById("posterSubtitle").value.trim(),
      visual,
      format:document.getElementById("posterFormat").value,
      profile
    });
    posterImageData=data.image_data_url||"";
    art.innerHTML="";
    art.style.backgroundImage=`url("${posterImageData}")`;
    document.getElementById("posterExportBtn").disabled=false;
  }catch(err){
    art.innerHTML="";
    art.style.backgroundImage="radial-gradient(circle at 75% 20%,#8174ff,transparent 35%),linear-gradient(145deg,#17191f,#243754)";
    document.getElementById("posterExportBtn").disabled=false;
  }
});

document.getElementById("posterExportBtn").addEventListener("click",async()=>{
  if(typeof html2canvas==="undefined")return alert("PNG-exportbibliotheek kon niet laden.");
  const canvas=await html2canvas(document.getElementById("posterCanvas"),{scale:2,useCORS:true});
  const link=document.createElement("a");
  link.download=(document.getElementById("posterTitle").value||"StudentOS_Poster").replace(/[^\w\- ]+/g,"").replace(/\s+/g,"_")+".png";
  link.href=canvas.toDataURL("image/png");
  link.click();
});


/* =====================================
   STUDENTOS V9 — SLIDE + POSTER EDITORS
   ===================================== */

let selectedSlideElement=null;
let selectedPosterLayer=null;
let zCounter=10;

function percentFromPx(px,total){return Math.max(0,Math.min(100,(px/total)*100));}

function enableDeckEditorButtons(){
  const enabled=Boolean(currentDeck?.slides?.length);
  ["addSlideBtn","duplicateSlideBtn","deleteSlideBtn","slideAiBtn"].forEach(id=>{
    const el=document.getElementById(id); if(el)el.disabled=!enabled;
  });
}

const oldRenderDeck=renderDeck;
renderDeck=function(){
  if(!currentDeck?.slides?.length)return oldRenderDeck();
  document.getElementById("deckTitle").textContent=currentDeck.title||"Presentatie";
  document.getElementById("deckStatus").textContent=currentDeck.slides.length+" slides";
  document.getElementById("slideThumbs").innerHTML=currentDeck.slides.map((s,i)=>`
    <button class="slide-thumb ${i===currentSlide?"active":""}" data-slide-index="${i}">
      <strong>${i+1}. ${escapeHtml(s.title||"")}</strong>
      <p>${escapeHtml((s.body||"").slice(0,90))}</p>
    </button>`).join("");
  document.querySelectorAll("[data-slide-index]").forEach(b=>b.onclick=()=>{currentSlide=Number(b.dataset.slideIndex);renderDeck();});
  const s=currentDeck.slides[currentSlide];
  const light=currentDeck.style==="academic";
  if(!s.elements){
    s.elements=[
      {id:"title",type:"text",text:s.title||"",x:8,y:18,w:82,fontSize:currentSlide===0?48:38,color:light?"#17191f":"#ffffff",align:"left",z:2},
      {id:"body",type:"text",text:s.body||"",x:8,y:48,w:76,fontSize:18,color:light?"#4e5562":"#d8d9e1",align:"left",z:1}
    ];
  }
  const canvas=document.getElementById("slideCanvas");
  canvas.innerHTML=`<div class="slide-render ${light?"light":""}" id="slideRenderRoot"></div>`;
  const root=document.getElementById("slideRenderRoot");
  s.elements.forEach(el=>{
    const div=document.createElement("div");
    div.className="slide-element";
    div.dataset.elementId=el.id;
    div.textContent=el.text||"";
    Object.assign(div.style,{
      left:el.x+"%", top:el.y+"%", width:el.w+"%",
      fontSize:el.fontSize+"px", color:el.color,
      textAlign:el.align||"left", zIndex:String(el.z||1)
    });
    root.appendChild(div);
    makeDraggableSlideElement(div,el);
    div.addEventListener("click",ev=>{ev.stopPropagation();selectSlideElement(el,div);});
  });
  root.addEventListener("click",()=>clearSlideSelection());
  const num=document.createElement("span");
  num.className="slide-number";
  num.textContent=`${currentSlide+1} / ${currentDeck.slides.length}`;
  root.appendChild(num);
  enableDeckEditorButtons();
  clearSlideSelection();
}

function makeDraggableSlideElement(node,model){
  let dragging=false,startX=0,startY=0,startLeft=0,startTop=0;
  node.addEventListener("pointerdown",e=>{
    dragging=true;startX=e.clientX;startY=e.clientY;
    const root=document.getElementById("slideRenderRoot");
    const rect=root.getBoundingClientRect();
    startLeft=model.x;startTop=model.y;
    node.setPointerCapture(e.pointerId);
    e.preventDefault();
    node.dataset.rootW=rect.width;node.dataset.rootH=rect.height;
  });
  node.addEventListener("pointermove",e=>{
    if(!dragging)return;
    const dx=(e.clientX-startX)/Number(node.dataset.rootW)*100;
    const dy=(e.clientY-startY)/Number(node.dataset.rootH)*100;
    model.x=Math.max(0,Math.min(95,startLeft+dx));
    model.y=Math.max(0,Math.min(92,startTop+dy));
    node.style.left=model.x+"%";node.style.top=model.y+"%";
  });
  node.addEventListener("pointerup",()=>dragging=false);
}

function selectSlideElement(model,node){
  selectedSlideElement={model,node};
  document.querySelectorAll(".slide-element").forEach(x=>x.classList.toggle("selected",x===node));
  document.getElementById("propertiesEmpty").classList.add("hidden");
  document.getElementById("propertiesControls").classList.remove("hidden");
  document.getElementById("propText").value=model.text||"";
  document.getElementById("propFontSize").value=model.fontSize||28;
  document.getElementById("propFontSizeValue").textContent=(model.fontSize||28)+" px";
  document.getElementById("propAlign").value=model.align||"left";
  document.getElementById("propColor").value=normalizeColor(model.color||"#ffffff");
  document.getElementById("propWidth").value=model.w||80;
  document.getElementById("propWidthValue").textContent=(model.w||80)+"%";
}
function clearSlideSelection(){
  selectedSlideElement=null;
  document.querySelectorAll(".slide-element").forEach(x=>x.classList.remove("selected"));
  document.getElementById("propertiesEmpty").classList.remove("hidden");
  document.getElementById("propertiesControls").classList.add("hidden");
}
function normalizeColor(c){
  if(/^#[0-9a-f]{6}$/i.test(c))return c;
  return "#ffffff";
}

document.getElementById("propText").addEventListener("input",e=>{
  if(!selectedSlideElement)return;
  selectedSlideElement.model.text=e.target.value;
  selectedSlideElement.node.textContent=e.target.value;
  const s=currentDeck.slides[currentSlide];
  if(selectedSlideElement.model.id==="title")s.title=e.target.value;
  if(selectedSlideElement.model.id==="body")s.body=e.target.value;
});
document.getElementById("propFontSize").addEventListener("input",e=>{
  if(!selectedSlideElement)return;
  const v=Number(e.target.value); selectedSlideElement.model.fontSize=v;selectedSlideElement.node.style.fontSize=v+"px";
  document.getElementById("propFontSizeValue").textContent=v+" px";
});
document.getElementById("propAlign").addEventListener("change",e=>{
  if(!selectedSlideElement)return;selectedSlideElement.model.align=e.target.value;selectedSlideElement.node.style.textAlign=e.target.value;
});
document.getElementById("propColor").addEventListener("input",e=>{
  if(!selectedSlideElement)return;selectedSlideElement.model.color=e.target.value;selectedSlideElement.node.style.color=e.target.value;
});
document.getElementById("propWidth").addEventListener("input",e=>{
  if(!selectedSlideElement)return;
  const v=Number(e.target.value);selectedSlideElement.model.w=v;selectedSlideElement.node.style.width=v+"%";
  document.getElementById("propWidthValue").textContent=v+"%";
});
document.getElementById("bringForwardBtn").addEventListener("click",()=>{
  if(!selectedSlideElement)return;
  selectedSlideElement.model.z=++zCounter;selectedSlideElement.node.style.zIndex=String(zCounter);
});

document.getElementById("addSlideBtn").addEventListener("click",()=>{
  if(!currentDeck)return;
  currentDeck.slides.splice(currentSlide+1,0,{title:"Nieuwe slide",body:"Voeg hier je kernboodschap toe.",layout:"content"});
  currentSlide++;renderDeck();
});
document.getElementById("duplicateSlideBtn").addEventListener("click",()=>{
  if(!currentDeck)return;
  const copy=JSON.parse(JSON.stringify(currentDeck.slides[currentSlide]));
  copy.title=(copy.title||"Slide")+" kopie";
  if(copy.elements)copy.elements=copy.elements.map((e,i)=>({...e,id:e.id+"_"+Date.now()+"_"+i}));
  currentDeck.slides.splice(currentSlide+1,0,copy);currentSlide++;renderDeck();
});
document.getElementById("deleteSlideBtn").addEventListener("click",()=>{
  if(!currentDeck||currentDeck.slides.length<=1)return alert("Een presentatie moet minstens één slide bevatten.");
  currentDeck.slides.splice(currentSlide,1);currentSlide=Math.max(0,currentSlide-1);renderDeck();
});

document.getElementById("slideAiBtn").addEventListener("click",async()=>{
  if(!currentDeck)return;
  const prompt=document.getElementById("slideAiPrompt").value.trim();
  if(!prompt)return alert("Typ wat je aan deze slide wilt verbeteren.");
  const btn=document.getElementById("slideAiBtn");btn.disabled=true;btn.textContent="AI denkt…";
  try{
    const data=await studioFetch("/api/studio/design-edit",{
      kind:"slide",
      instruction:prompt,
      content:currentDeck.slides[currentSlide],
      context:{deck_title:currentDeck.title,style:currentDeck.style},
      profile
    });
    const s=currentDeck.slides[currentSlide];
    if(data.title)s.title=data.title;
    if(data.body)s.body=data.body;
    s.elements=null;
    renderDeck();
  }catch(err){
    alert("AI Design Assist is niet bereikbaar: "+err.message);
  }finally{
    btn.disabled=false;btn.textContent="Verbeter deze slide";
  }
});

/* ---------- POSTER LAYER EDITOR ---------- */

function makePosterLayerDraggable(node){
  let dragging=false,startX=0,startY=0,startLeft=0,startTop=0;
  node.addEventListener("pointerdown",e=>{
    dragging=true;startX=e.clientX;startY=e.clientY;
    const canvas=document.getElementById("posterCanvas");
    const c=canvas.getBoundingClientRect();
    const n=node.getBoundingClientRect();
    startLeft=(n.left-c.left)/c.width*100;
    startTop=(n.top-c.top)/c.height*100;
    node.setPointerCapture(e.pointerId);
    node.dataset.cw=c.width;node.dataset.ch=c.height;
    selectPosterLayer(node);
    e.preventDefault();
  });
  node.addEventListener("pointermove",e=>{
    if(!dragging)return;
    const dx=(e.clientX-startX)/Number(node.dataset.cw)*100;
    const dy=(e.clientY-startY)/Number(node.dataset.ch)*100;
    node.style.left=Math.max(0,Math.min(95,startLeft+dx))+"%";
    node.style.top=Math.max(0,Math.min(94,startTop+dy))+"%";
  });
  node.addEventListener("pointerup",()=>dragging=false);
}
document.querySelectorAll(".poster-layer").forEach(makePosterLayerDraggable);

function selectPosterLayer(node){
  selectedPosterLayer=node;
  document.querySelectorAll(".poster-layer,.poster-image-layer").forEach(x=>x.classList.toggle("selected",x===node));
  document.getElementById("posterNoSelection").classList.add("hidden");
  document.getElementById("posterPropControls").classList.remove("hidden");
  document.getElementById("posterDeleteLayerBtn").disabled=["brand","title","subtitle"].includes(node.dataset.posterLayer||"");
  const isText=node.classList.contains("poster-layer");
  document.getElementById("posterLayerText").disabled=!isText;
  document.getElementById("posterLayerText").value=isText?node.textContent:"[Afbeelding]";
  const size=parseInt(getComputedStyle(node).fontSize)||40;
  document.getElementById("posterLayerSize").value=Math.min(100,Math.max(10,size));
  document.getElementById("posterLayerSizeValue").textContent=size+" px";
  document.getElementById("posterLayerColor").value=isText?rgbToHex(getComputedStyle(node).color):"#ffffff";
  document.getElementById("posterLayerColor").disabled=!isText;
  document.getElementById("posterLayerAlign").value=isText?(getComputedStyle(node).textAlign||"left"):"left";
  document.getElementById("posterLayerAlign").disabled=!isText;
}
function rgbToHex(rgb){
  const m=String(rgb).match(/\d+/g);if(!m||m.length<3)return "#ffffff";
  return "#"+m.slice(0,3).map(x=>Number(x).toString(16).padStart(2,"0")).join("");
}
document.getElementById("posterCanvas").addEventListener("click",e=>{
  if(e.target.id==="posterCanvas"||e.target.id==="posterArt"){
    selectedPosterLayer=null;
    document.querySelectorAll(".poster-layer,.poster-image-layer").forEach(x=>x.classList.remove("selected"));
    document.getElementById("posterNoSelection").classList.remove("hidden");
    document.getElementById("posterPropControls").classList.add("hidden");
    document.getElementById("posterDeleteLayerBtn").disabled=true;
  }
});
document.getElementById("posterLayerText").addEventListener("input",e=>{if(selectedPosterLayer?.classList.contains("poster-layer"))selectedPosterLayer.textContent=e.target.value;});
document.getElementById("posterLayerSize").addEventListener("input",e=>{
  if(!selectedPosterLayer)return;const v=Number(e.target.value);selectedPosterLayer.style.fontSize=v+"px";document.getElementById("posterLayerSizeValue").textContent=v+" px";
});
document.getElementById("posterLayerColor").addEventListener("input",e=>{if(selectedPosterLayer?.classList.contains("poster-layer"))selectedPosterLayer.style.color=e.target.value;});
document.getElementById("posterLayerAlign").addEventListener("change",e=>{if(selectedPosterLayer?.classList.contains("poster-layer"))selectedPosterLayer.style.textAlign=e.target.value;});

document.getElementById("posterAddTextBtn").addEventListener("click",()=>{
  const n=document.createElement("div");
  n.className="poster-layer";
  n.dataset.posterLayer="custom-"+Date.now();
  n.textContent="Nieuwe tekst";
  Object.assign(n.style,{left:"10%",top:"45%",width:"70%",fontSize:"28px",color:"#ffffff",zIndex:String(++zCounter)});
  document.getElementById("posterCanvas").appendChild(n);
  makePosterLayerDraggable(n);selectPosterLayer(n);
});
document.getElementById("posterUploadImage").addEventListener("change",e=>{
  const file=e.target.files?.[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=()=>{
    const wrap=document.createElement("div");
    wrap.className="poster-image-layer";
    wrap.dataset.posterLayer="image-"+Date.now();
    Object.assign(wrap.style,{left:"52%",top:"18%",width:"35%",height:"32%",zIndex:String(++zCounter)});
    wrap.innerHTML=`<img src="${reader.result}" alt="">`;
    document.getElementById("posterCanvas").appendChild(wrap);
    makePosterLayerDraggable(wrap);selectPosterLayer(wrap);
  };
  reader.readAsDataURL(file);
  e.target.value="";
});
document.getElementById("posterDeleteLayerBtn").addEventListener("click",()=>{
  if(!selectedPosterLayer)return;
  selectedPosterLayer.remove();selectedPosterLayer=null;
  document.getElementById("posterNoSelection").classList.remove("hidden");
  document.getElementById("posterPropControls").classList.add("hidden");
  document.getElementById("posterDeleteLayerBtn").disabled=true;
});

const oldUpdatePosterPreview=updatePosterPreview;
updatePosterPreview=function(){
  oldUpdatePosterPreview();
  const title=document.querySelector('[data-poster-layer="title"]');
  const sub=document.querySelector('[data-poster-layer="subtitle"]');
  if(title)title.textContent=document.getElementById("posterTitle").value||"Jouw titel";
  if(sub)sub.textContent=document.getElementById("posterSubtitle").value||"Subtekst verschijnt hier.";
}

document.getElementById("posterAiBtn").addEventListener("click",async()=>{
  const instruction=document.getElementById("posterAiPrompt").value.trim();
  if(!instruction)return alert("Typ hoe je de poster wilt verbeteren.");
  const btn=document.getElementById("posterAiBtn");btn.disabled=true;btn.textContent="AI denkt…";
  try{
    const data=await studioFetch("/api/studio/design-edit",{
      kind:"poster",
      instruction,
      content:{
        title:document.getElementById("posterTitle").value,
        subtitle:document.getElementById("posterSubtitle").value,
        visual:document.getElementById("posterVisual").value
      },
      profile
    });
    if(data.title){document.getElementById("posterTitle").value=data.title;}
    if(data.subtitle){document.getElementById("posterSubtitle").value=data.subtitle;}
    if(data.visual){document.getElementById("posterVisual").value=data.visual;}
    updatePosterPreview();
  }catch(err){alert("AI Design Assist is niet bereikbaar: "+err.message);}
  finally{btn.disabled=false;btn.textContent="Verbeter posterconcept";}
});

setTimeout(enableDeckEditorButtons,0);


/* =====================================
   STUDENTOS V10 — PROJECTS + ADVANCED EDITOR
   ===================================== */

const PROJECTS_KEY="studentos_v10_projects";
let projects=JSON.parse(localStorage.getItem(PROJECTS_KEY)||"[]");
let activeProjectId=null;
let historyStack=[];
let redoStack=[];
let posterPages=[];
let currentPosterPage=0;

let projectCloudTimer=null;
function saveProjects(){
  localStorage.setItem(PROJECTS_KEY,JSON.stringify(projects));
  document.getElementById("saveState").textContent=currentUser&&cloudReady?"Cloud autosave…":"Lokaal opgeslagen";
  renderProjects();
  if(currentUser&&cloudReady){
    clearTimeout(projectCloudTimer);
    projectCloudTimer=setTimeout(()=>pushCloudProjects().catch(err=>{console.warn(err);showSyncToast("Project cloudsync mislukt","error");}),650);
  }
}
function setDirty(){
  document.getElementById("saveState").textContent="Niet opgeslagen";
}
function projectTypeLabel(type){
  return {presentation:"Presentatie",poster:"Poster",report:"Verslag"}[type]||"Project";
}
function iconForType(type){return {presentation:"📊",poster:"🎨",report:"📝"}[type]||"📁";}

function snapshotEditor(){
  const state={
    deck:currentDeck?JSON.parse(JSON.stringify(currentDeck)):null,
    slide:currentSlide,
    posterPages:posterPages?JSON.parse(JSON.stringify(posterPages)):[],
    posterPage:currentPosterPage
  };
  historyStack.push(state);
  if(historyStack.length>40)historyStack.shift();
  redoStack=[];
}
function restoreState(state){
  if(!state)return;
  currentDeck=state.deck;
  currentSlide=state.slide||0;
  posterPages=state.posterPages||[];
  currentPosterPage=state.posterPage||0;
  if(currentDeck)renderDeck();
  if(posterPages.length)renderPosterPage();
}
function undoEditor(){
  if(!historyStack.length)return;
  const current={
    deck:currentDeck?JSON.parse(JSON.stringify(currentDeck)):null,
    slide:currentSlide,
    posterPages:JSON.parse(JSON.stringify(posterPages||[])),
    posterPage:currentPosterPage
  };
  redoStack.push(current);
  restoreState(historyStack.pop());
}
function redoEditor(){
  if(!redoStack.length)return;
  const current={
    deck:currentDeck?JSON.parse(JSON.stringify(currentDeck)):null,
    slide:currentSlide,
    posterPages:JSON.parse(JSON.stringify(posterPages||[])),
    posterPage:currentPosterPage
  };
  historyStack.push(current);
  restoreState(redoStack.pop());
}
document.getElementById("undoBtn").onclick=undoEditor;
document.getElementById("redoBtn").onclick=redoEditor;

function createProject(type,name){
  const id=(crypto.randomUUID?crypto.randomUUID():String(Date.now()));
  const p={
    id,type,
    name:name||`Nieuwe ${projectTypeLabel(type)}`,
    created_at:new Date().toISOString(),
    updated_at:new Date().toISOString(),
    data:{}
  };
  projects.unshift(p);activeProjectId=id;
  document.getElementById("activeProjectName").value=p.name;
  saveProjects();
  return p;
}
function getActiveProject(){return projects.find(p=>p.id===activeProjectId);}
function saveActiveProject(){
  let p=getActiveProject();
  if(!p){
    p=createProject(studioTab==="presentation"?"presentation":studioTab==="poster"?"poster":studioTab==="report"?"report":"presentation");
  }
  p.name=document.getElementById("activeProjectName").value.trim()||p.name;
  p.updated_at=new Date().toISOString();
  if(p.type==="presentation"){
    p.data={deck:currentDeck,currentSlide};
  } else if(p.type==="poster"){
    capturePosterPage();
    p.data={pages:posterPages,currentPage:currentPosterPage};
  } else if(p.type==="report"){
    p.data={
      prompt:document.getElementById("reportPrompt")?.value||"",
      output:document.getElementById("reportOutput")?.innerHTML||""
    };
  }
  saveProjects();
}
document.getElementById("saveProjectBtn").onclick=saveActiveProject;
document.getElementById("activeProjectName").addEventListener("input",setDirty);

function renderProjects(){
  const grid=document.getElementById("projectGrid"); if(!grid)return;
  let list=[...projects];
  const q=(document.getElementById("projectSearch")?.value||"").toLowerCase();
  const type=document.getElementById("projectTypeFilter")?.value||"all";
  const sort=document.getElementById("projectSort")?.value||"recent";
  list=list.filter(p=>(type==="all"||p.type===type)&&p.name.toLowerCase().includes(q));
  if(sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
  else if(sort==="oldest")list.sort((a,b)=>a.updated_at.localeCompare(b.updated_at));
  else list.sort((a,b)=>b.updated_at.localeCompare(a.updated_at));
  if(!list.length){grid.innerHTML='<div class="empty">Nog geen projecten. Maak je eerste presentatie, poster of verslag.</div>';return;}
  grid.innerHTML=list.map(p=>`
    <article class="project-card">
      <div class="project-preview ${p.type}">
        <span class="project-type-tag">${projectTypeLabel(p.type)}</span>
        ${iconForType(p.type)}
      </div>
      <div class="project-info">
        <h4>${escapeHtml(p.name)}</h4>
        <small>Laatst gewijzigd ${formatDateTime(p.updated_at)}</small>
      </div>
      <div class="project-actions">
        <button class="open" data-open-project="${p.id}">Open</button>
        <button data-duplicate-project="${p.id}">Dupliceer</button>
        <button data-delete-project="${p.id}">Verwijder</button>
      </div>
    </article>`).join("");
  document.querySelectorAll("[data-open-project]").forEach(b=>b.onclick=()=>openProject(b.dataset.openProject));
  document.querySelectorAll("[data-duplicate-project]").forEach(b=>b.onclick=()=>duplicateProject(b.dataset.duplicateProject));
  document.querySelectorAll("[data-delete-project]").forEach(b=>b.onclick=()=>deleteProject(b.dataset.deleteProject));
}
document.getElementById("projectSearch")?.addEventListener("input",renderProjects);
document.getElementById("projectTypeFilter")?.addEventListener("change",renderProjects);
document.getElementById("projectSort")?.addEventListener("change",renderProjects);

document.querySelectorAll("[data-new-project]").forEach(b=>b.onclick=()=>{
  const type=b.dataset.newProject;
  const p=createProject(type);
  if(type==="presentation"){
    studioTab="presentation";
    currentDeck=demoDeck("Nieuwe presentatie",8);
    currentDeck.template="minimal";currentDeck.theme="dark";currentSlide=0;
    renderDeck();
  } else if(type==="poster"){
    studioTab="poster";
    initPosterPages(true);
  } else {
    studioTab="report";
    document.getElementById("reportPrompt").value="";
    document.getElementById("reportOutput").innerHTML='<div class="empty">Schrijf of genereer hier je verslag.</div>';
  }
  goView("studio");
  switchStudioTab(type==="presentation"?"presentation":type==="poster"?"poster":"report");
});

function switchStudioTab(tab){
  studioTab=tab;
  document.querySelectorAll("[data-studio-tab]").forEach(x=>x.classList.toggle("active",x.dataset.studioTab===tab));
  document.querySelectorAll(".studio-pane").forEach(x=>x.classList.add("hidden"));
  document.getElementById("studio-"+tab).classList.remove("hidden");
}
function openProject(id){
  const p=projects.find(x=>x.id===id); if(!p)return;
  activeProjectId=id;
  document.getElementById("activeProjectName").value=p.name;
  historyStack=[];redoStack=[];
  if(p.type==="presentation"){
    currentDeck=p.data.deck||demoDeck(p.name,8);currentSlide=p.data.currentSlide||0;renderDeck();switchStudioTab("presentation");
  }else if(p.type==="poster"){
    posterPages=p.data.pages||[];currentPosterPage=p.data.currentPage||0;if(!posterPages.length)initPosterPages(true);renderPosterPage();switchStudioTab("poster");
  }else{
    document.getElementById("reportPrompt").value=p.data.prompt||"";
    document.getElementById("reportOutput").innerHTML=p.data.output||'<div class="empty">Geen inhoud.</div>';
    switchStudioTab("report");
  }
  goView("studio");
  document.getElementById("saveState").textContent="Opgeslagen";
}
function duplicateProject(id){
  const p=projects.find(x=>x.id===id);if(!p)return;
  const copy=JSON.parse(JSON.stringify(p));
  copy.id=(crypto.randomUUID?crypto.randomUUID():String(Date.now()));
  copy.name=p.name+" kopie";
  copy.created_at=copy.updated_at=new Date().toISOString();
  projects.unshift(copy);saveProjects();
}
async function deleteProject(id){
  const p=projects.find(x=>x.id===id);if(!p)return;
  if(!confirm(`Verwijder "${p.name}"?`))return;
  projects=projects.filter(x=>x.id!==id);
  if(activeProjectId===id)activeProjectId=null;
  localStorage.setItem(PROJECTS_KEY,JSON.stringify(projects));
  renderProjects();
  if(currentUser&&supabaseClient&&isUuid(id)){
    const {error}=await supabaseClient.from("projects").delete().eq("id",id).eq("user_id",currentUser.id);
    if(error)showSyncToast("Cloud verwijderen mislukt","error");
    else showSyncToast("Project verwijderd");
  }
}



function isUuid(v){return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v||""));}
function ensureProjectUuids(){
  projects=projects.map(p=>{
    if(isUuid(p.id))return p;
    const newId=(crypto.randomUUID?crypto.randomUUID():p.id);
    return {...p,id:newId};
  });
  localStorage.setItem(PROJECTS_KEY,JSON.stringify(projects));
}
async function pushCloudProjects(){
  if(!currentUser||!supabaseClient)return;
  ensureProjectUuids();
  if(!projects.length){document.getElementById("saveState").textContent="Cloud gesynchroniseerd";return;}
  const rows=projects.filter(p=>isUuid(p.id)).map(p=>({
    id:p.id,user_id:currentUser.id,project_type:p.type,name:p.name,
    project_data:p.data||{},created_at:p.created_at||new Date().toISOString(),updated_at:p.updated_at||new Date().toISOString()
  }));
  const {error}=await supabaseClient.from("projects").upsert(rows,{onConflict:"id"});
  if(error)throw error;
  document.getElementById("saveState").textContent="Cloud gesynchroniseerd";
  showSyncToast("Projecten in cloud opgeslagen");
}
async function pullCloudProjects(){
  if(!currentUser||!supabaseClient)return;
  const {data,error}=await supabaseClient.from("projects").select("*").eq("user_id",currentUser.id).order("updated_at",{ascending:false});
  if(error)throw error;
  const remote=(data||[]).map(r=>({id:r.id,type:r.project_type,name:r.name,data:r.project_data||{},created_at:r.created_at,updated_at:r.updated_at}));
  const merged=new Map();
  [...projects,...remote].forEach(p=>{
    const prev=merged.get(p.id);
    if(!prev||new Date(p.updated_at||0)>=new Date(prev.updated_at||0))merged.set(p.id,p);
  });
  projects=[...merged.values()].sort((a,b)=>new Date(b.updated_at)-new Date(a.updated_at));
  localStorage.setItem(PROJECTS_KEY,JSON.stringify(projects));
  renderProjects();
}

const originalStudioClickers=[...document.querySelectorAll("[data-studio-tab]")];
originalStudioClickers.forEach(btn=>btn.addEventListener("click",()=>setDirty()));

function addSlideElement(model){
  const s=currentDeck?.slides?.[currentSlide];if(!s)return;
  if(!s.elements)s.elements=[];
  s.elements.push(model);renderDeck();setDirty();
}

document.getElementById("addTextBtn").onclick=()=>{
  if(!currentDeck)return;snapshotEditor();
  addSlideElement({id:"text_"+Date.now(),type:"text",text:"Nieuwe tekst",x:12,y:25,w:50,fontSize:24,color:"#ffffff",align:"left",z:++zCounter});
};
document.getElementById("addShapeBtn").onclick=()=>{
  if(!currentDeck)return;snapshotEditor();
  addSlideElement({id:"shape_"+Date.now(),type:"shape",shape:"rect",x:15,y:35,w:28,h:18,fill:"#6d5dfc",opacity:100,z:++zCounter});
};
document.getElementById("slideUploadImage").addEventListener("change",e=>{
  const f=e.target.files?.[0];if(!f||!currentDeck)return;
  snapshotEditor();
  const r=new FileReader();
  r.onload=()=>addSlideElement({id:"image_"+Date.now(),type:"image",src:r.result,x:55,y:20,w:34,h:45,opacity:100,z:++zCounter});
  r.readAsDataURL(f);e.target.value="";
});
document.getElementById("addTableBtn").onclick=()=>{
  if(!currentDeck)return;snapshotEditor();
  addSlideElement({id:"table_"+Date.now(),type:"table",x:12,y:45,w:64,h:28,rows:[["Onderdeel","Waarde"],["A","10"],["B","20"],["C","30"]],fill:"#ffffff",opacity:100,z:++zCounter});
};
document.getElementById("addChartBtn").onclick=()=>{
  if(!currentDeck)return;snapshotEditor();
  addSlideElement({id:"chart_"+Date.now(),type:"chart",x:48,y:34,w:38,h:35,values:[35,65,48,82],fill:"#c9ff6a",opacity:100,z:++zCounter});
};

const v9RenderDeck=renderDeck;
renderDeck=function(){
  if(!currentDeck?.slides?.length)return v9RenderDeck();
  document.getElementById("presentationTemplate").value=currentDeck.template||"minimal";
  document.getElementById("presentationTheme").value=currentDeck.theme||currentDeck.style==="academic"?"light":"dark";
  document.getElementById("deckTitle").textContent=currentDeck.title||"Presentatie";
  document.getElementById("deckStatus").textContent=currentDeck.slides.length+" slides";
  document.getElementById("slideThumbs").innerHTML=currentDeck.slides.map((s,i)=>`
    <button class="slide-thumb ${i===currentSlide?"active":""}" data-slide-index="${i}">
      <strong>${i+1}. ${escapeHtml(s.title||"")}</strong>
      <p>${escapeHtml((s.body||"").slice(0,90))}</p>
    </button>`).join("");
  document.querySelectorAll("[data-slide-index]").forEach(b=>b.onclick=()=>{currentSlide=Number(b.dataset.slideIndex);renderDeck();});
  const s=currentDeck.slides[currentSlide];
  if(!s.elements){
    const light=(currentDeck.theme||"dark")==="light";
    s.elements=[
      {id:"title",type:"text",text:s.title||"",x:8,y:18,w:82,fontSize:currentSlide===0?48:38,color:light?"#17191f":"#ffffff",align:"left",z:2},
      {id:"body",type:"text",text:s.body||"",x:8,y:48,w:76,fontSize:18,color:light?"#4e5562":"#d8d9e1",align:"left",z:1}
    ];
  }
  const canvas=document.getElementById("slideCanvas");
  canvas.innerHTML=`<div class="slide-render ${themeClass(currentDeck.theme||"dark")}" id="slideRenderRoot"></div>`;
  const root=document.getElementById("slideRenderRoot");
  s.elements.forEach(el=>{
    let node;
    if(el.type==="text"){
      node=document.createElement("div");node.className="slide-element";node.textContent=el.text||"";
      Object.assign(node.style,{left:el.x+"%",top:el.y+"%",width:el.w+"%",fontSize:(el.fontSize||24)+"px",color:el.color||"#fff",textAlign:el.align||"left",zIndex:String(el.z||1),opacity:String((el.opacity||100)/100)});
    } else if(el.type==="shape"){
      node=document.createElement("div");node.className="slide-shape";
      Object.assign(node.style,{left:el.x+"%",top:el.y+"%",width:el.w+"%",height:(el.h||18)+"%",background:el.fill||"#6d5dfc",zIndex:String(el.z||1),opacity:String((el.opacity||100)/100),borderRadius:"8px"});
    } else if(el.type==="image"){
      node=document.createElement("div");node.className="slide-image";node.innerHTML=`<img src="${el.src}" alt="">`;
      Object.assign(node.style,{left:el.x+"%",top:el.y+"%",width:el.w+"%",height:(el.h||40)+"%",zIndex:String(el.z||1),opacity:String((el.opacity||100)/100),borderRadius:"8px"});
    } else if(el.type==="table"){
      node=document.createElement("div");node.className="slide-table";node.innerHTML=`<table>${(el.rows||[]).map(r=>`<tr>${r.map(c=>`<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")}</table>`;
      Object.assign(node.style,{left:el.x+"%",top:el.y+"%",width:el.w+"%",height:(el.h||28)+"%",zIndex:String(el.z||1),opacity:String((el.opacity||100)/100)});
    } else if(el.type==="chart"){
      node=document.createElement("div");node.className="slide-chart";node.innerHTML=`<div class="mini-chart">${(el.values||[30,60,45]).map(v=>`<span style="height:${v}%;background:${el.fill||"#c9ff6a"}"></span>`).join("")}</div>`;
      Object.assign(node.style,{left:el.x+"%",top:el.y+"%",width:el.w+"%",height:(el.h||35)+"%",zIndex:String(el.z||1),opacity:String((el.opacity||100)/100)});
    }
    if(!node)return;
    node.dataset.elementId=el.id;
    root.appendChild(node);
    makeUniversalDraggable(node,el);
    node.addEventListener("click",ev=>{ev.stopPropagation();selectAdvancedSlideElement(el,node);});
  });
  root.addEventListener("click",()=>clearSlideSelection());
  const num=document.createElement("span");num.className="slide-number";num.textContent=`${currentSlide+1} / ${currentDeck.slides.length}`;root.appendChild(num);
  enableDeckEditorButtonsV10();
  clearSlideSelection();
}
function themeClass(theme){
  if(theme==="light")return "light";
  if(theme==="lime")return "theme-lime";
  if(theme==="violet")return "theme-violet";
  return "";
}
function makeUniversalDraggable(node,model){
  let drag=false,sx=0,sy=0,sl=0,st=0;
  node.addEventListener("pointerdown",e=>{
    drag=true;sx=e.clientX;sy=e.clientY;sl=model.x;st=model.y;
    const r=document.getElementById("slideRenderRoot").getBoundingClientRect();
    node.dataset.rw=r.width;node.dataset.rh=r.height;
    node.setPointerCapture(e.pointerId);e.preventDefault();
    snapshotEditor();
  });
  node.addEventListener("pointermove",e=>{
    if(!drag)return;
    model.x=Math.max(0,Math.min(95,sl+(e.clientX-sx)/Number(node.dataset.rw)*100));
    model.y=Math.max(0,Math.min(92,st+(e.clientY-sy)/Number(node.dataset.rh)*100));
    node.style.left=model.x+"%";node.style.top=model.y+"%";setDirty();
  });
  node.addEventListener("pointerup",()=>drag=false);
}
function selectAdvancedSlideElement(model,node){
  selectedSlideElement={model,node};
  document.querySelectorAll(".slide-element,.slide-shape,.slide-image,.slide-table,.slide-chart").forEach(x=>x.classList.toggle("selected",x===node));
  document.getElementById("propertiesEmpty").classList.add("hidden");
  document.getElementById("propertiesControls").classList.remove("hidden");
  const isText=model.type==="text";
  document.getElementById("propText").disabled=!isText;
  document.getElementById("propText").value=isText?(model.text||""):`[${model.type}]`;
  document.getElementById("propFontSize").disabled=!isText;
  document.getElementById("propAlign").disabled=!isText;
  document.getElementById("propColor").disabled=!isText;
  document.getElementById("propFontSize").value=model.fontSize||24;
  document.getElementById("propFontSizeValue").textContent=(model.fontSize||24)+" px";
  document.getElementById("propAlign").value=model.align||"left";
  document.getElementById("propColor").value=normalizeColor(model.color||"#ffffff");
  document.getElementById("propWidth").value=model.w||50;
  document.getElementById("propWidthValue").textContent=(model.w||50)+"%";
  document.getElementById("propFill").value=normalizeColor(model.fill||"#6d5dfc");
  document.getElementById("propOpacity").value=model.opacity||100;
  document.getElementById("propOpacityValue").textContent=(model.opacity||100)+"%";
}
function enableDeckEditorButtonsV10(){
  const enabled=Boolean(currentDeck?.slides?.length);
  ["addSlideBtn","addTextBtn","addShapeBtn","addTableBtn","addChartBtn","duplicateSlideBtn","deleteSlideBtn","slideAiBtn"].forEach(id=>{
    const el=document.getElementById(id);if(el)el.disabled=!enabled;
  });
}
document.getElementById("propFill").addEventListener("input",e=>{
  if(!selectedSlideElement)return;selectedSlideElement.model.fill=e.target.value;
  if(selectedSlideElement.model.type==="shape")selectedSlideElement.node.style.background=e.target.value;
  if(selectedSlideElement.model.type==="chart"){
    selectedSlideElement.node.querySelectorAll(".mini-chart span").forEach(x=>x.style.background=e.target.value);
  }
  setDirty();
});
document.getElementById("propOpacity").addEventListener("input",e=>{
  if(!selectedSlideElement)return;const v=Number(e.target.value);selectedSlideElement.model.opacity=v;selectedSlideElement.node.style.opacity=String(v/100);document.getElementById("propOpacityValue").textContent=v+"%";setDirty();
});
document.getElementById("deleteElementBtn").onclick=()=>{
  if(!selectedSlideElement||!currentDeck)return;snapshotEditor();
  const s=currentDeck.slides[currentSlide];
  s.elements=s.elements.filter(e=>e.id!==selectedSlideElement.model.id);renderDeck();setDirty();
};

document.getElementById("presentationTemplate").addEventListener("change",e=>{if(currentDeck){snapshotEditor();currentDeck.template=e.target.value;setDirty();renderDeck();}});
document.getElementById("presentationTheme").addEventListener("change",e=>{if(currentDeck){snapshotEditor();currentDeck.theme=e.target.value;setDirty();renderDeck();}});

const originalPresentationBtn=document.getElementById("presentationBtn");
originalPresentationBtn.addEventListener("click",()=>setTimeout(()=>{
  if(currentDeck){
    currentDeck.template=document.getElementById("presentationTemplate").value;
    currentDeck.theme=document.getElementById("presentationTheme").value;
    if(!activeProjectId)createProject("presentation",currentDeck.title||"Presentatie");
    saveActiveProject();
  }
},700));

/* --------- POSTER MULTI-PAGE --------- */

function serializePosterCanvas(){
  const canvas=document.getElementById("posterCanvas");
  const layers=[...canvas.querySelectorAll(".poster-layer,.poster-image-layer")].map(n=>({
    cls:n.className,
    layer:n.dataset.posterLayer||"",
    text:n.classList.contains("poster-layer")?n.textContent:"",
    html:n.classList.contains("poster-image-layer")?n.innerHTML:"",
    style:n.getAttribute("style")||""
  }));
  return {
    title:document.getElementById("posterTitle").value,
    subtitle:document.getElementById("posterSubtitle").value,
    visual:document.getElementById("posterVisual").value,
    format:document.getElementById("posterFormat").value,
    template:document.getElementById("posterTemplate").value,
    artStyle:document.getElementById("posterArt").getAttribute("style")||"",
    layers
  };
}
function capturePosterPage(){
  if(!posterPages.length)return;
  posterPages[currentPosterPage]=serializePosterCanvas();
}
function defaultPosterPage(){
  return {
    title:"Jouw titel",subtitle:"Subtekst verschijnt hier.",visual:"",format:"portrait",template:"sports",
    artStyle:"",
    layers:[
      {cls:"poster-layer poster-brand-layer",layer:"brand",text:"StudentOS Studio",html:"",style:"left:8%;top:7%;width:45%;font-size:10px"},
      {cls:"poster-layer poster-title-layer",layer:"title",text:"Jouw titel",html:"",style:"left:8%;top:62%;width:84%;font-size:58px"},
      {cls:"poster-layer poster-subtitle-layer",layer:"subtitle",text:"Subtekst verschijnt hier.",html:"",style:"left:8%;top:82%;width:82%;font-size:18px"}
    ]
  };
}
function initPosterPages(force=false){
  if(force||!posterPages.length){posterPages=[defaultPosterPage()];currentPosterPage=0;}
  renderPosterPage();
}
function renderPosterTabs(){
  const tabs=document.getElementById("posterPageTabs");
  tabs.innerHTML=posterPages.map((_,i)=>`<button class="${i===currentPosterPage?"active":""}" data-poster-page="${i}">Pagina ${i+1}</button>`).join("");
  tabs.querySelectorAll("[data-poster-page]").forEach(b=>b.onclick=()=>{capturePosterPage();currentPosterPage=Number(b.dataset.posterPage);renderPosterPage();});
}
function renderPosterPage(){
  if(!posterPages.length)return initPosterPages(true);
  const p=posterPages[currentPosterPage]||defaultPosterPage();
  document.getElementById("posterTitle").value=p.title||"";
  document.getElementById("posterSubtitle").value=p.subtitle||"";
  document.getElementById("posterVisual").value=p.visual||"";
  document.getElementById("posterFormat").value=p.format||"portrait";
  document.getElementById("posterTemplate").value=p.template||"sports";
  const canvas=document.getElementById("posterCanvas");
  canvas.classList.remove("portrait","square","landscape");canvas.classList.add(p.format||"portrait");
  const art=document.getElementById("posterArt");art.setAttribute("style",p.artStyle||"");
  canvas.querySelectorAll(".poster-layer,.poster-image-layer").forEach(n=>n.remove());
  (p.layers||[]).forEach(l=>{
    const n=document.createElement("div");n.className=l.cls;n.dataset.posterLayer=l.layer;n.setAttribute("style",l.style||"");
    if(n.classList.contains("poster-image-layer"))n.innerHTML=l.html||""; else n.textContent=l.text||"";
    canvas.appendChild(n);makePosterLayerDraggable(n);
  });
  renderPosterTabs();
}
document.getElementById("addPosterPageBtn").onclick=()=>{capturePosterPage();snapshotEditor();posterPages.push(defaultPosterPage());currentPosterPage=posterPages.length-1;renderPosterPage();setDirty();};
document.getElementById("duplicatePosterPageBtn").onclick=()=>{capturePosterPage();snapshotEditor();const c=JSON.parse(JSON.stringify(posterPages[currentPosterPage]));posterPages.splice(currentPosterPage+1,0,c);currentPosterPage++;renderPosterPage();setDirty();};
document.getElementById("deletePosterPageBtn").onclick=()=>{
  if(posterPages.length<=1)return alert("Een posterproject moet minstens één pagina hebben.");
  snapshotEditor();posterPages.splice(currentPosterPage,1);currentPosterPage=Math.max(0,currentPosterPage-1);renderPosterPage();setDirty();
};

["posterTitle","posterSubtitle","posterVisual","posterFormat","posterTemplate"].forEach(id=>{
  document.getElementById(id).addEventListener("input",()=>{capturePosterPage();setDirty();});
  document.getElementById(id).addEventListener("change",()=>{capturePosterPage();setDirty();});
});

const originalPosterBtn=document.getElementById("posterBtn");
originalPosterBtn.addEventListener("click",()=>setTimeout(()=>{
  if(!posterPages.length)initPosterPages(true);
  capturePosterPage();
  if(!activeProjectId)createProject("poster",document.getElementById("posterTitle").value||"Poster");
  saveActiveProject();
},900));

/* --------- THEME STYLES --------- */
const extraThemeStyle=document.createElement("style");
extraThemeStyle.textContent=`
.slide-render.theme-lime{background:linear-gradient(135deg,#141810,#29351c);color:#f7ffe8}
.slide-render.theme-violet{background:linear-gradient(135deg,#211b3d,#6d5dfc);color:#fff}
`;
document.head.appendChild(extraThemeStyle);

/* --------- AUTOSAVE --------- */
let autosaveTimer=null;
function scheduleProjectAutosave(){
  clearTimeout(autosaveTimer);
  autosaveTimer=setTimeout(()=>{if(activeProjectId)saveActiveProject();},1200);
}
document.addEventListener("input",e=>{
  if(document.getElementById("view-studio")?.contains(e.target)){setDirty();scheduleProjectAutosave();}
});
document.addEventListener("change",e=>{
  if(document.getElementById("view-studio")?.contains(e.target)){setDirty();scheduleProjectAutosave();}
});

/* Ensure Projects initially render */
setTimeout(()=>{renderProjects();if(!posterPages.length)initPosterPages(true);},0);


/* =====================================
   STUDENTOS V11 — PRO EDITORS
   ===================================== */

const VERSIONS_KEY="studentos_v11_versions";
let versions=JSON.parse(localStorage.getItem(VERSIONS_KEY)||"{}");
let comments=JSON.parse(localStorage.getItem("studentos_v11_comments")||"{}");
let shareTokens=JSON.parse(localStorage.getItem("studentos_v11_sharetokens")||"{}");

function saveVersions(){localStorage.setItem(VERSIONS_KEY,JSON.stringify(versions));}
function saveComments(){localStorage.setItem("studentos_v11_comments",JSON.stringify(comments));}
function saveShareTokens(){localStorage.setItem("studentos_v11_sharetokens",JSON.stringify(shareTokens));}

function ensureGuides(root){
  if(root.querySelector(".alignment-guide"))return;
  const v=document.createElement("div");v.className="alignment-guide vertical";v.style.left="50%";
  const h=document.createElement("div");h.className="alignment-guide horizontal";h.style.top="50%";
  root.appendChild(v);root.appendChild(h);
}
function showGuides(root,showV,showH){
  ensureGuides(root);
  root.querySelector(".alignment-guide.vertical").style.display=showV?"block":"none";
  root.querySelector(".alignment-guide.horizontal").style.display=showH?"block":"none";
}

function addResizeHandles(node,model){
  node.querySelectorAll(".resize-handle").forEach(x=>x.remove());
  ["se","ne","sw","nw"].forEach(pos=>{
    const h=document.createElement("div");h.className="resize-handle "+pos;node.appendChild(h);
    h.addEventListener("pointerdown",e=>{
      e.stopPropagation();e.preventDefault();
      const root=document.getElementById("slideRenderRoot");
      const rr=root.getBoundingClientRect();
      const start=node.getBoundingClientRect();
      const sx=e.clientX, sy=e.clientY;
      const sw=start.width, sh=start.height;
      const startLeft=model.x,startTop=model.y;
      snapshotEditor();
      h.setPointerCapture(e.pointerId);
      const move=ev=>{
        let dw=ev.clientX-sx,dh=ev.clientY-sy;
        let newW=sw,newH=sh,newX=startLeft,newY=startTop;
        if(pos.includes("e"))newW=Math.max(30,sw+dw);
        if(pos.includes("w")){newW=Math.max(30,sw-dw);newX=startLeft+dw/rr.width*100;}
        if(pos.includes("s"))newH=Math.max(24,sh+dh);
        if(pos.includes("n")){newH=Math.max(24,sh-dh);newY=startTop+dh/rr.height*100;}
        model.w=Math.max(5,Math.min(100,newW/rr.width*100));
        model.h=Math.max(5,Math.min(100,newH/rr.height*100));
        model.x=Math.max(0,Math.min(95,newX));
        model.y=Math.max(0,Math.min(95,newY));
        node.style.width=model.w+"%";node.style.height=model.h+"%";
        node.style.left=model.x+"%";node.style.top=model.y+"%";
        setDirty();
      };
      const up=()=>{h.removeEventListener("pointermove",move);h.removeEventListener("pointerup",up);};
      h.addEventListener("pointermove",move);h.addEventListener("pointerup",up);
    });
  });
}

const v10MakeUniversal=makeUniversalDraggable;
makeUniversalDraggable=function(node,model){
  let drag=false,sx=0,sy=0,sl=0,st=0;
  node.addEventListener("pointerdown",e=>{
    if(e.target.classList.contains("resize-handle"))return;
    drag=true;sx=e.clientX;sy=e.clientY;sl=model.x;st=model.y;
    const r=document.getElementById("slideRenderRoot").getBoundingClientRect();
    node.dataset.rw=r.width;node.dataset.rh=r.height;
    node.setPointerCapture(e.pointerId);e.preventDefault();
    snapshotEditor();
  });
  node.addEventListener("pointermove",e=>{
    if(!drag)return;
    let nx=sl+(e.clientX-sx)/Number(node.dataset.rw)*100;
    let ny=st+(e.clientY-sy)/Number(node.dataset.rh)*100;

    // snapping: center and 10% grid
    let showV=false,showH=false;
    if(Math.abs(nx + (model.w||20)/2 - 50) < 2){nx=50-(model.w||20)/2;showV=true;}
    if(Math.abs(ny + (model.h||10)/2 - 50) < 2){ny=50-(model.h||10)/2;showH=true;}

    nx=Math.round(nx/2)*2;
    ny=Math.round(ny/2)*2;

    model.x=Math.max(0,Math.min(95,nx));
    model.y=Math.max(0,Math.min(92,ny));
    node.style.left=model.x+"%";node.style.top=model.y+"%";
    showGuides(document.getElementById("slideRenderRoot"),showV,showH);
    setDirty();
  });
  node.addEventListener("pointerup",()=>{
    drag=false;
    const root=document.getElementById("slideRenderRoot");
    if(root)showGuides(root,false,false);
  });
}

const v10SelectAdvanced=selectAdvancedSlideElement;
selectAdvancedSlideElement=function(model,node){
  v10SelectAdvanced(model,node);
  if(!model.h){
    const root=document.getElementById("slideRenderRoot")?.getBoundingClientRect();
    const rect=node.getBoundingClientRect();
    if(root)model.h=Math.max(5,rect.height/root.height*100);
  }
  addResizeHandles(node,model);
  document.getElementById("propRotation").value=model.rotation||0;
  document.getElementById("propRotationValue").textContent=(model.rotation||0)+"°";
  document.getElementById("propBoldBtn").classList.toggle("active",Boolean(model.bold));
  document.getElementById("propItalicBtn").classList.toggle("active",Boolean(model.italic));
  document.getElementById("propUnderlineBtn").classList.toggle("active",Boolean(model.underline));
}

document.getElementById("propRotation").addEventListener("input",e=>{
  if(!selectedSlideElement)return;
  const v=Number(e.target.value);
  selectedSlideElement.model.rotation=v;
  selectedSlideElement.node.style.transform=`rotate(${v}deg)`;
  document.getElementById("propRotationValue").textContent=v+"°";
  setDirty();
});
["Bold","Italic","Underline"].forEach(kind=>{
  document.getElementById("prop"+kind+"Btn").addEventListener("click",()=>{
    if(!selectedSlideElement || selectedSlideElement.model.type!=="text")return;
    const key=kind.toLowerCase();
    selectedSlideElement.model[key]=!selectedSlideElement.model[key];
    selectedSlideElement.node.style.fontWeight=selectedSlideElement.model.bold?"800":"400";
    selectedSlideElement.node.style.fontStyle=selectedSlideElement.model.italic?"italic":"normal";
    selectedSlideElement.node.style.textDecoration=selectedSlideElement.model.underline?"underline":"none";
    document.getElementById("prop"+kind+"Btn").classList.toggle("active",selectedSlideElement.model[key]);
    setDirty();
  });
});

const v10RenderDeckV11=renderDeck;
renderDeck=function(){
  v10RenderDeckV11();
  if(!currentDeck?.slides?.length)return;
  const s=currentDeck.slides[currentSlide];
  const root=document.getElementById("slideRenderRoot");
  if(!root)return;
  ensureGuides(root);
  root.querySelectorAll("[data-element-id]").forEach(node=>{
    const model=s.elements?.find(x=>x.id===node.dataset.elementId);
    if(!model)return;
    node.style.transform=`rotate(${model.rotation||0}deg)`;
    if(model.type==="text"){
      node.style.fontWeight=model.bold?"800":"400";
      node.style.fontStyle=model.italic?"italic":"normal";
      node.style.textDecoration=model.underline?"underline":"none";
    }
  });
  document.getElementById("speakerNotes").value=s.notes||"";
  updateV11Buttons();
}

document.getElementById("speakerNotes").addEventListener("input",e=>{
  if(!currentDeck?.slides?.[currentSlide])return;
  currentDeck.slides[currentSlide].notes=e.target.value;
  setDirty();scheduleProjectAutosave();
});

function updateV11Buttons(){
  const enabled=Boolean(currentDeck?.slides?.length && activeProjectId);
  ["versionBtn","shareProjectBtn","exportPdfBtn"].forEach(id=>{
    const el=document.getElementById(id);if(el)el.disabled=!enabled;
  });
}
const oldSaveActiveProjectV11=saveActiveProject;
saveActiveProject=function(){
  oldSaveActiveProjectV11();
  updateV11Buttons();
  renderComments();
};

/* -------- VERSION HISTORY -------- */
function openVersionModal(){
  if(!activeProjectId)return;
  renderVersions();
  document.getElementById("versionModal").classList.remove("hidden");
}
function closeVersionModal(){document.getElementById("versionModal").classList.add("hidden");}
document.getElementById("versionBtn").onclick=openVersionModal;
document.querySelectorAll("[data-close-version]").forEach(x=>x.onclick=closeVersionModal);
document.getElementById("createVersionBtn").onclick=()=>{
  if(!activeProjectId)return;
  saveActiveProject();
  const p=getActiveProject();
  if(!versions[activeProjectId])versions[activeProjectId]=[];
  versions[activeProjectId].unshift({
    id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),
    created_at:new Date().toISOString(),
    name:`Versie ${versions[activeProjectId].length+1}`,
    data:JSON.parse(JSON.stringify(p.data))
  });
  versions[activeProjectId]=versions[activeProjectId].slice(0,20);
  saveVersions();renderVersions();
};
function renderVersions(){
  const list=document.getElementById("versionList");
  const arr=versions[activeProjectId]||[];
  if(!arr.length){list.innerHTML='<div class="empty">Nog geen opgeslagen versies.</div>';return;}
  list.innerHTML=arr.map(v=>`
    <div class="version-item">
      <div><strong>${escapeHtml(v.name)}</strong><small>${formatDateTime(v.created_at)}</small></div>
      <button data-restore-version="${v.id}">Herstel</button>
    </div>`).join("");
  list.querySelectorAll("[data-restore-version]").forEach(b=>b.onclick=()=>{
    const v=arr.find(x=>x.id===b.dataset.restoreVersion);if(!v)return;
    const p=getActiveProject();if(!p)return;
    p.data=JSON.parse(JSON.stringify(v.data));p.updated_at=new Date().toISOString();saveProjects();openProject(p.id);closeVersionModal();
  });
}

/* -------- SHARE LINKS -------- */
document.getElementById("shareProjectBtn").onclick=async()=>{
  if(!activeProjectId)return;
  if(!shareTokens[activeProjectId]){
    shareTokens[activeProjectId]=(crypto.randomUUID?crypto.randomUUID():Math.random().toString(36).slice(2));
    saveShareTokens();
  }
  const token=shareTokens[activeProjectId];
  const fakeLink=`https://studentos.local/share/${token}`;
  try{await navigator.clipboard.writeText(fakeLink);}catch{}
  document.getElementById("shareStatus").textContent="Deellink klaar";
  alert("Prototype deellink gekopieerd:\n"+fakeLink+"\n\nVoor echte publieke share-links is serverhosting nodig.");
};

/* -------- PDF EXPORT -------- */
document.getElementById("exportPdfBtn").onclick=async()=>{
  if(!currentDeck?.slides?.length)return;
  if(!window.jspdf?.jsPDF)return alert("PDF-bibliotheek kon niet laden.");
  const {jsPDF}=window.jspdf;
  const pdf=new jsPDF({orientation:"landscape",unit:"pt",format:"a4"});
  const prev=currentSlide;
  for(let i=0;i<currentDeck.slides.length;i++){
    currentSlide=i;renderDeck();
    await new Promise(r=>setTimeout(r,80));
    const node=document.getElementById("slideCanvas");
    const canvas=await html2canvas(node,{scale:1.5,useCORS:true,backgroundColor:null});
    const img=canvas.toDataURL("image/png");
    if(i>0)pdf.addPage();
    pdf.addImage(img,"PNG",0,0,841.89,595.28);
  }
  currentSlide=prev;renderDeck();
  pdf.save((currentDeck.title||"StudentOS_Presentation").replace(/[^\w\- ]+/g,"").replace(/\s+/g,"_")+".pdf");
};

/* -------- COMMENTS -------- */
document.getElementById("addCommentBtn").onclick=()=>{
  if(!activeProjectId)return alert("Sla het project eerst op.");
  const text=document.getElementById("commentInput").value.trim();if(!text)return;
  if(!comments[activeProjectId])comments[activeProjectId]=[];
  comments[activeProjectId].unshift({
    id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),
    author:profile?.name||"Gebruiker",
    text,
    created_at:new Date().toISOString()
  });
  document.getElementById("commentInput").value="";
  saveComments();renderComments();
};
function renderComments(){
  const el=document.getElementById("commentsList");if(!el)return;
  if(!activeProjectId){el.innerHTML='<div class="empty">Sla eerst een project op om comments te gebruiken.</div>';return;}
  const arr=comments[activeProjectId]||[];
  el.innerHTML=arr.length?arr.map(c=>`
    <div class="comment-item"><strong>${escapeHtml(c.author)}</strong><p>${escapeHtml(c.text)}</p><small>${formatDateTime(c.created_at)}</small></div>
  `).join(""):'<div class="empty">Nog geen comments.</div>';
}

/* Extend export to respect transforms and notes */
setTimeout(()=>{renderComments();updateV11Buttons();},0);



async function refreshSystemStatus(){
  const set=(id,state,text)=>{const dot=document.getElementById(id+"Dot");const t=document.getElementById(id+"Text");if(dot){dot.className="status-dot "+state;}if(t)t.textContent=text;};
  const overall=document.getElementById("systemOverallBadge");
  try{
    const r=await fetch(apiBaseUrl()+"/api/health",{cache:"no-store"});
    if(!r.ok)throw new Error("API offline");
    const h=await r.json();
    set("statusApi","ok",`Online • ${h.version||"StudentOS"}`);
    set("statusAi",h.ai_configured?"ok":"warn",h.ai_configured?`AI actief • ${h.model}`:"AI-key nog niet ingesteld");
    const cloudOk=Boolean(currentUser&&cloudReady);
    set("statusCloud",cloudOk?"ok":cloudReady?"warn":"warn",cloudOk?"Ingelogd en gekoppeld":cloudReady?"Cloud klaar • nog niet ingelogd":"Alleen lokale opslag");
    set("statusProject",cloudOk?"ok":"warn",cloudOk?"Lokaal + cloud autosave":"Lokale autosave actief");
    if(overall){overall.textContent=h.ai_configured?"Online":"Deels klaar";overall.className="mode-pill";}
  }catch(err){
    set("statusApi","bad","Backend niet bereikbaar");
    set("statusAi","warn","Offline fallback beschikbaar");
    set("statusCloud",cloudReady?"warn":"bad",cloudReady?"Cloud mogelijk beschikbaar":"Niet verbonden");
    set("statusProject","warn","Lokale autosave actief");
    if(overall)overall.textContent="Offline-modus";
  }
}
document.getElementById("refreshSystemStatusBtn")?.addEventListener("click",()=>refreshSystemStatus());


/* =====================================
   STUDENTOS V14 — SIGNATURE EXPERIENCE
   ===================================== */
function setAppActiveV14(active){ document.body.classList.toggle('app-active',active); }
const initBeforeV14 = init;
init = function(){ initBeforeV14(); setAppActiveV14(Boolean(profile)); };
setAppActiveV14(Boolean(profile));

function v14ScrollSetup(){ document.getElementById('profileSetup')?.scrollIntoView({behavior:'smooth',block:'start'}); }
['startStudentOSBtn','finalStartBtn','futureStartBtn'].forEach(id=>document.getElementById(id)?.addEventListener('click',v14ScrollSetup));
document.getElementById('exploreDemoBtn')?.addEventListener('click',()=>document.getElementById('product')?.scrollIntoView({behavior:'smooth'}));
document.getElementById('landingLoginBtn')?.addEventListener('click',()=>{ if(profile){setAppActiveV14(true);} else v14ScrollSetup(); });

if('IntersectionObserver' in window){
  const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target);}}),{threshold:.1});
  document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
}else document.querySelectorAll('.reveal').forEach(el=>el.classList.add('visible'));

const commandPalette=document.getElementById('commandPalette');
const commandInput=document.getElementById('commandInput');
const commandResults=document.getElementById('commandResults');
let commandActiveIndex=0;
const v14Commands=[
  {icon:'🏠',label:'Dashboard',desc:'Je persoonlijke overzicht',view:'dashboard'},
  {icon:'📚',label:'Onderwijs & Leren',desc:'Leerpad, oefenen, scholen en toekomst',view:'education'},
  {icon:'🗂️',label:'Mijn Projecten',desc:'Presentaties, posters en verslagen',view:'projects'},
  {icon:'🧠',label:'AI Tutor',desc:'Laat iets uitleggen op jouw niveau',view:'tutor'},
  {icon:'✨',label:'Studio AI',desc:'Research, slides, reports en design',view:'studio'},
  {icon:'📅',label:'Planner',desc:'Plan taken en leersessies',view:'planner'},
  {icon:'📈',label:'Voortgang',desc:'Bekijk activiteit en mastery',view:'progress'},
  {icon:'🎯',label:'Doelen',desc:'Beheer je persoonlijke doelen',view:'goals'},
  {icon:'⚙️',label:'Profiel',desc:'Pas je StudentOS-profiel aan',view:'profile'}
];
function filteredCommands(){const q=(commandInput?.value||'').trim().toLowerCase();return v14Commands.filter(c=>!q||(`${c.label} ${c.desc}`).toLowerCase().includes(q));}
function renderCommandResultsV14(){
  if(!commandResults)return; const list=filteredCommands(); commandActiveIndex=Math.min(commandActiveIndex,Math.max(0,list.length-1));
  commandResults.innerHTML=list.length?list.map((c,i)=>`<button class="command-item ${i===commandActiveIndex?'active':''}" data-command-view="${c.view}"><span>${c.icon}</span><div><strong>${c.label}</strong><small>${c.desc}</small></div></button>`).join(''):'<div class="empty">Geen resultaten.</div>';
  commandResults.querySelectorAll('[data-command-view]').forEach(b=>b.onclick=()=>{goView(b.dataset.commandView);closeCommandV14();});
}
function openCommandV14(){if(!profile||!commandPalette)return;commandPalette.classList.remove('hidden');commandInput.value='';commandActiveIndex=0;renderCommandResultsV14();setTimeout(()=>commandInput.focus(),30);}
function closeCommandV14(){commandPalette?.classList.add('hidden');}
document.getElementById('commandBtn')?.addEventListener('click',openCommandV14);
document.querySelectorAll('[data-close-command]').forEach(x=>x.onclick=closeCommandV14);
commandInput?.addEventListener('input',()=>{commandActiveIndex=0;renderCommandResultsV14();});
commandInput?.addEventListener('keydown',e=>{const list=filteredCommands();if(e.key==='ArrowDown'){e.preventDefault();commandActiveIndex=Math.min(list.length-1,commandActiveIndex+1);renderCommandResultsV14();}if(e.key==='ArrowUp'){e.preventDefault();commandActiveIndex=Math.max(0,commandActiveIndex-1);renderCommandResultsV14();}if(e.key==='Enter'&&list[commandActiveIndex]){e.preventDefault();goView(list[commandActiveIndex].view);closeCommandV14();}});
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommandV14();}if(e.key==='Escape'&&commandPalette&&!commandPalette.classList.contains('hidden'))closeCommandV14();});



/* =====================================
   STUDENTOS V15 — INDEX LUXURY MOTION
   ===================================== */

(() => {
  const landing = document.querySelector(".landing");
  const nav = document.querySelector(".landing-nav");
  const demo = document.querySelector(".demo-window");

  if(landing){
    landing.addEventListener("pointermove", e => {
      const r = landing.getBoundingClientRect();
      const x = ((e.clientX-r.left)/r.width)*100;
      const y = ((e.clientY-r.top)/Math.max(r.height,1))*100;
      landing.style.setProperty("--mouse-x", x.toFixed(1)+"%");
      landing.style.setProperty("--mouse-y", Math.min(y,32).toFixed(1)+"%");
    });
  }

  const updateLandingNav = () => {
    if(nav) nav.classList.toggle("scrolled", window.scrollY > 28);
  };
  window.addEventListener("scroll", updateLandingNav, {passive:true});
  updateLandingNav();

  if(demo && window.matchMedia("(pointer:fine)").matches){
    const wrap = demo.closest(".hero-product-demo");
    wrap?.addEventListener("pointermove", e => {
      const r = wrap.getBoundingClientRect();
      const rx = ((e.clientY-r.top)/r.height-.5)*-3.5;
      const ry = ((e.clientX-r.left)/r.width-.5)*5.5;
      demo.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg) translateY(-2px)`;
    });
    wrap?.addEventListener("pointerleave", () => {
      demo.style.transform = "rotateY(-2deg) rotateX(1deg)";
    });
  }

  document.querySelectorAll(".journey-step").forEach(step => {
    step.addEventListener("mouseenter", () => {
      document.querySelectorAll(".journey-step").forEach(x=>x.classList.remove("active"));
      step.classList.add("active");
    });
  });
})();
