# StudentOS 360 — V13 Visual Refresh

V13 verandert vooral de uitstraling, niet de kernfunctionaliteit.

## Nieuwe visuele richting
- premium dark sidebar
- sterker StudentOS-logo
- zachtere gradients
- lime/violet als herkenbare accenten
- grotere typografische hiërarchie
- compactere maar luxere cards
- consistente radius en shadows
- betere hover/focus states
- modernere onboarding
- subtiele grid/orb backgrounds
- betere mobile spacing
- sterkere dashboards, projectcards, education cards en Studio AI

## Doel
De site moet minder voelen als een prototype en meer als een echte moderne SaaS/education-app.

## Niet toegevoegd
Op verzoek zijn geen:
- ouderdashboard
- docentdashboard
- rapportcijfers

toegevoegd.
