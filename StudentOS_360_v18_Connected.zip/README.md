# StudentOS 360 — V7.1

V7.1 is de eerste **cloud + live-AI-ready** versie.

## Architectuur

### Frontend
- HTML/CSS/JavaScript
- offline-first localStorage
- Supabase browser auth
- cloud snapshot sync
- AI Tutor calls go only to StudentOS backend

### Backend
- Node.js + Express
- official OpenAI JavaScript SDK
- OpenAI Responses API
- optional Supabase JWT verification
- API secrets stored in environment variables

### Database
- Supabase/Postgres
- profiles
- user_state snapshot
- normalized future tables for tasks/goals
- Row Level Security policies

## Veiligheidskeuze
`OPENAI_API_KEY` staat nooit in frontendcode.
De Supabase `service_role` key wordt ook niet gebruikt in de browser.

## Snel starten
Lees `SETUP.md`.

## Demo
Zonder configuratie blijft StudentOS werken als lokale V7 demo.


---

# V8 — Studio AI toegevoegd

Nieuwe sidebarmodule: **✨ Studio AI**

Bevat:
- Ask AI
- web-grounded Research
- Presentation Builder + PPTX export
- Research-first Writer
- Natural Rewrite
- Poster Designer + PNG export
- GPT Image backend
- klikbare webbronnen
- eigen StudentOS UX in plaats van concurrentinterfaces te kopiëren

Lees `STUDIO_AI.md` voor de architectuur.


---

# V9 — Editors

Studio AI bevat nu interactieve editorfuncties voor presentaties en posters.

Zie `V9_EDITORS.md`.


---

# V10 — Projects & Advanced Editors

Zie `V10_PROJECTS.md` voor alle nieuwe functies.


---

# V11 — Professional Editors

Zie `V11_PRO_EDITORS.md`.


---

# V12 — Education & Adaptive Learning

Zie `V12_EDUCATION.md`.


---

# V13 — Visual Refresh

Zie `V13_VISUAL_REFRESH.md`.


---

# V14 — Signature Design

Zie `V14_SIGNATURE_DESIGN.md`.


---

# V15 — Index Luxury

Open `index.html`. Zie `V15_INDEX_LUXURY.md` voor de visuele wijzigingen.


---

# V16 — Online MVP & Reliability

Zie `V16_ONLINE_MVP.md`. Voor live accounts/AI: start voortaan via de Node-server in plaats van alleen `index.html` te dubbelklikken.


---

# V17 — Deploy Ready

Gratis standaardlimieten zijn verhoogd naar **100 AI-tekstverzoeken en 8 afbeeldingen per dag voor ingelogde gebruikers**. Zie `V17_DEPLOY_READY.md` en `LIVE_SETUP.md`.


---

# V18 — Connected Build

Deze build bevat de publieke Supabase-configuratie voor het gekoppelde StudentOS-project. Zie `V18_CONNECTED.md`.
