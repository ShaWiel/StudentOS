
window.STUDENTOS_EDUCATION = {
  sources: {
    structure: "https://gov.sr/thema/scholen/",
    ministry: "https://gov.sr/ministeries/ministerie-van-onderwijs-wetenschapen-cultuur/directoraat-algemeen-vormend-onderwijs/",
    vocational: "https://gov.sr/beroepsonderwijs/scholen/",
    schoolList: "https://gov.sr/wp-content/uploads/2022/10/Lijst-met-Scholen-Suriname-1.xlsx",
    adekus: "https://www.uvs.edu/aanmelding-nieuwe-inschrijvingen-bacheloropleidingen/"
  },

  ladder: [
    {id:"ecd",icon:"🧸",title:"ECD / jonge kinderen",subtitle:"Vroege ontwikkeling; nationaal ECD-beleid richt zich op 0–8 jaar.",tag:"Vroege ontwikkeling"},
    {id:"glo",icon:"📚",title:"GLO / basisschool",subtitle:"Primair onderwijs volgens MinOWC.",tag:"Primair"},
    {id:"voj",icon:"🎒",title:"VOJ",subtitle:"Voortgezet Onderwijs voor Junioren.",tag:"Secundair"},
    {id:"vos",icon:"📘",title:"VOS",subtitle:"Voortgezet Onderwijs voor Senioren.",tag:"Secundair"},
    {id:"beroeps",icon:"🛠️",title:"Beroepsonderwijs",subtitle:"Onder meer LBO, MBO, NATIN, AMTO en IMEAO-routes.",tag:"Secundair / beroeps"},
    {id:"tertiair",icon:"🎓",title:"Tertiair onderwijs",subtitle:"Postsecundair/hoger onderwijs waarvoor minimaal VOS of equivalent als basis geldt.",tag:"Hoger onderwijs"},
    {id:"volwassen",icon:"💼",title:"Volwasseneneducatie",subtitle:"MinOWC curriculumontwikkeling loopt door tot volwasseneneducatie.",tag:"Leven lang leren"}
  ],

  curriculum: [
    {stage:"ecd",subject:"Taal & communicatie",topics:["woorden","luisteren","vertellen","klanken"],official:false,desc:"Spelenderwijs taalontwikkeling."},
    {stage:"ecd",subject:"Getalbegrip",topics:["tellen","meer/minder","vormen","patronen"],official:false,desc:"Vroege rekenprikkels en logisch denken."},
    {stage:"ecd",subject:"Sociaal-emotioneel",topics:["samen spelen","emoties","routine","zelfstandigheid"],official:false,desc:"Ontwikkeling van sociale en emotionele vaardigheden."},

    {stage:"glo",subject:"Taal",topics:["lezen","spelling","woordenschat","begrijpend lezen"],official:true,desc:"Taal is expliciet genoemd in MinOWC-herhalingsonderwijs."},
    {stage:"glo",subject:"Rekenen",topics:["optellen","aftrekken","breuken","percentages"],official:true,desc:"Rekenen is expliciet genoemd in MinOWC-herhalingsonderwijs."},
    {stage:"glo",subject:"AGN",topics:["aardrijkskunde","geschiedenis","natuuronderwijs"],official:true,desc:"Aardrijkskunde, geschiedenis en natuuronderwijs worden door MinOWC samen genoemd."},
    {stage:"glo",subject:"Expressie & bewegen",topics:["sport","spel","creativiteit"],official:true,desc:"Sport/spel en expressie worden in MinOWC-programmering genoemd."},

    {stage:"voj",subject:"Nederlands",topics:["begrijpend lezen","grammatica","schrijven"],official:false,desc:"StudentOS-studiekaart voor algemene taalvaardigheid."},
    {stage:"voj",subject:"Wiskunde",topics:["algebra","verhoudingen","meetkunde","procenten"],official:false,desc:"StudentOS-studiekaart voor wiskundige basisvaardigheden."},
    {stage:"voj",subject:"Engels",topics:["vocabulary","grammar","reading"],official:false,desc:"StudentOS-studiekaart."},
    {stage:"voj",subject:"Mens & natuur",topics:["biologie","natuurkunde","milieu"],official:false,desc:"StudentOS-studiekaart."},

    {stage:"vos",subject:"Wiskunde",topics:["algebra","functies","statistiek","meetkunde"],official:false,desc:"StudentOS-studiekaart; exacte inhoud verschilt per richting."},
    {stage:"vos",subject:"Economie",topics:["vraag en aanbod","inflatie","markten","begroting"],official:false,desc:"StudentOS-studiekaart."},
    {stage:"vos",subject:"Natuurwetenschappen",topics:["biologie","scheikunde","natuurkunde"],official:false,desc:"StudentOS-studiekaart; vakkenpakket verschilt."},
    {stage:"vos",subject:"Talen & maatschappij",topics:["Nederlands","Engels","geschiedenis","maatschappij"],official:false,desc:"StudentOS-studiekaart."},

    {stage:"beroeps",subject:"Technische Stream",topics:["bouwkunde","elektro","werktuigbouw","voertuigentechniek"],official:true,desc:"Programmagebieden uit de actuele MinOWC beroepsonderwijs-directory."},
    {stage:"beroeps",subject:"Dienstverlenende Stream",topics:["economie","marketing","toerisme","zorg & welzijn"],official:true,desc:"Programmagebieden uit de actuele MinOWC beroepsonderwijs-directory."},
    {stage:"beroeps",subject:"ICT & informatie",topics:["ICT","elektrotechniek-info","audiovisuele productie"],official:true,desc:"Voorbeelden uit actuele NATIN/beroepsonderwijsvermeldingen."},

    {stage:"tertiair",subject:"Academische vaardigheden",topics:["onderzoek","bronbeoordeling","schrijven","presenteren"],official:false,desc:"StudentOS algemene studeerkaart."},
    {stage:"tertiair",subject:"Professionele vaardigheden",topics:["projectwerk","data","communicatie","loopbaan"],official:false,desc:"StudentOS algemene studeerkaart."},

    {stage:"volwassen",subject:"Digitale vaardigheden",topics:["computer basics","internet","Office","online veiligheid"],official:false,desc:"StudentOS praktische leerkaart."},
    {stage:"volwassen",subject:"Werk & administratie",topics:["CV","e-mail","formulieren","budgetteren"],official:false,desc:"StudentOS praktische leerkaart."}
  ],

  schools: [
    {name:"NATIN Paramaribo",region:"Paramaribo",place:"Tammenga",level:["MBO"],stream:["Technische Stream"],programs:["Apothekers Assistent","Audiovisuele Productie","Chemisch analist","Elektrotechniek – energie","Elektrotechniek – info","Infrastructuur","ICT","Medisch analist","Procestechniek","Weg en Waterbouwkunde","Werktuigbouwkunde"],verified:true},
    {name:"NATIN Mottonshoop",region:"Paramaribo",place:"Tammenga",level:["MBO"],stream:["Technische Stream"],programs:["Bosbeheer","Natuurbeheer en Ecotoerisme","Hydro/Meteo","Landmeetkunde","Mijnbouw"],verified:true},
    {name:"NATIN Lelydorp",region:"Wanica",place:"Lelydorp",level:["MBO"],stream:["Technische Stream"],programs:[],verified:true},
    {name:"NATIN Nickerie",region:"Nickerie",place:"Nieuw Nickerie",level:["MBO"],stream:["Technische Stream"],programs:[],verified:true},
    {name:"AMTO Paramaribo",region:"Paramaribo",place:"Paramaribo",level:["MBO"],stream:["Technische Stream"],programs:["Bouwkunde","Weg en Waterbouwkunde","Electro","Koeltechniek","Electronica"],verified:true},
    {name:"AMTO Noord",region:"Paramaribo",place:"Noord",level:["MBO"],stream:["Technische Stream"],programs:["Bouwkunde","Werktuigbouwkunde","Electro"],verified:true},
    {name:"AMTO Lelydorp",region:"Wanica",place:"Lelydorp",level:["MBO"],stream:["Technische Stream"],programs:["Electro","Bouwkunde","Werktuigbouwkunde"],verified:true},
    {name:"AMTO Nickerie",region:"Nickerie",place:"Nieuw Nickerie",level:["MBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","Werktuigbouwkunde"],verified:true},
    {name:"AMTO Saramacca",region:"Saramacca",place:"Saramacca",level:["MBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","Werktuigbouwkunde"],verified:true},
    {name:"AMTO Moengo",region:"Marowijne",place:"Moengo",level:["MBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","Werktuigbouwkunde"],verified:true},
    {name:"IMEAO 1",region:"Paramaribo",place:"Blauwgrond",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Secretarieel","Statistiek","Toerisme"],verified:true},
    {name:"IMEAO 2",region:"Paramaribo",place:"Beekhuizen",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Toerisme"],verified:true},
    {name:"IMEAO 3",region:"Wanica",place:"De Nieuwe Grond",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Secretarieel","Toerisme"],verified:true},
    {name:"IMEAO 4",region:"Paramaribo",place:"Kwatta",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Secretarieel","Toerisme"],verified:true},
    {name:"IMEAO 5",region:"Wanica",place:"Koewarasan",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing"],verified:true},
    {name:"IMEAO Nickerie",region:"Nickerie",place:"Nieuw Nickerie",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Secretarieel","Statistiek"],verified:true},
    {name:"Avond IMEAO",region:"Paramaribo",place:"Centrum",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie","Marketing","Secretarieel","Toerisme"],verified:true},
    {name:"Dep. IMEAO SGT",region:"Commewijne",place:"Tamanredjo",level:["MBO"],stream:["Dienstverlenend"],programs:["Economie"],verified:true},
    {name:"Vocational College Suriname (VCS)",region:"Paramaribo",place:"Paramaribo",level:["MBO"],stream:["Dienstverlenend"],programs:["Horeca","Mode, Creatie & Commercie","Zorg & Welzijn","Facilitaire Dienstverlening"],verified:true},
    {name:"Scholengemeenschap Moengotapoe",region:"Marowijne",place:"Moengotapoe",level:["MBO"],stream:["Dienstverlenend","Technische Stream"],programs:["Economie","Marketing","Elektrotechniek – energie","Elektrotechniek – info","Infrastructuur","Werktuigbouwkunde"],verified:true},
    {name:"LBO Meerzorg",region:"Commewijne",place:"Meerzorg",level:["LBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","Voertuigentechniek","Werktuigbouwkunde"],verified:true},
    {name:"LBO Latour",region:"Paramaribo",place:"Latour",level:["LBO"],stream:["Dienstverlenend"],programs:["Handel & Administratie"],verified:true},
    {name:"LBO Openbare Nijverheidschool (ONS)",region:"Paramaribo",place:"Centrum",level:["LBO","PO"],stream:["Dienstverlenend"],programs:["Facilitaire Dienstverlening","Horeca","Mode, Creatie & Commercie","Zorg & Welzijn"],verified:true},
    {name:"STS-1",region:"Paramaribo",place:"Centrum",level:["LBO"],stream:["Technische Stream"],programs:["Agrarische productie","Bouwkunde","Electro","Schildertechniek","Voertuigentechniek","Werktuigbouwkunde"],verified:true},
    {name:"STS-2",region:"Paramaribo",place:"Tammenga",level:["LBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","GAWASA","Voertuigentechniek","Werktuigbouwkunde"],verified:true},
    {name:"STS-3",region:"Paramaribo",place:"Beekhuizen",level:["LBO"],stream:["Technische Stream"],programs:["Bouwkunde","Electro","Voertuigentechniek","Werktuigbouwkunde"],verified:true},
    {name:"STS-4",region:"Paramaribo",place:"Blauwgrond",level:["LBO"],stream:["Technische Stream"],programs:["Agrarische productie","Bouwkunde","Electro","GAWASA","Voertuigentechniek","Werktuigbouwkunde"],verified:true},
    {name:"LBO Ramdjanee",region:"Nickerie",place:"Nickerie",level:["LBO","PO"],stream:["Dienstverlenend","Technische Stream"],programs:["Agrarische productie","Facilitaire Dienstverlening","Handel & Administratie","Horeca","Zorg & Welzijn"],verified:true},
    {name:"LBO Brokopondo",region:"Brokopondo",place:"Brokopondo",level:["LBO"],stream:["Dienstverlenend","Technische Stream"],programs:["Electro","Werktuigbouwkunde","Handel & Administratie"],verified:true},
    {name:"LBO Barron",region:"Marowijne",place:"Marowijne",level:["LBO","PO"],stream:["Dienstverlenend","Technische Stream"],programs:["Bouwkunde","Electro","Werktuigbouwkunde","Facilitaire Dienstverlening","Handel & Administratie","Mode, Creatie & Commercie"],verified:true},
    {name:"LBO Atjoni",region:"Sipaliwini",place:"Atjoni",level:["LBO","PO"],stream:["Technische Stream"],programs:["Electro","Werktuigbouwkunde"],verified:true},
    {name:"LBO Tata Colin",region:"Coronie",place:"Coronie",level:["LBO"],stream:["Dienstverlenend","Technische Stream"],programs:["Bouwkunde","Voertuigentechniek","Handel & Administratie"],verified:true},
    {name:"AMTO / beroepsroute Para",region:"Para",place:"Para",level:["MBO"],stream:["Technische Stream"],programs:["Oriëntatie technische beroepsroutes"],verified:false}
  ],

  questionBank: {
    basis: {
      "Rekenen": {
        "breuken": [
          {difficulty:1,q:"Welke breuk is precies de helft?",options:["1/4","1/2","3/4","2/3"],answer:1,explain:"Een helft betekent 1 van 2 gelijke delen: 1/2."},
          {difficulty:1,q:"Een pizza heeft 4 gelijke stukken. Je eet 1 stuk. Welke breuk heb je gegeten?",options:["1/2","1/3","1/4","3/4"],answer:2,explain:"Je eet 1 van de 4 gelijke stukken, dus 1/4."},
          {difficulty:2,q:"Welke breuk is gelijk aan 1/2?",options:["2/3","2/4","3/4","1/3"],answer:1,explain:"2/4 kun je delen door 2: 2÷2 / 4÷2 = 1/2."},
          {difficulty:3,q:"Wat is 1/4 + 2/4?",options:["3/8","3/4","2/8","1/2"],answer:1,explain:"Bij gelijke noemers tel je de tellers op: 1+2=3, dus 3/4."}
        ],
        "percentages": [
          {difficulty:1,q:"Wat betekent 50%?",options:["Een kwart","De helft","Alles","Een tiende"],answer:1,explain:"50 van 100 is de helft."},
          {difficulty:2,q:"Wat is 10% van 80?",options:["8","10","18","72"],answer:0,explain:"10% is één tiende. 80 ÷ 10 = 8."},
          {difficulty:3,q:"Een prijs van 200 stijgt met 15%. Wat is de nieuwe prijs?",options:["215","225","230","250"],answer:2,explain:"15% van 200 is 30. 200 + 30 = 230."}
        ]
      },
      "Taal": {
        "begrijpend lezen": [
          {difficulty:1,q:"Wat is meestal het doel van een titel?",options:["De tekst verstoppen","Vertellen waar de tekst ongeveer over gaat","Alle antwoorden geven","Alleen mooi klinken"],answer:1,explain:"Een titel helpt je voorspellen waar de tekst over gaat."},
          {difficulty:2,q:"Wat is een hoofdgedachte?",options:["Het minst belangrijke detail","De belangrijkste boodschap van een tekst","De eerste zin","Een moeilijke naam"],answer:1,explain:"De hoofdgedachte is de kernboodschap die de schrijver wil overbrengen."}
        ]
      }
    },
    voj: {
      "Wiskunde": {
        "algebra": [
          {difficulty:1,q:"Los op: x + 5 = 12",options:["5","7","12","17"],answer:1,explain:"Trek 5 van beide kanten af: x=7."},
          {difficulty:2,q:"Los op: 3x = 21",options:["6","7","8","18"],answer:1,explain:"Deel beide kanten door 3: x=7."},
          {difficulty:3,q:"Los op: 2x + 4 = 18",options:["5","6","7","11"],answer:2,explain:"18−4=14 en 14÷2=7."}
        ]
      },
      "Nederlands": {
        "grammatica": [
          {difficulty:1,q:"Welk woord is het werkwoord in: 'De leerling leest een boek'?",options:["leerling","leest","boek","een"],answer:1,explain:"'Leest' vertelt wat de leerling doet en is het werkwoord."},
          {difficulty:2,q:"Welke zin staat in de verleden tijd?",options:["Ik loop naar school.","Ik liep naar school.","Ik zal lopen.","Loop naar school."],answer:1,explain:"'Liep' is de verleden tijd van lopen."}
        ]
      }
    },
    vos: {
      "Economie": {
        "inflatie": [
          {difficulty:1,q:"Wat gebeurt er meestal met koopkracht als prijzen stijgen en je inkomen gelijk blijft?",options:["Koopkracht stijgt","Koopkracht daalt","Niets verandert","Geld verdubbelt"],answer:1,explain:"Met hetzelfde inkomen kun je minder kopen als het algemene prijsniveau stijgt."},
          {difficulty:2,q:"Welke situatie past het best bij inflatie?",options:["Eén telefoon wordt duurder","Veel goederen en diensten worden gemiddeld duurder","Een winkel geeft korting","De productie van één bedrijf stijgt"],answer:1,explain:"Inflatie gaat om een algemene stijging van het prijsniveau, niet één los product."},
          {difficulty:3,q:"Als inflatie 8% is en loon 3% stijgt, wat gebeurt er ongeveer met reële koopkracht?",options:["Stijgt sterk","Daalt","Blijft exact gelijk","Verdubbelt"],answer:1,explain:"Prijzen stijgen sneller dan het loon; reële koopkracht neemt daardoor ongeveer af."}
        ],
        "vraag en aanbod": [
          {difficulty:1,q:"Wat gebeurt er vaak met de prijs als vraag stijgt en aanbod gelijk blijft?",options:["Prijs daalt","Prijs stijgt","Prijs wordt nul","Altijd niets"],answer:1,explain:"Meer vraag bij hetzelfde aanbod zet meestal opwaartse druk op de prijs."},
          {difficulty:3,q:"Wat kan een toename van aanbod bij gelijke vraag veroorzaken?",options:["Hogere evenwichtsprijs","Lagere evenwichtsprijs","Geen markt meer","Altijd inflatie"],answer:1,explain:"Meer aanbod verschuift de aanbodcurve naar rechts en kan de evenwichtsprijs verlagen."}
        ]
      },
      "Wiskunde": {
        "algebra": [
          {difficulty:1,q:"Los op: 4x - 8 = 12",options:["4","5","6","8"],answer:1,explain:"4x=20, dus x=5."},
          {difficulty:2,q:"Wat is de helling van y = 3x + 2?",options:["2","3","5","x"],answer:1,explain:"In y=mx+b is m de helling. Hier is m=3."},
          {difficulty:3,q:"Als f(x)=x²-4, wat is f(3)?",options:["3","5","9","13"],answer:1,explain:"3²−4 = 9−4 = 5."}
        ]
      }
    },
    volwassene: {
      "Digitale vaardigheden": {
        "online veiligheid": [
          {difficulty:1,q:"Wat deel je nooit zomaar via een onverwacht bericht?",options:["Je favoriete kleur","Een verificatiecode","Het weer","Een recept"],answer:1,explain:"Verificatiecodes kunnen toegang tot accounts geven en horen geheim te blijven."},
          {difficulty:2,q:"Wat is de veiligste reactie op een verdachte betaallink?",options:["Direct betalen","Link doorsturen naar iedereen","Zelf de organisatie via een bekend kanaal controleren","Je wachtwoord invullen"],answer:2,explain:"Controleer de organisatie onafhankelijk via een bekend nummer of officiële site."}
        ]
      }
    }
  },

  futureRoutes: {
    "people": {
      careers:["Onderwijsprofessional","HR-professional","Psychologie/gedragswerk","Zorgprofessional"],
      studies:["Psychologie","Onderwijs- en Pedagogische Wetenschappen","Public Health","Sociologie"],
      skills:["communicatie","empathie","onderzoek","begeleiding"]
    },
    "numbers": {
      careers:["Econoom","Financieel analist","Ondernemer","Business analyst"],
      studies:["Economie","Bedrijfskunde","Finance/administratieve routes","Statistiek/data"],
      skills:["wiskunde","analyse","planning","financieel inzicht"]
    },
    "technology": {
      careers:["ICT-specialist","Engineer","Technisch projectleider","Developer"],
      studies:["ICT","Electrotechniek","Werktuigbouwkunde","Infrastructuur/Bouwkunde"],
      skills:["wiskunde","probleemoplossing","techniek","digitale vaardigheden"]
    },
    "science": {
      careers:["Arts/gezondheidsprofessional","Laboratoriumprofessional","Onderzoeker","Milieuspecialist"],
      studies:["Geneeskunde","Biologie","Scheikunde","Public Health","Milieuwetenschappen"],
      skills:["biologie","scheikunde","onderzoek","data"]
    },
    "language": {
      careers:["Communicatieprofessional","Schrijver/redacteur","Media professional","Content specialist"],
      studies:["Taal en Communicatie","Media/creatieve routes","Onderwijs/talen"],
      skills:["schrijven","presenteren","creativiteit","taal"]
    },
    "society": {
      careers:["Jurist","Beleidsadviseur","Bestuursprofessional","Onderzoeker"],
      studies:["Rechtswetenschappen","Public Administration","Sociologie","maatschappelijke studies"],
      skills:["argumentatie","onderzoek","schrijven","analyse"]
    }
  }
};
