# StudentOS 360 — V11 Professional Editors

V11 richt zich op professionele editorfuncties.

## Presentatie-editor
Nieuw:
- resize handles
- rotatie
- grid snapping
- center alignment guides
- bold / italic / underline
- speaker notes per slide
- PDF export
- bestaande PPTX export blijft aanwezig
- element opacity/fill/width blijven aanwezig

## Projectversies
- handmatige checkpoints
- maximaal 20 lokale versies per project
- eerdere versie herstellen
- Supabase-tabellen voorbereid voor echte cloudversies

## Delen
- prototype share-token per project
- deellink wordt lokaal gegenereerd
- echte publieke links vereisen een serverroute/hosting

## Comments
- comments per project
- auteur + datum
- lokaal opgeslagen
- database schema voorbereid voor cloudcomments

## Samenwerking
De UI is voorbereid op echte samenwerking, maar realtime multi-user editing is nog niet actief.

## PDF
Presentaties kunnen als PDF worden geëxporteerd via jsPDF + html2canvas.

## Volgende stap: V12 onderwijslaag
Na V11 is het logisch om terug te gaan naar het hart van StudentOS:
- Surinaamse schooldatabase
- curricula per leerfase
- vakken per niveau
- leerdoelen
- adaptieve quizzen
- mastery per onderwerp
- oefenreeksen
- school/studie/carrière-navigator
- docent/ouderdashboard
