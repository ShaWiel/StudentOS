
(() => {
  const EDU = window.STUDENTOS_EDUCATION;
  if(!EDU) return;

  if(window.titles) window.titles.education = "Onderwijs & Leren";

  const MASTERY_KEY = "studentos_v12_mastery";
  let mastery = JSON.parse(localStorage.getItem(MASTERY_KEY) || "{}");
  let eduTab = "path";
  let session = null;
  let selectedAnswer = null;
  let futureInterest = "";
  let futureAction = "";

  let masteryCloudTimer=null;
  function saveMastery(){
    localStorage.setItem(MASTERY_KEY, JSON.stringify(mastery));
    if(typeof currentUser!=="undefined" && currentUser && typeof supabaseClient!=="undefined" && supabaseClient){
      clearTimeout(masteryCloudTimer);
      masteryCloudTimer=setTimeout(()=>pushMasteryToCloud().catch(console.warn),700);
    }
  }
  async function pushMasteryToCloud(){
    if(!currentUser||!supabaseClient)return;
    const rows=Object.entries(mastery).map(([k,v])=>{
      const [stage,subject,topic]=k.split("::");
      return {user_id:currentUser.id,stage,subject,topic,mastery_score:Number(v)||0,updated_at:new Date().toISOString(),last_practiced_at:new Date().toISOString()};
    });
    if(!rows.length)return;
    const {error}=await supabaseClient.from("learning_mastery").upsert(rows,{onConflict:"user_id,stage,subject,topic"});
    if(error)throw error;
  }
  async function pullMasteryFromCloud(){
    if(!currentUser||!supabaseClient)return;
    const {data,error}=await supabaseClient.from("learning_mastery").select("stage,subject,topic,mastery_score").eq("user_id",currentUser.id);
    if(error)throw error;
    (data||[]).forEach(r=>{mastery[key(r.stage,r.subject,r.topic)]=Number(r.mastery_score)||0;});
    localStorage.setItem(MASTERY_KEY,JSON.stringify(mastery));
    updateMasteryCard();renderMasteryList();
  }
  window.studentosPullMasteryFromCloud=pullMasteryFromCloud;
  function key(stage,subject,topic){ return [stage,subject,topic].join("::"); }
  function getMastery(stage,subject,topic){ return Number(mastery[key(stage,subject,topic)] || 0); }
  function setMastery(stage,subject,topic,value){
    mastery[key(stage,subject,topic)] = Math.max(0,Math.min(100,Math.round(value)));
    saveMastery();
  }

  // Tabs
  document.querySelectorAll("[data-edu-tab]").forEach(btn => btn.addEventListener("click", () => {
    eduTab = btn.dataset.eduTab;
    document.querySelectorAll("[data-edu-tab]").forEach(x => x.classList.toggle("active", x === btn));
    document.querySelectorAll(".edu-pane").forEach(x => x.classList.add("hidden"));
    document.getElementById("edu-" + eduTab).classList.remove("hidden");
    if(eduTab === "schools") renderSchools();
    if(eduTab === "practice") renderMasteryList();
  }));

  // Ladder
  function renderLadder(){
    const current = profile?.stage || "";
    const mapStage = {peuter:"ecd",basis:"glo",voj:"voj",vos:"vos",student:"tertiair",volwassene:"volwassen",senior:"volwassen"};
    const currentId = mapStage[current];
    document.getElementById("educationLadder").innerHTML = EDU.ladder.map(item => `
      <div class="ladder-item" style="${item.id===currentId?'border-color:#247149;background:#f2fbf5':''}">
        <div class="ladder-icon">${item.icon}</div>
        <div>
          <strong>${escapeHtml(item.title)}${item.id===currentId?' • Jij bent hier':''}</strong>
          <small>${escapeHtml(item.subtitle)}</small>
        </div>
        <span class="ladder-tag">${escapeHtml(item.tag)}</span>
      </div>
    `).join("");
  }

  // Curriculum
  function renderCurriculum(){
    const filter = document.getElementById("curriculumStageFilter").value;
    const list = EDU.curriculum.filter(x => filter === "all" || x.stage === filter);
    document.getElementById("curriculumMap").innerHTML = list.map(x => `
      <article class="curriculum-card">
        <span class="eyebrow">${stageName(x.stage)}</span>
        <h4>${escapeHtml(x.subject)}</h4>
        <p>${escapeHtml(x.desc)}</p>
        <div class="curriculum-meta">
          ${x.topics.slice(0,5).map(t => `<span>${escapeHtml(t)}</span>`).join("")}
          <span class="${x.official?'official':''}">${x.official?'✓ brongekoppeld':'StudentOS kaart'}</span>
        </div>
      </article>
    `).join("");
  }
  function stageName(s){
    return {ecd:"ECD",glo:"Basisonderwijs",voj:"VOJ",vos:"VOS",beroeps:"Beroepsonderwijs",tertiair:"Tertiair",volwassen:"Volwassen"}[s] || s;
  }
  document.getElementById("curriculumStageFilter").addEventListener("change", renderCurriculum);

  // Practice selectors
  function practiceSubjects(){
    const stage = document.getElementById("practiceStage").value;
    const bank = EDU.questionBank[stage] || {};
    const subjects = Object.keys(bank);
    document.getElementById("practiceSubject").innerHTML = subjects.map(x => `<option>${escapeHtml(x)}</option>`).join("");
    practiceTopics();
  }
  function practiceTopics(){
    const stage = document.getElementById("practiceStage").value;
    const subject = document.getElementById("practiceSubject").value;
    const topics = Object.keys(EDU.questionBank[stage]?.[subject] || {});
    document.getElementById("practiceTopic").innerHTML = topics.map(x => `<option>${escapeHtml(x)}</option>`).join("");
    updateMasteryCard();
  }
  document.getElementById("practiceStage").addEventListener("change", practiceSubjects);
  document.getElementById("practiceSubject").addEventListener("change", practiceTopics);
  document.getElementById("practiceTopic").addEventListener("change", updateMasteryCard);

  function updateMasteryCard(){
    const stage = document.getElementById("practiceStage").value;
    const subject = document.getElementById("practiceSubject").value;
    const topic = document.getElementById("practiceTopic").value;
    const score = getMastery(stage,subject,topic);
    document.getElementById("masteryScore").textContent = score + "%";
    document.getElementById("masteryBar").style.width = score + "%";
    document.getElementById("masteryLabel").textContent =
      score === 0 ? "Nog niet geoefend" :
      score < 40 ? "Basis opbouwen" :
      score < 70 ? "In ontwikkeling" :
      score < 90 ? "Sterk" : "Bijna beheerst";
  }

  function chooseDifficulty(score){
    if(score < 30) return 1;
    if(score < 70) return 2;
    return 3;
  }
  function questionsFor(stage,subject,topic){
    return EDU.questionBank[stage]?.[subject]?.[topic] || [];
  }
  function selectQuestion(){
    const qs = questionsFor(session.stage,session.subject,session.topic);
    const desired = chooseDifficulty(getMastery(session.stage,session.subject,session.topic));
    let candidates = qs.filter(q => q.difficulty === desired);
    if(!candidates.length) candidates = qs.filter(q => Math.abs(q.difficulty-desired) <= 1);
    if(!candidates.length) candidates = qs;
    const unused = candidates.filter(q => !session.used.includes(q.q));
    const pool = unused.length ? unused : candidates;
    return pool[Math.floor(Math.random()*pool.length)];
  }

  document.getElementById("startPracticeBtn").addEventListener("click", () => {
    const stage = document.getElementById("practiceStage").value;
    const subject = document.getElementById("practiceSubject").value;
    const topic = document.getElementById("practiceTopic").value;
    if(!questionsFor(stage,subject,topic).length) return alert("Voor dit onderwerp zijn nog geen oefenvragen toegevoegd.");
    session = {stage,subject,topic,index:0,total:5,correct:0,used:[],question:null};
    document.getElementById("practiceEmpty").classList.add("hidden");
    document.getElementById("sessionSummary").classList.add("hidden");
    document.getElementById("practiceSession").classList.remove("hidden");
    nextPracticeQuestion();
  });

  function nextPracticeQuestion(){
    if(session.index >= session.total){
      finishPractice();
      return;
    }
    selectedAnswer = null;
    session.question = selectQuestion();
    if(!session.question) return finishPractice();
    session.used.push(session.question.q);
    document.getElementById("practiceMeta").textContent = `Vraag ${session.index+1} van ${session.total} • ${session.subject}`;
    document.getElementById("questionText").textContent = session.question.q;
    document.getElementById("difficultyBadge").textContent = ["","Basis","Midden","Uitdaging"][session.question.difficulty] || "Adaptief";
    document.getElementById("answerOptions").innerHTML = session.question.options.map((opt,i) => `
      <button class="answer-option" data-answer="${i}">${escapeHtml(opt)}</button>
    `).join("");
    document.querySelectorAll("[data-answer]").forEach(btn => btn.onclick = () => {
      if(!document.getElementById("nextQuestionBtn").classList.contains("hidden")) return;
      selectedAnswer = Number(btn.dataset.answer);
      document.querySelectorAll("[data-answer]").forEach(x => x.classList.toggle("selected", x === btn));
    });
    document.getElementById("practiceFeedback").className = "practice-feedback hidden";
    document.getElementById("submitAnswerBtn").classList.remove("hidden");
    document.getElementById("nextQuestionBtn").classList.add("hidden");
  }

  document.getElementById("submitAnswerBtn").addEventListener("click", () => {
    if(selectedAnswer === null) return alert("Kies eerst een antwoord.");
    const q = session.question;
    const correct = selectedAnswer === q.answer;
    const old = getMastery(session.stage,session.subject,session.topic);
    const change = correct ? (q.difficulty * 5 + 4) : -(q.difficulty * 3 + 2);
    setMastery(session.stage,session.subject,session.topic, old + change);
    if(correct) session.correct++;
    session.index++;

    document.querySelectorAll("[data-answer]").forEach(btn => {
      const i = Number(btn.dataset.answer);
      if(i === q.answer) btn.classList.add("correct");
      if(i === selectedAnswer && !correct) btn.classList.add("wrong");
    });

    const fb = document.getElementById("practiceFeedback");
    fb.className = "practice-feedback " + (correct ? "good" : "bad");
    fb.innerHTML = `<strong>${correct?'Goed gedaan!':'Nog niet juist.'}</strong><br>${escapeHtml(q.explain)}`;

    document.getElementById("submitAnswerBtn").classList.add("hidden");
    document.getElementById("nextQuestionBtn").classList.remove("hidden");
    updateMasteryCard();
    renderMasteryList();

    if(window.addActivity) addActivity(`${correct?'Goed':'Geoefend'}: ${session.subject} — ${session.topic}`);
  });

  document.getElementById("nextQuestionBtn").addEventListener("click", nextPracticeQuestion);

  document.getElementById("explainQuestionBtn").addEventListener("click", () => {
    if(!session?.question) return;
    const prompt = `Leg dit op mijn niveau uit zonder meteen alleen het antwoord te geven: ${session.question.q}`;
    if(document.getElementById("chatInput")){
      document.getElementById("chatInput").value = prompt;
      goView("tutor");
    }
  });

  function finishPractice(){
    document.getElementById("practiceSession").classList.add("hidden");
    const score = Math.round(session.correct/session.total*100);
    const masteryScore = getMastery(session.stage,session.subject,session.topic);
    const summary = document.getElementById("sessionSummary");
    summary.classList.remove("hidden");
    summary.innerHTML = `
      <span class="eyebrow">Oefenreeks afgerond</span>
      <h3>${session.correct}/${session.total} goed</h3>
      <p>Je mastery voor <strong>${escapeHtml(session.topic)}</strong> staat nu op <strong>${masteryScore}%</strong>.</p>
      <button class="btn primary" id="practiceAgainBtn">Nog een reeks</button>
    `;
    document.getElementById("practiceAgainBtn").onclick = () => document.getElementById("startPracticeBtn").click();
    renderMasteryList();
  }

  document.getElementById("resetMasteryBtn").addEventListener("click", () => {
    const stage = document.getElementById("practiceStage").value;
    const subject = document.getElementById("practiceSubject").value;
    const topic = document.getElementById("practiceTopic").value;
    setMastery(stage,subject,topic,0);
    updateMasteryCard();
    renderMasteryList();
  });

  function renderMasteryList(){
    const entries = Object.entries(mastery).sort((a,b) => b[1]-a[1]);
    const el = document.getElementById("masteryList");
    if(!entries.length){
      el.innerHTML = '<div class="empty">Je mastery verschijnt hier nadat je oefent.</div>';
      return;
    }
    el.innerHTML = entries.slice(0,12).map(([k,v]) => {
      const [stage,subject,topic] = k.split("::");
      return `<div class="mastery-item">
        <div class="mastery-item-top"><span>${escapeHtml(topic)} <small>• ${escapeHtml(subject)}</small></span><span>${v}%</span></div>
        <div class="mastery-mini"><div style="width:${v}%"></div></div>
      </div>`;
    }).join("");
  }

  // Schools
  function renderSchools(){
    const q = (document.getElementById("schoolSearch").value || "").toLowerCase();
    const level = document.getElementById("schoolLevelFilter").value;
    const region = document.getElementById("schoolRegionFilter").value;
    const list = EDU.schools.filter(s => {
      const hay = [s.name,s.region,s.place,...s.stream,...s.programs].join(" ").toLowerCase();
      return (!q || hay.includes(q))
        && (level === "all" || s.level.includes(level))
        && (region === "all" || s.region === region);
    });

    document.getElementById("schoolStats").innerHTML = `
      <span>${list.length} resultaten</span>
      <span>${list.filter(x=>x.level.includes("MBO")).length} MBO</span>
      <span>${list.filter(x=>x.level.includes("LBO")).length} LBO</span>
      <span>${new Set(list.map(x=>x.region)).size} gebieden</span>
    `;

    document.getElementById("schoolGrid").innerHTML = list.map(s => `
      <article class="school-card">
        <div class="school-card-top">
          <div>
            <span class="eyebrow">${escapeHtml(s.region)}</span>
            <h4>${escapeHtml(s.name)}</h4>
          </div>
          <span class="${s.verified?'verified-pill':'difficulty-badge'}">${s.verified?'✓ MinOWC':'te verifiëren'}</span>
        </div>
        <p><strong>${escapeHtml(s.place)}</strong> • ${escapeHtml(s.stream.join(" / "))}</p>
        <div class="school-badges">
          ${s.level.map(x=>`<span>${escapeHtml(x)}</span>`).join("")}
          ${s.programs.slice(0,6).map(x=>`<span>${escapeHtml(x)}</span>`).join("")}
        </div>
        <a href="${EDU.sources.vocational}" target="_blank" rel="noopener noreferrer">Officiële beroepsonderwijsbron ↗</a>
      </article>
    `).join("") || '<div class="empty">Geen scholen gevonden met deze filters.</div>';
  }
  ["schoolSearch","schoolLevelFilter","schoolRegionFilter"].forEach(id => {
    document.getElementById(id).addEventListener(id==="schoolSearch"?"input":"change", renderSchools);
  });

  // Future
  document.querySelectorAll("[data-future-interest]").forEach(btn => btn.onclick = () => {
    futureInterest = btn.dataset.futureInterest;
    document.querySelectorAll("[data-future-interest]").forEach(x => x.classList.toggle("selected",x===btn));
  });
  document.querySelectorAll("[data-future-action]").forEach(btn => btn.onclick = () => {
    futureAction = btn.dataset.futureAction;
    document.querySelectorAll("[data-future-action]").forEach(x => x.classList.toggle("selected",x===btn));
  });

  document.getElementById("futureRouteBtn").addEventListener("click", () => {
    if(!futureInterest || !futureAction) return alert("Kies eerst een interesse én wat je graag doet.");
    const base = EDU.futureRoutes[futureInterest];
    const actionExtra = {
      help:["begeleiding","dienstverlening","zorg/onderwijs"],
      analyze:["onderzoek","data","kritisch denken"],
      build:["techniek","projectwerk","praktische oplossingen"],
      lead:["management","beleid","ondernemerschap"],
      communicate:["presenteren","schrijven","media"]
    }[futureAction] || [];

    document.getElementById("futureRouteOutput").innerHTML = `
      <div class="route-result">
        <span class="eyebrow">Jouw oriëntatieroute</span>
        <h3>${escapeHtml(base.careers[0])} en verwante richtingen</h3>
        <p class="edu-help">Op basis van je interesses zijn dit richtingen die je verder kunt onderzoeken. Dit is geen formeel beroeps- of toelatingsadvies.</p>
        <div class="route-columns">
          <div class="route-box"><strong>Mogelijke beroepen</strong><ul>${base.careers.map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul></div>
          <div class="route-box"><strong>Studierichtingen</strong><ul>${base.studies.map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul></div>
          <div class="route-box"><strong>Vaardigheden om te bouwen</strong><ul>${[...base.skills,...actionExtra].slice(0,7).map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul></div>
          <div class="route-box"><strong>Volgende stap</strong><ul><li>Bekijk scholen/opleidingen</li><li>Controleer toelatingseisen</li><li>Praat met iemand uit het beroep</li><li>Probeer een klein project of activiteit</li></ul></div>
        </div>
        <button class="btn primary" id="routeToSchoolsBtn">Bekijk passende scholen</button>
      </div>`;
    document.getElementById("routeToSchoolsBtn").onclick = () => {
      document.querySelector('[data-edu-tab="schools"]').click();
    };
  });

  // Personalize practice stage
  function setDefaultStage(){
    const map = {basis:"basis",voj:"voj",vos:"vos",student:"vos",volwassene:"volwassene",senior:"volwassene",peuter:"basis"};
    const val = map[profile?.stage] || "basis";
    document.getElementById("practiceStage").value = val;
    practiceSubjects();
  }

  // Link dashboard to education with one recommendation
  const oldRenderRecommendationsEdu = window.renderRecommendations;
  if(typeof oldRenderRecommendationsEdu === "function"){
    window.renderRecommendations = function(){
      oldRenderRecommendationsEdu();
      const list = document.getElementById("recommendationCards");
      if(list && !list.querySelector('[data-rec-view="education"]')){
        const b = document.createElement("button");
        b.className="recommend-item";
        b.dataset.recView="education";
        b.style.cssText="width:100%;text-align:left;background:white";
        b.innerHTML='<span>📚</span><div><strong>Oefen adaptief</strong><small>Laat de moeilijkheid meegroeien met je mastery.</small></div>';
        b.onclick=()=>goView("education");
        list.appendChild(b);
      }
    };
  }

  renderLadder();
  renderCurriculum();
  setDefaultStage();
  renderMasteryList();
  renderSchools();
})();
