# StudentOS 360 — V17 Deploy Ready

## Gratis limieten

### Ingelogde gebruiker
- 100 tekst-AI-verzoeken per dag
- 8 AI-afbeeldingen per dag

Deze worden afgedwongen via Supabase in `consume_ai_quota()`.

### Gast
- 25 tekst-AI-verzoeken per 24 uur
- 5 AI-afbeeldingen per 24 uur

Gastlimieten worden server-side afgedwongen.

Belangrijk: de eindgebruiker kan dit gratis ervaren, maar AI-verzoeken kosten de eigenaar van StudentOS nog steeds geld.

## Deploymentbestanden
- `render.yaml`
- `railway.json`
- `Dockerfile`
- `.github/workflows/check.yml`
- `scripts/production-check.mjs`

## Live architectuur
Eén Node/Express-webservice serveert:
- `index.html`
- CSS/JavaScript
- `/api/tutor`
- `/api/studio/*`
- `/api/public-config`
- `/api/health`

Supabase verzorgt:
- accounts
- RLS
- profielen/state
- projecten
- mastery
- AI-usage quota

OpenAI wordt uitsluitend server-side aangeroepen.

## Wat nog door de eigenaar moet gebeuren
1. Supabase-project aanmaken.
2. `backend/schema.sql` uitvoeren.
3. OpenAI API-key aanmaken.
4. Repository naar GitHub pushen.
5. Render of Railway koppelen.
6. Environment variables instellen.
7. Deployen.
8. `/api/health` controleren.
