import fs from "node:fs";
const files=["index.html","styles.css","app.js","education.js","education-data.js","backend/server.mjs","backend/schema.sql","package.json","Dockerfile"];
let fail=false;
for(const f of files){const ok=fs.existsSync(f);console.log(`${ok?"✓":"✗"} ${f}`);if(!ok)fail=true;}
for(const k of ["OPENAI_API_KEY","SUPABASE_URL","SUPABASE_PUBLISHABLE_KEY"]){console.log(`${process.env[k]?"✓":"○"} ENV ${k}`);}
if(fail)process.exit(1);
