# StudentOS Studio AI — V8

## Productpositionering

StudentOS Studio AI combineert zes soorten workflows in één eigen omgeving:

1. **Ask AI**
   - algemene vragen
   - snel / gebalanceerd / diep
   - optionele actuele webcontrole

2. **Research**
   - zoekt eerst op het web
   - geeft bronlijst terug
   - bedoeld voor feitelijke en actuele vragen

3. **Presentation Builder**
   - genereert een slideverhaal
   - visuele StudentOS slide-preview
   - slides zijn inline bewerkbaar
   - PPTX-export via PptxGenJS
   - kan eerst webresearch doen

4. **Research-first Writer**
   - optioneel verplichte webcontrole
   - verslag/essay/onderzoek/zakelijk rapport
   - natuurlijke schrijfstijl
   - geen verzonnen bronnen of persoonlijke ervaringen

5. **Natural Rewrite**
   - verbetert flow, toon, leesbaarheid en zinsvariatie
   - NIET gepositioneerd als AI-detector bypass

6. **Poster Designer**
   - AI-gegenereerd artwork
   - scherpe HTML-tekstoverlay
   - verschillende aspect ratios
   - PNG export met html2canvas

## Geen exacte kopieën van concurrenten

StudentOS mag functioneel concurreren met tools zoals presentatiebouwers,
chatassistenten en designplatforms, maar gebruikt:
- eigen naam
- eigen interface
- eigen iconografie
- eigen layouts
- eigen workflow

Geen gekopieerde merkassets, logo's of pixel-perfect proprietary UI.

## Waarheidscontrole

Voor Research en Research-first Report gebruikt de OpenAI Responses API:
`tools: [{ type: "web_search" }]`

De backend extraheert `url_citation`-annotations en stuurt die terug naar de frontend,
waar ze als klikbare bronnen worden weergegeven.

## Presentaties

AI genereert een compacte JSON deckstructuur. De browser rendert deze als slides.
PPTXGenJS maakt er een echte `.pptx` van.

Volgende presentatieversie:
- AI-beelden per slide
- meerdere thema's
- charts
- iconen
- drag/drop
- speaker notes
- templates
- PDF export
- upload bestaand PPTX en verbeteren

## Posters

GPT Image genereert alleen het artwork/background.
De titel/subtekst worden door StudentOS als HTML-overlay gezet zodat tekst scherp blijft.

Volgende designversie:
- drag/drop lagen
- lettertypes
- kleuren
- upload eigen foto's/logo
- templates
- stickers/vormen
- resize naar Instagram/Facebook/print

## Gratis businessmodel

"Gratis voor gebruiker" betekent niet "gratis infrastructuur".

AI inference, web search en image generation kunnen kosten veroorzaken.
Aanbevolen gratis productbeleid:
- gewone lokale leerfuncties: onbeperkt gratis
- Ask AI: dagelijkse limiet
- Research: kleinere dagelijkse limiet
- Images: 1–3 gratis generaties/dag
- Presentatie: outline gratis, zware beeldgeneratie gelimiteerd
- caching voor herhaalde schoolvragen
- goedkope modelroutes voor eenvoudige taken
- zwaardere modellen alleen wanneer nodig

Voeg rate limiting en usage tables toe vóór publieke release.

## Minderjarigen

Omdat StudentOS gebruikers onder 18 bedient, moeten vóór publieke release
leeftijdsgerichte safeguards, disclosures, monitoring, privacybeleid en waar nodig
ouder-/voogdflows juridisch en technisch worden geïmplementeerd.
