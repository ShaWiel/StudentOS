# SCHOLARK — V19 Freemium

Free: $0 — 100 tekst-AI/dag, 8 images/dag, Tutor, adaptief leren, planner, studiekeuze, Ask AI en Natural Rewrite.
Plus: $9.99/maand — 350 tekst-AI/dag, 25 images/dag, Research, Presentaties, Verslagen en Poster Designer.
Pro: $14.99/maand — 1.000 tekst-AI/dag, 60 images/dag en hoogste AI-model.

Modelrouting: Free = GPT-5.6 Luna, Plus = GPT-5.6 Terra, Pro = GPT-5.6 Sol.
Checkout is nog niet gekoppeld. Upgrade-knoppen slaan planinteresse op in Supabase.
Planinformatie is server-side leidend; de browser kan zichzelf niet upgraden.
