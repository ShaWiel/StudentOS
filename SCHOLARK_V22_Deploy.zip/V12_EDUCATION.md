# SCHOLARK — V12 Education & Adaptive Learning

V12 brengt SCHOLARK terug naar zijn kern: onderwijs.

## Officiële structuur
De onderwijsstructuur in de UI gebruikt de huidige MinOWC-indeling:
- primair onderwijs: GLO / basisschool
- secundair onderwijs: VOJ en VOS
- tertiair onderwijs: postsecundair/hoger onderwijs
- curriculumontwikkeling binnen MinOWC loopt daarnaast van ECD/peuters tot volwasseneneducatie

## Curriculumkaart
De curriculumkaart maakt bewust onderscheid tussen:
- **brongekoppelde onderdelen** — rechtstreeks ondersteund door een officiële MinOWC-bron
- **SCHOLARK studiekaart** — praktische leerdomeinen om de app te kunnen structureren, maar niet gepresenteerd als volledig officieel curriculum

Voor basisonderwijs zijn taal en rekenen plus AGN/expressie gekoppeld aan officiële MinOWC-programmering.
Voor beroepsonderwijs zijn streams en programmagebieden uit de actuele beroepsonderwijs-directory gebruikt.

## School Finder
De eerste echte schooldirectory bevat vooral beroepsonderwijs:
- NATIN
- AMTO
- IMEAO
- STS
- LBO
- Vocational College Suriname
- Scholengemeenschap Moengotapoe
- regionale scholen/routes

De dataset gebruikt de actuele MinOWC beroepsonderwijs-pagina als bron.
GLO/VOJ/VOS heeft ook een officiële overheidsscholenlijst, maar de publieke XLSX is ouder; vóór launch moet SCHOLARK deze centraal importeren en periodiek laten verifiëren.

## Adaptief oefenen
V12 bevat een echte lokale adaptive loop:
1. mastery-score per stage/subject/topic
2. moeilijkheid gekozen op mastery
3. correct antwoord verhoogt mastery
4. fout antwoord verlaagt mastery
5. volgende vraag past zich aan
6. sessies bestaan uit 5 vragen
7. uitleg kan worden doorgestuurd naar de Tutor

Starter question banks:
- Basisonderwijs: breuken, percentages, begrijpend lezen
- VOJ: algebra, grammatica
- VOS: economie (inflatie, vraag/aanbod), algebra
- Volwassen: online veiligheid

## Studie & beroep
Route Navigator koppelt:
- interesse
- voorkeursactiviteit
- mogelijke beroepen
- studierichtingen
- vaardigheden
- volgende acties

Dit blijft oriëntatie, geen officiële toelatingsbeslissing.

## Actuele AdeKUS-blokken
V12 toont:
- algemene bachelor-aanmelding 2026–2027: 4–31 augustus 2026
- actuele Numerus Fixus-meldingen voor Psychologie en Biologie als voorbeelden van informatie die los van algemene studieprofielen bijgewerkt moet worden

## Database
`backend/schema.sql` bevat nu ook:
- learning_mastery
- practice_attempts
- education_resources
- school_directory

## Volgende stap V13
- volledige officiële schoolimport
- curricula per leerjaar, niet alleen per niveau
- AI-generated quizvragen binnen gecontroleerde leerdoelen
- spaced repetition
- diagnosetoets
- ouderdashboard
- docentdashboard
- rapportage per vak
- echte cloud mastery-sync
- aanbevolen lessen op basis van zwakke onderwerpen
