# SCHOLARK — V9 Editors

V9 verandert Studio AI van alleen "genereren" naar **bewerken**.

## Presentation Editor

Nieuwe functies:
- slides toevoegen
- slides dupliceren
- slides verwijderen
- slide thumbnails
- selecteerbare tekstblokken
- drag & drop op canvas
- tekst wijzigen
- lettergrootte
- kleur
- uitlijning
- breedte
- z-index / naar voren
- AI Design Assist per slide
- bestaande PPTX-export blijft werken

## Poster Editor

Nieuwe functies:
- titel/subtekst als losse lagen
- vrije tekstlaag toevoegen
- eigen afbeelding uploaden
- lagen slepen
- lettergrootte aanpassen
- kleur aanpassen
- tekstuitlijning
- vrije lagen verwijderen
- AI Design Assist voor concept/copy
- AI-background generatie
- bestaande PNG-export blijft werken

## Architectuur

V9 blijft bewust een eigen SCHOLARK-editor.

Het doel is functionele concurrentie met presentatie- en designtools,
niet het klonen van hun merkidentiteit of proprietary interface.

## Volgende editorstap

Voor een volwaardige productie-editor zijn daarna logisch:

### Slides
- resize handles
- vormen
- afbeeldingen per slide
- icon library
- grafieken
- tabellen
- alignment guides
- undo/redo
- themes
- speaker notes
- transitions
- collaboration

### Posters
- resize handles
- crop
- rotate
- opacity
- background removal
- shapes
- gradients
- brand kits
- templates
- grid snapping
- undo/redo
- multiple pages

### Platform
- project autosave in Supabase
- project thumbnails
- recent files
- duplicate project
- shared links
- team collaboration
