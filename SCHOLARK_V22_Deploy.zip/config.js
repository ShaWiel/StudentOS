window.STUDENTOS_CONFIG = {
  SUPABASE_URL: "https://cilyfayvknpfytxthmwh.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_JClzcmdFxbyiypc--aAuIA_yAd-mswt",
  API_BASE_URL: ""
};
