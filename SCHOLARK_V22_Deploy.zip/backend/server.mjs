import "dotenv/config";
import express from "express";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cors from "cors";
import OpenAI from "openai";
import { createClient } from "@supabase/supabase-js";
import { Paddle, Environment } from "@paddle/paddle-node-sdk";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const ROOT_DIR=path.resolve(__dirname,"..");
const APP_VERSION="22.0.0-beta1";
app.set("trust proxy",1);

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map(x => x.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Requests from local file:// pages may arrive with no Origin / "null".
    if (!origin || allowedOrigins.includes(origin) || allowedOrigins.includes("null")) {
      return callback(null, true);
    }
    return callback(new Error("Origin not allowed by SCHOLARK CORS policy."));
  }
}));
app.post("/api/billing/paddle-webhook", express.raw({type:"application/json",limit:"128kb"}), handlePaddleWebhook);
app.use(express.json({ limit: "48kb" }));

app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:false,crossOriginResourcePolicy:false}));
app.use(compression());
app.use((req,res,next)=>{
  req.requestId=crypto.randomUUID();
  res.setHeader("X-Request-ID",req.requestId);
  next();
});
const apiLimiter=rateLimit({windowMs:15*60*1000,limit:300,standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Te veel verzoeken. Probeer het later opnieuw."}});
const guestAiLimiter=rateLimit({windowMs:24*60*60*1000,limit:Number(process.env.GUEST_DAILY_AI_LIMIT||25),standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Daglimiet voor gast-AI bereikt. Log in of probeer morgen opnieuw."}});
const guestImageLimiter=rateLimit({windowMs:24*60*60*1000,limit:Number(process.env.GUEST_DAILY_IMAGE_LIMIT||5),standardHeaders:"draft-7",legacyHeaders:false,message:{message:"Daglimiet voor gast-afbeeldingen bereikt."}});
app.use("/api",apiLimiter);


const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const supabase = (process.env.SUPABASE_URL && process.env.SUPABASE_PUBLISHABLE_KEY)
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

// Service-role access is server-only and is used for billing sync, account deletion and atomic cost bookkeeping.
const supabaseAdmin = (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY)
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
      auth:{persistSession:false,autoRefreshToken:false}
    })
  : null;

const paddleEnvironment=String(process.env.PADDLE_ENV||"sandbox").toLowerCase()==="production"?Environment.production:Environment.sandbox;
const paddle=process.env.PADDLE_API_KEY?new Paddle(process.env.PADDLE_API_KEY,{environment:paddleEnvironment}):null;
const billingConfigured=Boolean(
  paddle && supabaseAdmin && process.env.PADDLE_WEBHOOK_SECRET && process.env.PADDLE_CLIENT_TOKEN &&
  process.env.PADDLE_PLUS_PRICE_ID && process.env.PADDLE_PRO_PRICE_ID
);
function billingContextSignature(userId,plan,nonce){return crypto.createHmac("sha256",process.env.PADDLE_WEBHOOK_SECRET||"not-configured").update(`${userId}|${plan}|${nonce}`).digest("hex");}
function validBillingContext(custom={}){
  const userId=cleanString(custom.studentos_user_id,80),plan=cleanString(custom.studentos_plan,10),nonce=cleanString(custom.studentos_nonce,80),sig=cleanString(custom.studentos_signature,128);
  if(!userId||!["plus","pro"].includes(plan)||!nonce||!sig||!process.env.PADDLE_WEBHOOK_SECRET)return false;
  const expected=billingContextSignature(userId,plan,nonce);try{return crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected));}catch{return false;}
}
function planFromPaddleData(data={}){
  const ids=(data.items||[]).map(item=>item?.price?.id||item?.priceId||item?.price_id).filter(Boolean);
  if(process.env.PADDLE_PRO_PRICE_ID&&ids.includes(process.env.PADDLE_PRO_PRICE_ID))return "pro";
  if(process.env.PADDLE_PLUS_PRICE_ID&&ids.includes(process.env.PADDLE_PLUS_PRICE_ID))return "plus";
  return null;
}

const PLAN_CONFIG={
  guest:{rank:0,label:"Guest",model:"gpt-5.6-luna",monthlyBudgetMicros:0,maxOutputTokens:700},
  free:{rank:1,label:"Free",model:"gpt-5.6-luna",monthlyBudgetMicros:750000,maxOutputTokens:900},
  plus:{rank:2,label:"Plus",model:"gpt-5.6-terra",monthlyBudgetMicros:2250000,maxOutputTokens:1800},
  pro:{rank:3,label:"Pro",model:"gpt-5.6-sol",monthlyBudgetMicros:4500000,maxOutputTokens:3000}
};
const MODEL_PRICING_USD_PER_MTOK={
  "gpt-5.6-luna":{input:1,output:6},
  "gpt-5.6-terra":{input:2.5,output:15},
  "gpt-5.6-sol":{input:5,output:30},
  "gpt-5.6":{input:5,output:30}
};
function normalizePlan(plan){return ["free","plus","pro"].includes(plan)?plan:"free";}
function modelForPlan(plan){return PLAN_CONFIG[plan]?.model||PLAN_CONFIG.free.model;}
function isMinorAge(age){const n=Number(age);return Number.isFinite(n)&&n>=3&&n<18;}
function isUnder13(age){const n=Number(age);return Number.isFinite(n)&&n>=3&&n<13;}
function modelForRequest(req){return isMinorAge(req.studentosAge)?"gpt-5.6-sol":modelForPlan(req.studentosPlan);}
function maxOutputForRequest(req,override){const base=PLAN_CONFIG[req.studentosPlan]?.maxOutputTokens||900;return Math.max(300,Math.min(Number(override)||base,isMinorAge(req.studentosAge)?Math.max(base,1200):base));}
async function fetchUserPlan(req,user){
  if(!user)return "guest";const token=getBearer(req);if(!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_PUBLISHABLE_KEY)return "free";
  try{const url=new URL(`${process.env.SUPABASE_URL}/rest/v1/user_subscriptions`);url.searchParams.set("select","plan,status,current_period_end");url.searchParams.set("user_id",`eq.${user.id}`);url.searchParams.set("limit","1");
    const r=await fetch(url,{headers:{"apikey":process.env.SUPABASE_PUBLISHABLE_KEY,"Authorization":`Bearer ${token}`}});if(!r.ok)return "free";const rows=await r.json();const sub=rows?.[0];if(!sub||sub.status!=="active")return "free";return normalizePlan(sub.plan);
  }catch{return "free";}
}
function requirePlan(minPlan="plus"){return (req,res,next)=>{const have=PLAN_CONFIG[req.studentosPlan||"guest"]?.rank||0;const need=PLAN_CONFIG[minPlan]?.rank||2;if(have<need)return res.status(402).json({code:"UPGRADE_REQUIRED",message:`Deze functie hoort bij SCHOLARK ${PLAN_CONFIG[minPlan]?.label||"Plus"}.`,current_plan:req.studentosPlan||"guest",required_plan:minPlan});next();};}

function cleanString(value, max = 2000) {
  return String(value ?? "").trim().slice(0, max);
}

const SUPPORTED_LANGUAGES={nl:"Dutch",en:"English",es:"Spanish",pt:"Portuguese",fr:"French"};
function requestLanguage(req){
  const raw=cleanString(req.body?.language||req.get?.("X-SCHOLARK-Language")||"nl",8).toLowerCase().split("-")[0];
  return SUPPORTED_LANGUAGES[raw]?raw:"nl";
}
function languageName(req){return SUPPORTED_LANGUAGES[requestLanguage(req)]||"Dutch";}

function ageBand(age, stage) {
  const a = Number(age);
  if (stage === "peuter" || a <= 6) return "early_childhood";
  if (stage === "basis" || a <= 12) return "child";
  if (stage === "voj" || stage === "vos" || a <= 17) return "teen";
  if (stage === "senior") return "senior";
  return "adult";
}

async function authenticateOptional(req) {
  if (!supabase) return null;
  const auth = req.get("authorization") || "";
  if (!auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7);
  const { data, error } = await supabase.auth.getUser(token);
  if (error) return null;
  return data.user || null;
}


async function fetchLearnerAge(req,user){
  const bodyAge=Number(req.body?.profile?.age);
  if(Number.isFinite(bodyAge)&&bodyAge>=3&&bodyAge<=120)return bodyAge;
  const token=getBearer(req);
  if(!user||!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_PUBLISHABLE_KEY)return null;
  try{
    const url=new URL(`${process.env.SUPABASE_URL}/rest/v1/profiles`);
    url.searchParams.set("select","age");url.searchParams.set("user_id",`eq.${user.id}`);url.searchParams.set("limit","1");
    const r=await fetch(url,{headers:{apikey:process.env.SUPABASE_PUBLISHABLE_KEY,Authorization:`Bearer ${token}`}});
    if(!r.ok)return null;const rows=await r.json();const age=Number(rows?.[0]?.age);return Number.isFinite(age)?age:null;
  }catch{return null;}
}
function monthKey(){const d=new Date();return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}-01`;}
async function getMonthlyCostMicros(userId){
  if(!supabaseAdmin||!userId)return null;
  const {data,error}=await supabaseAdmin.from("ai_usage_monthly").select("estimated_cost_microusd").eq("user_id",userId).eq("usage_month",monthKey()).maybeSingle();
  if(error){console.warn("Monthly usage read failed",error.message);return null;}return Number(data?.estimated_cost_microusd||0);
}
async function checkMonthlyBudget(req,res){
  if(!req.studentosUser||!supabaseAdmin)return true;
  const cap=PLAN_CONFIG[req.studentosPlan]?.monthlyBudgetMicros||PLAN_CONFIG.free.monthlyBudgetMicros;
  const used=await getMonthlyCostMicros(req.studentosUser.id);
  if(used!==null&&used>=cap){
    res.status(429).json({code:"MONTHLY_FAIR_USE_REACHED",message:"Je maandelijkse AI-fair-use grens is bereikt. De leerfuncties zonder live AI blijven beschikbaar.",plan:req.studentosPlan});return false;
  }
  return true;
}
function countWebSearchCalls(response){return (response?.output||[]).filter(x=>x?.type==="web_search_call").length;}
function estimateTextCostMicros(model,response,webSearchCalls=0){
  const p=MODEL_PRICING_USD_PER_MTOK[model]||MODEL_PRICING_USD_PER_MTOK["gpt-5.6-sol"];
  const input=Number(response?.usage?.input_tokens||0);const output=Number(response?.usage?.output_tokens||0);
  return Math.max(0,Math.round(input*p.input+output*p.output+webSearchCalls*10000));
}
async function recordAiUsage(req,{response=null,model=null,webSearchCalls=0,image=false}={}){
  if(!supabaseAdmin||!req.studentosUser)return;
  const input=Number(response?.usage?.input_tokens||0);const output=Number(response?.usage?.output_tokens||0);
  // Image generation usage is provider/model dependent. A conservative $0.10 reserve per generated image prevents runaway spend.
  const estimated=image?100000:estimateTextCostMicros(model||modelForRequest(req),response,webSearchCalls);
  const {error}=await supabaseAdmin.rpc("record_ai_usage",{p_user_id:req.studentosUser.id,p_input_tokens:input,p_output_tokens:output,p_web_search_calls:webSearchCalls,p_image_requests:image?1:0,p_estimated_cost_microusd:estimated});
  if(error)console.warn("Usage bookkeeping failed",error.message);
}


function getBearer(req){
  const auth=req.get("authorization")||"";
  return auth.startsWith("Bearer ")?auth.slice(7):"";
}
function safetyIdentifier(req,user){
  const raw=user?.id||`${req.ip}|${req.get("user-agent")||"guest"}`;
  return "sos_"+crypto.createHash("sha256").update(raw).digest("hex").slice(0,32);
}
async function moderateText(text){
  if(!openai||!text)return {flagged:false};
  const result=await openai.moderations.create({model:"omni-moderation-latest",input:text});
  return {flagged:Boolean(result.results?.[0]?.flagged),categories:result.results?.[0]?.categories||{}};
}
async function consumeCloudQuota(req,kind){
  const token=getBearer(req);
  if(!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_PUBLISHABLE_KEY)return null;
  const r=await fetch(`${process.env.SUPABASE_URL}/rest/v1/rpc/consume_ai_quota`,{
    method:"POST",
    headers:{"Content-Type":"application/json","apikey":process.env.SUPABASE_PUBLISHABLE_KEY,"Authorization":`Bearer ${token}`},
    body:JSON.stringify({p_kind:kind})
  });
  if(!r.ok)return null;
  const data=await r.json();
  return Array.isArray(data)?data[0]:data;
}
async function enforceAiAccess(req,res,next,kind="text"){
  try{
    const user=await authenticateOptional(req);
    req.studentosUser=user;
    req.safetyIdentifier=safetyIdentifier(req,user);
    req.studentosAge=await fetchLearnerAge(req,user);
    if(isUnder13(req.studentosAge)&&String(process.env.OPENAI_ZERO_DATA_RETENTION_CONFIRMED||"").toLowerCase()!=="true"){
      return res.status(403).json({code:"UNDER13_LIVE_AI_DISABLED",message:"Live AI is voor profielen jonger dan 13 uitgeschakeld totdat SCHOLARK Zero Data Retention voor deze verwerking heeft bevestigd. Oefenen, planner en lokale leerfuncties blijven beschikbaar."});
    }
    if(user){
      req.studentosPlan=await fetchUserPlan(req,user);
      if(!(await checkMonthlyBudget(req,res)))return;
      const quota=await consumeCloudQuota(req,kind);
      if(quota&&quota.allowed===false)return res.status(429).json({message:"Je daglimiet is bereikt.",remaining:quota.remaining??0});
      req.quota=quota;
      return next();
    }
    req.studentosPlan="guest";
    return (kind==="image"?guestImageLimiter:guestAiLimiter)(req,res,next);
  }catch(err){return next(err);}
}
async function safeInputOrReject(req,res,text){
  try{
    const mod=await moderateText(text);
    if(mod.flagged){res.status(400).json({message:"Deze invoer kan niet via SCHOLARK AI worden verwerkt. Probeer de vraag veiliger of educatiever te formuleren."});return false;}
    return true;
  }catch(err){console.warn("Moderation unavailable",err);return true;}
}


function tutorInstructions({ profile, explanationLevel, learningStyle, language="Dutch" }) {
  const age = Number(profile.age) || null;
  const stage = cleanString(profile.stage, 40) || "volwassene";
  const band = ageBand(age, stage);
  const goal = cleanString(profile.goal, 120);
  const subjects = cleanString(profile.subjects, 300);

  return `
You are SCHOLARK Tutor, a multilingual educational tutor designed for users in Suriname and beyond across many life stages.

USER CONTEXT
- Display name: ${cleanString(profile.name, 60) || "gebruiker"}
- Age: ${age ?? "unknown"}
- Learning stage: ${stage}
- Age band: ${band}
- Main goal: ${goal || "general learning"}
- Relevant subjects: ${subjects || "not specified"}
- Requested explanation depth: ${cleanString(explanationLevel, 30)}
- Preferred learning style: ${cleanString(learningStyle, 30)}

CORE TEACHING RULES
1. Respond in clear ${language}. If the learner explicitly asks for another language, follow that request when safe and practical.
2. Adapt vocabulary, sentence length, examples, and conceptual depth to the learner's age/stage.
3. Teach; do not merely dump an answer. Explain the reasoning at an appropriate level, then give a small check-for-understanding or next step when useful.
4. When the user asks for schoolwork, help them learn how to do it. Do not falsely claim their work is factually verified if it is not.
5. If information is uncertain or depends on a school/institution's current rules, say that it must be verified from the official institution.
6. Do not shame mistakes. Correct them clearly and concretely.
7. For very young learners, keep answers short, concrete, playful, and easy to read with an adult.
8. For senior users, prioritize simple step-by-step practical instructions and avoid jargon.
9. Never ask the user to reveal passwords, verification codes, exact home address, banking credentials, or other unnecessary sensitive information.
10. For dangerous, illegal, self-harm, sexual, or other age-inappropriate requests, follow platform safety rules and redirect toward safe educational help.
11. Do not pretend to have completed real-world actions (submitting forms, sending emails, enrolling at school, paying bills) unless the application actually performed them.
12. Avoid overlong introductions. Start with the explanation.

OUTPUT STYLE
- Use plain text with short headings where useful.
- Prefer concise paragraphs and numbered steps.
- If learning_style is "quiz", end with 2–3 short questions but do not reveal answers immediately.
- If learning_style is "voorbeeld", include at least one concrete example.
- If learning_style is "stappen", use an explicit step-by-step sequence.
`.trim();
}

app.get("/api/public-config",(_req,res)=>{
  res.setHeader("Cache-Control","no-store");
  res.json({
    SUPABASE_URL:process.env.SUPABASE_URL||"",
    SUPABASE_PUBLISHABLE_KEY:process.env.SUPABASE_PUBLISHABLE_KEY||"",
    API_BASE_URL:"",
    cloud_enabled:Boolean(process.env.SUPABASE_URL&&process.env.SUPABASE_PUBLISHABLE_KEY),
    release_channel:"public_beta",
    billing:{enabled:billingConfigured,environment:String(process.env.PADDLE_ENV||"sandbox"),client_token:billingConfigured?process.env.PADDLE_CLIENT_TOKEN:"",prices:{plus:billingConfigured?process.env.PADDLE_PLUS_PRICE_ID:"",pro:billingConfigured?process.env.PADDLE_PRO_PRICE_ID:""}}
  });
});

app.get("/api/health", (_req, res) => {
  res.setHeader("Cache-Control","no-store");
  res.json({
    ok:true,version:`V${APP_VERSION}`,uptime_seconds:Math.round(process.uptime()),
    ai_configured:Boolean(openai),auth_verification_configured:Boolean(supabase),admin_configured:Boolean(supabaseAdmin),billing_configured:billingConfigured,
    under13_live_ai_ready:String(process.env.OPENAI_ZERO_DATA_RETENTION_CONFIRMED||"").toLowerCase()==="true",
    model_policy:"Free=Luna • Plus=Terra • Pro=Sol; minors use Sol",environment:process.env.NODE_ENV||"development"
  });
});

app.post("/api/tutor", (req,res,next)=>enforceAiAccess(req,res,next,"text"), async (req, res) => {
  try {
    const question = cleanString(req.body?.question, 5000);
    if (!question) return res.status(400).json({ message: "Stel eerst een vraag." });
    if (!openai) return res.status(503).json({ message: "OPENAI_API_KEY is nog niet ingesteld op de server." });

    const profile = req.body?.profile || {};
    if(!(await safeInputOrReject(req,res,question)))return;
    const user = req.studentosUser || null;

    const instructions = tutorInstructions({
      profile,
      explanationLevel: req.body?.explanation_level || "normaal",
      learningStyle: req.body?.learning_style || "stappen",
      language: languageName(req)
    });

    const response = await openai.responses.create({
      model:modelForRequest(req),
      instructions,
      input: question,
      max_output_tokens:maxOutputForRequest(req),
      store:false,
      safety_identifier:req.safetyIdentifier
    });
    await recordAiUsage(req,{response,model:modelForRequest(req)});

    const answer = response.output_text?.trim();
    if (!answer) return res.status(502).json({ message: "De AI leverde geen tekstantwoord." });

    // Tiny topic label for progress tracking. We avoid a second model call.
    const topic = question
      .replace(/[?.!,]/g, " ")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 5)
      .join(" ")
      .slice(0, 80);

    res.json({
      ok: true,
      answer,
      topic,
      authenticated: Boolean(user)
    });
  } catch (error) {
    console.error("Tutor error:", error);
    res.status(500).json({
      message: "De Tutor kon deze vraag niet verwerken.",
      detail: process.env.NODE_ENV === "development" ? String(error?.message || error) : undefined
    });
  }
});



/* ===========================
   SCHOLARK V8 — STUDIO API
   =========================== */

function uniqueCitations(response){
  const out=[];
  const seen=new Set();
  for(const item of response.output || []){
    if(item.type !== "message") continue;
    for(const content of item.content || []){
      for(const ann of content.annotations || []){
        if(ann.type === "url_citation" && ann.url && !seen.has(ann.url)){
          seen.add(ann.url);
          out.push({ title: ann.title || ann.url, url: ann.url });
        }
      }
    }
  }
  return out;
}

function studioAgeRules(profile={}){
  const age=Number(profile.age)||null;
  const stage=cleanString(profile.stage,40)||"volwassene";
  return `
The user may be a minor. Age: ${age ?? "unknown"}, stage: ${stage}.
Adapt content to age and learning level.
For minors, keep content age-appropriate, educational, privacy-conscious and safe.
Do not request unnecessary personal information.
`.trim();
}

function reasoningNote(mode){
  if(mode==="deep") return "Think carefully and provide a rigorous answer, but do not expose private chain-of-thought. Give concise reasoning summaries when useful.";
  if(mode==="balanced") return "Balance speed and depth. Check assumptions before answering.";
  return "Answer efficiently and clearly.";
}

async function runStudioText({prompt,instructions,useWeb=false,mode="balanced",safetyIdentifier="",req,maxOutputTokens=null}){
  if(!openai) throw new Error("OPENAI_API_KEY is niet ingesteld.");
  const model=modelForRequest(req);
  const response=await openai.responses.create({
    model,
    instructions:`${instructions}\n\n${reasoningNote(mode)}`,
    ...(useWeb ? {tools:[{type:"web_search"}]} : {}),
    input:prompt,
    max_output_tokens:maxOutputForRequest(req,maxOutputTokens),
    store:false,
    ...(safetyIdentifier?{safety_identifier:safetyIdentifier}:{})
  });
  const webSearchCalls=countWebSearchCalls(response);
  await recordAiUsage(req,{response,model,webSearchCalls});
  return {
    answer:response.output_text?.trim() || "",
    citations:uniqueCitations(response)
  };
}

app.post("/api/studio/chat",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,8000);
    if(!prompt)return res.status(400).json({message:"Typ eerst een vraag."});
    const profile=req.body?.profile||{};
    const verify=Boolean(req.body?.verify_web);
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      req,
      prompt,
      useWeb:verify,
      safetyIdentifier:req.safetyIdentifier,
      mode:req.body?.mode||"balanced",
      instructions:`
You are SCHOLARK Studio AI, a versatile multilingual assistant.
Respond in ${languageName(req)}.
Answer accurately, clearly and directly.
If web search is enabled, use it whenever freshness or factual verification matters.
Do not invent sources, statistics or current facts.
Separate known facts from estimates or opinions.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Ask AI kon de vraag niet verwerken."});
  }
});

app.post("/api/studio/research",(req,res,next)=>enforceAiAccess(req,res,next,"text"),requirePlan("plus"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,8000);
    if(!prompt)return res.status(400).json({message:"Vul een onderzoeksvraag in."});
    const level=cleanString(req.body?.level,30);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      req,
      prompt,
      useWeb:true,
      safetyIdentifier:req.safetyIdentifier,
      mode:"deep",
      instructions:`
You are the SCHOLARK Research assistant.
Research the user's question on the live web before answering.
Prioritize primary sources, official institutions, peer-reviewed research, government sources, reputable universities, recognized international organizations, and credible reporting when appropriate.
Cross-check important claims when feasible.
If reliable sources disagree, say so.
Do not fabricate references.
Write in ${languageName(req)}.
Research depth: ${level}.
Use concise headings and a clear conclusion.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Research kon niet worden uitgevoerd."});
  }
});

app.post("/api/studio/report",(req,res,next)=>enforceAiAccess(req,res,next,"text"),requirePlan("plus"),async(req,res)=>{
  try{
    const prompt=cleanString(req.body?.prompt,12000);
    if(!prompt)return res.status(400).json({message:"Vul een onderwerp of opdracht in."});
    const useWeb=Boolean(req.body?.verify_web);
    const type=cleanString(req.body?.type,30);
    const length=cleanString(req.body?.length,30);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,prompt)))return;
    const result=await runStudioText({
      req,
      prompt,
      useWeb,
      safetyIdentifier:req.safetyIdentifier,
      mode:"deep",
      instructions:`
You are SCHOLARK Research-first Writer.
Create a well-structured ${type} report draft in ${languageName(req)}.
Desired length: ${length}.
${useWeb ? `
Before writing, research relevant factual claims on the web.
Use reliable sources and avoid unsupported claims.
If facts cannot be verified, flag them rather than inventing them.
` : `
Do not claim facts were web-verified. Mark uncertain current facts for verification.
`}
Write with natural rhythm, varied sentence structure, appropriate transitions and vocabulary that fits the user's stage.
Do not fabricate personal experiences or pretend the user personally conducted research they did not conduct.
Do not write for the purpose of bypassing plagiarism or AI-detection systems.
Where appropriate, include an introduction, logical body sections, conclusion and a short source note.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"Het verslag kon niet worden gemaakt."});
  }
});

app.post("/api/studio/rewrite",(req,res,next)=>enforceAiAccess(req,res,next,"text"),async(req,res)=>{
  try{
    const text=cleanString(req.body?.text,16000);
    if(!text)return res.status(400).json({message:"Plak eerst tekst."});
    const style=cleanString(req.body?.style,40);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,text)))return;
    const result=await runStudioText({
      req,
      prompt:text,
      useWeb:false,
      safetyIdentifier:req.safetyIdentifier,
      mode:"balanced",
      instructions:`
You are SCHOLARK Natural Rewrite.
Rewrite the supplied text in ${languageName(req)} while preserving its meaning and factual content.
Style: ${style}.
Improve natural flow, sentence variety, clarity and tone.
Avoid repetitive AI-like filler, excessive headings and inflated vocabulary.
Do not invent personal anecdotes, qualifications, sources, events or facts.
Do not claim that the output is undetectable as AI and do not optimize for evading detection systems.
Return only the improved text unless clarification is essential.
${studioAgeRules(profile)}
      `.trim()
    });
    res.json({ok:true,...result});
  }catch(err){
    console.error(err);res.status(500).json({message:"De tekst kon niet worden herschreven."});
  }
});

function parseDeckJson(text){
  const cleaned=String(text||"")
    .replace(/^```json\s*/i,"")
    .replace(/^```\s*/,"")
    .replace(/\s*```$/,"")
    .trim();
  return JSON.parse(cleaned);
}

app.post("/api/studio/presentation",(req,res,next)=>enforceAiAccess(req,res,next,"text"),requirePlan("plus"),async(req,res)=>{
  try{
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    const topic=cleanString(req.body?.topic,500);
    if(!topic)return res.status(400).json({message:"Vul een onderwerp in."});
    const audience=cleanString(req.body?.audience,200);
    const count=Math.max(4,Math.min(15,Number(req.body?.slide_count)||8));
    const style=cleanString(req.body?.style,30)||"modern";
    const useWeb=Boolean(req.body?.verify_web);
    const profile=req.body?.profile||{};
    if(!(await safeInputOrReject(req,res,topic)))return;

    const response=await openai.responses.create({
      model:modelForRequest(req),
      instructions:`
You are SCHOLARK Presentation Architect.
Create a compelling slide narrative, not a document broken into slides.
Audience: ${audience || "general"}.
Number of slides: exactly ${count}.
Style: ${style}.
${useWeb ? "Use web search to verify relevant factual claims before constructing the deck. Do not fabricate facts." : "Do not pretend current facts were verified."}
Each slide must have ONE clear message and concise body copy.
Return ONLY valid JSON, no markdown fences:
{
  "title":"...",
  "style":"${style}",
  "slides":[
    {"title":"...","body":"...","layout":"hero|content|comparison|quote|closing"}
  ]
}
Body copy should be concise enough for a real presentation.
Write all user-facing slide content in ${languageName(req)}.
${studioAgeRules(profile)}
      `.trim(),
      ...(useWeb?{tools:[{type:"web_search"}]}:{}),
      input:`Maak een presentatie over: ${topic}`,
      max_output_tokens:maxOutputForRequest(req,req.studentosPlan==="pro"?3200:2200),
      store:false,
      safety_identifier:req.safetyIdentifier
    });
    await recordAiUsage(req,{response,model:modelForRequest(req),webSearchCalls:countWebSearchCalls(response)});

    let deck;
    try{
      deck=parseDeckJson(response.output_text);
    }catch{
      return res.status(502).json({message:"De presentatie-inhoud kwam niet in geldig JSON-formaat terug."});
    }
    if(!Array.isArray(deck.slides))return res.status(502).json({message:"Ongeldige deckstructuur."});
    deck.slides=deck.slides.slice(0,count);
    res.json({ok:true,deck,citations:uniqueCitations(response)});
  }catch(err){
    console.error(err);res.status(500).json({message:"De presentatie kon niet worden gegenereerd."});
  }
});

app.post("/api/studio/poster",(req,res,next)=>enforceAiAccess(req,res,next,"image"),requirePlan("plus"),async(req,res)=>{
  try{
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    const title=cleanString(req.body?.title,300);
    const subtitle=cleanString(req.body?.subtitle,600);
    const visual=cleanString(req.body?.visual,1200);
    const format=cleanString(req.body?.format,30)||"portrait";
    if(!(await safeInputOrReject(req,res,[title,subtitle,visual].filter(Boolean).join("\n"))))return;
    const size=format==="landscape"?"1536x1024":format==="square"?"1024x1024":"1024x1536";

    // Generate artwork WITHOUT critical text: SCHOLARK overlays crisp editable text in-browser.
    const prompt=`
Create premium poster artwork/background for a design titled "${title}".
Visual brief: ${visual || "modern, professional, high-impact editorial design"}.
Supporting context: ${subtitle}.
Do NOT render logos or brand marks of Canva, Gamma, ChatGPT, Gemini, DeepSeek, or other third-party products.
Do NOT put essential readable headline text in the image; leave strong negative space for typography overlay.
Composition should work as a ${format} poster.
High visual hierarchy, polished professional advertising quality.
`.trim();

    const result=await openai.images.generate({
      model:process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
      prompt,
      size
    });
    await recordAiUsage(req,{response:result,model:process.env.OPENAI_IMAGE_MODEL||"gpt-image-2",image:true});
    const b64=result.data?.[0]?.b64_json;
    if(!b64)return res.status(502).json({message:"Geen afbeelding ontvangen."});
    res.json({ok:true,image_data_url:`data:image/png;base64,${b64}`});
  }catch(err){
    console.error(err);res.status(500).json({message:"De posterafbeelding kon niet worden gegenereerd."});
  }
});




app.post("/api/studio/design-edit",(req,res,next)=>enforceAiAccess(req,res,next,"text"),requirePlan("plus"),async(req,res)=>{
  try{
    const kind=cleanString(req.body?.kind,30);
    const instruction=cleanString(req.body?.instruction,1200);
    const content=req.body?.content||{};
    const context=req.body?.context||{};
    if(!instruction)return res.status(400).json({message:"Geef een ontwerp-instructie."});
    if(!openai)return res.status(503).json({message:"AI is niet geconfigureerd."});
    if(!(await safeInputOrReject(req,res,instruction)))return;

    const response=await openai.responses.create({
      model:modelForRequest(req),
      instructions:`
You are SCHOLARK Design Assist.
You improve content structure and design direction without copying another brand's proprietary interface or assets.
Return ONLY valid JSON and no markdown fences.

If kind is "slide", return:
{"title":"...","body":"..."}

If kind is "poster", return:
{"title":"...","subtitle":"...","visual":"..."}

Keep the user's meaning, but make the content clearer, stronger, more visually usable and appropriate for the audience.
Write user-facing content in ${languageName(req)}.
Do not invent factual claims.
`.trim(),
      input:JSON.stringify({kind,instruction,content,context}),
      max_output_tokens:maxOutputForRequest(req,900),
      store:false,
      safety_identifier:req.safetyIdentifier
    });
    await recordAiUsage(req,{response,model:modelForRequest(req)});

    const raw=String(response.output_text||"").replace(/^```json\s*/i,"").replace(/^```\s*/,"").replace(/\s*```$/,"").trim();
    const data=JSON.parse(raw);
    res.json({ok:true,...data});
  }catch(err){
    console.error(err);res.status(500).json({message:"Design Assist kon de wijziging niet uitvoeren."});
  }
});



async function handlePaddleWebhook(req,res){
  if(!paddle||!supabaseAdmin||!process.env.PADDLE_WEBHOOK_SECRET)return res.status(503).send("billing not configured");
  const signature=req.get("paddle-signature")||"";
  try{
    const raw=req.body.toString();
    const eventData=await paddle.webhooks.unmarshal(raw,process.env.PADDLE_WEBHOOK_SECRET,signature);
    const eventId=eventData.eventId||eventData.notificationId||crypto.createHash("sha256").update(raw).digest("hex");
    const {error:eventError}=await supabaseAdmin.from("billing_events").insert({event_id:String(eventId),event_type:String(eventData.eventType||"unknown")});
    if(eventError?.code==="23505")return res.status(200).send("already processed");
    if(eventError)console.warn("Billing event log failed",eventError.message);

    const data=eventData.data||{};const custom=data.customData||data.custom_data||{};
    const uid=cleanString(custom.studentos_user_id,80);const signedPlan=cleanString(custom.studentos_plan,10);const purchasedPlan=planFromPaddleData(data);
    const relevant=["subscription.created","subscription.activated","subscription.updated","subscription.canceled"];
    if(uid&&relevant.includes(eventData.eventType)){
      if(!validBillingContext(custom))throw new Error("Invalid SCHOLARK billing context signature");
      if(eventData.eventType!=="subscription.canceled"&&(!purchasedPlan||purchasedPlan!==signedPlan))throw new Error("Purchased Paddle price does not match signed SCHOLARK plan");
      const canceled=eventData.eventType==="subscription.canceled"||String(data.status||"").toLowerCase()==="canceled";
      const status=canceled?"canceled":(["active","trialing","past_due"].includes(String(data.status||""))?String(data.status):"active");
      const periodEnd=data.currentBillingPeriod?.endsAt||data.current_billing_period?.ends_at||data.nextBilledAt||data.next_billed_at||null;
      const row={user_id:uid,plan:canceled?"free":purchasedPlan,status:canceled?"active":status,current_period_end:periodEnd,provider:"paddle",provider_customer_id:data.customerId||data.customer_id||null,provider_subscription_id:data.id||null,updated_at:new Date().toISOString()};
      const {error}=await supabaseAdmin.from("user_subscriptions").upsert(row,{onConflict:"user_id"});
      if(error)throw error;
    }
    res.status(200).send("ok");
  }catch(err){console.error("Paddle webhook error",err);res.status(400).send("invalid webhook");}
}

app.get("/api/billing/config",(_req,res)=>res.json({enabled:billingConfigured,environment:String(process.env.PADDLE_ENV||"sandbox"),client_token:billingConfigured?process.env.PADDLE_CLIENT_TOKEN:"",prices:{plus:billingConfigured?process.env.PADDLE_PLUS_PRICE_ID:"",pro:billingConfigured?process.env.PADDLE_PRO_PRICE_ID:""}}));
app.post("/api/billing/checkout-context",async(req,res)=>{
  if(!billingConfigured)return res.status(503).json({message:"Billing is nog niet volledig geconfigureerd."});
  const user=await authenticateOptional(req);if(!user)return res.status(401).json({message:"Log eerst in."});
  const plan=cleanString(req.body?.plan,10);if(!["plus","pro"].includes(plan))return res.status(400).json({message:"Ongeldig abonnement."});
  const nonce=crypto.randomUUID();res.json({user_id:user.id,plan,nonce,signature:billingContextSignature(user.id,plan,nonce)});
});

app.post("/api/account/delete",async(req,res)=>{
  try{
    if(!supabaseAdmin)return res.status(503).json({message:"Accountverwijdering is nog niet server-side geconfigureerd."});
    const user=await authenticateOptional(req);if(!user)return res.status(401).json({message:"Log opnieuw in voordat je je account verwijdert."});
    const {error}=await supabaseAdmin.auth.admin.deleteUser(user.id);if(error)throw error;
    res.json({ok:true});
  }catch(err){console.error("Delete account error",err);res.status(500).json({message:"Account kon niet worden verwijderd."});}
});

app.use(express.static(ROOT_DIR,{extensions:["html"],maxAge:process.env.NODE_ENV==="production"?"1h":0}));
app.get(/^(?!\/api).*/,(_req,res)=>res.sendFile(path.join(ROOT_DIR,"index.html")));
app.use((err,req,res,_next)=>{
  console.error(`[${req.requestId||"no-id"}]`,err);
  res.status(500).json({message:"Er ging iets mis op de SCHOLARK-server.",request_id:req.requestId});
});

app.listen(PORT, () => {
  console.log(`SCHOLARK V22 Multilingual Beta: http://localhost:${PORT}`);
});
