# SCHOLARK — V18 Connected Build

Deze build is al gekoppeld aan het echte SCHOLARK Supabase-project via de publieke Project URL en Publishable key.

Er staat geen OpenAI API-key en geen Supabase service-role key in de browserconfiguratie.

## Al live in Supabase
- profiles
- user_state
- study_tasks
- learning_goals
- projects
- project_versions
- project_comments
- project_share_links
- learning_mastery
- practice_attempts
- education_resources
- school_directory
- ai_usage_daily

RLS is ingeschakeld.

## Gratis limieten
- ingelogd: 100 tekst-AI / dag
- ingelogd: 8 AI-images / dag
- gast: 25 tekst-AI / dag
- gast: 5 AI-images / dag

## Volgende stap
Upload de volledige inhoud van deze map naar `ShaWiel/SCHOLARK` op GitHub. Daarna kan ChatGPT de repository rechtstreeks verder onderhouden.
