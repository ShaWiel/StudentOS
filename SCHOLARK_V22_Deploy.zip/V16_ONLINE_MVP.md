# SCHOLARK — V16 Online MVP

## Wat V16 toevoegt
- één Node-service serveert frontend én API
- runtime public config via `/api/public-config`
- uitgebreide `/api/health`
- Helmet, compression, API rate limiting en request IDs
- server-side OpenAI only
- OpenAI moderation voor AI-input
- privacy-preserving `safety_identifier`
- gratis dagquota: 100 tekst-AI en 8 images per ingelogde gebruiker via Supabase RPC
- gastlimieten via server rate limiter
- cloudprojecten: pull/merge/upsert/delete
- cloud mastery sync
- lokale offline fallback blijft bestaan
- Dockerfile + root package.json
- systeemstatus in Profiel

## Start lokaal
1. `cp backend/.env.example backend/.env`
2. vul server secrets in
3. voer `backend/schema.sql` uit in Supabase
4. `npm install` in de root
5. `npm start`
6. open `http://localhost:3000`

Open de site bij voorkeur niet meer via `file://index.html` wanneer je accounts, cloud en live AI test.
