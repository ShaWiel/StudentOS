# SCHOLARK live zetten

## A. Eerst lokaal testen

In de hoofdmap:

```bash
npm install
npm run check
npm run prod-check
npm start
```

Open daarna:

```text
http://localhost:3000
```

Gebruik voor live AI/cloud dus niet alleen `file://index.html`.

## B. Supabase

1. Maak een nieuw Supabase-project.
2. Open de SQL Editor.
3. Open lokaal `backend/schema.sql`.
4. Kopieer de volledige inhoud.
5. Run de SQL.
6. Kopieer daarna:
   - Project URL
   - Publishable key

Deze twee mogen als publieke webconfiguratie worden gebruikt omdat de database met RLS is afgeschermd.

Gebruik NOOIT de Supabase `service_role` key in `config.js`, `app.js` of andere browsercode.

## C. OpenAI

Maak een OpenAI API-key en gebruik die uitsluitend als server-secret:

```text
OPENAI_API_KEY=...
```

Niet in de browser plaatsen.

## D. GitHub

Maak één repository met de volledige inhoud van deze V17-map.

Belangrijke rootbestanden:

```text
package.json
Dockerfile
render.yaml
railway.json
index.html
app.js
styles.css
backend/
```

## E. Render — aanbevolen test/MVP-route

Je kunt `render.yaml` gebruiken als Blueprint of handmatig een Node Web Service maken.

Stel deze environment variables in:

```text
NODE_ENV=production
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6
OPENAI_IMAGE_MODEL=gpt-image-2
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=...
ALLOWED_ORIGINS=https://JOUW-STUDENTOS-DOMAIN
GUEST_DAILY_AI_LIMIT=25
GUEST_DAILY_IMAGE_LIMIT=5
```

Build:

```text
npm install
```

Start:

```text
npm start
```

Health check:

```text
/api/health
```

## F. Na deployment testen

Controleer minimaal:

1. Homepage opent.
2. Account aanmaken.
3. Uitloggen/inloggen.
4. Profiel blijft bestaan.
5. Project maken.
6. Browser vernieuwen.
7. Project komt terug.
8. Mastery-oefening doen.
9. Opnieuw inloggen en mastery controleren.
10. AI Tutor testen.
11. Research testen.
12. Presentatie genereren.
13. Posterafbeelding genereren.
14. Mobiele browser testen.
15. `/api/health` controleren.

## G. Gratis limieten

Ingelogd:
- 100 tekstcalls/dag
- 8 images/dag

Gast:
- 25 tekstcalls/dag
- 5 images/dag

Voor echte publieke schaal is het verstandig later limieten dynamisch te maken op basis van kosten en misbruik.
