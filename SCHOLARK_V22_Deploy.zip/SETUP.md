# SCHOLARK V7.1 — Setup

## Wat V7.1 toevoegt

- Supabase e-mail/wachtwoord accounts
- Cloud sync voor profiel, taken, doelen, activiteit en geleerde onderwerpen
- Offline-first localStorage fallback
- Server-side OpenAI Tutor via de Responses API
- RLS-beveiliging zodat ingelogde gebruikers alleen hun eigen data kunnen lezen/schrijven
- Auth-token wordt optioneel door de backend gevalideerd
- Live AI valt automatisch terug op lokale demokennis als de backend niet bereikbaar is

---

## 1. Supabase project

Maak een Supabase-project.

Voer daarna `backend/schema.sql` uit in de SQL Editor.

In Supabase vind je:
- Project URL
- Publishable key (of anon key, afhankelijk van je projectinstellingen)

Vul die in `config.js` in:

```js
window.STUDENTOS_CONFIG = {
  SUPABASE_URL: "https://JOUWPROJECT.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "JOUW_PUBLISHABLE_KEY",
  API_BASE_URL: "http://localhost:3000"
};
```

### BELANGRIJK
De browser mag de publishable/anon key gebruiken in combinatie met RLS.
Zet NOOIT de `service_role` key in `config.js`.

---

## 2. Backend installeren

Open een terminal in de map `backend`.

Kopieer:

`.env.example` → `.env`

Vul in:

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=...
```

Installeer packages:

```bash
npm install
```

Start:

```bash
npm start
```

Controle:

`http://localhost:3000/api/health`

---

## 3. Frontend openen

Omdat cloud-auth en fetch betrouwbaarder werken via HTTP, gebruik bij voorkeur een lokale webserver in plaats van alleen dubbelklikken op `index.html`.

Bijvoorbeeld VS Code Live Server.

Standaard verwacht `config.js`:

`API_BASE_URL: "http://localhost:3000"`

---

## 4. Accountflow testen

1. Open SCHOLARK.
2. Klik **Inloggen**.
3. Kies **Account maken**.
4. Registreer e-mail + wachtwoord.
5. Afhankelijk van Supabase Auth-instellingen moet de gebruiker de e-mail eerst bevestigen.
6. Log in.
7. Voeg taken/doelen toe.
8. Herlaad de pagina: de clouddata hoort terug te komen.

---

## 5. AI Tutor testen

1. Start de backend met een geldige `OPENAI_API_KEY`.
2. Open SCHOLARK → AI Tutor.
3. Vraag bijvoorbeeld:
   - `Leg fotosynthese uit alsof ik 10 ben.`
   - `Ik snap inflatie niet. Geef een voorbeeld uit het dagelijks leven.`
   - `Help me de stelling van Pythagoras stap voor stap begrijpen.`
4. Als de backend niet bereikbaar is, gebruikt V7.1 automatisch de lokale V7-demokennis.

---

## Productiepunten vóór echte lancering

- Juridische/privacy-review voor accounts van minderjarigen.
- Ouder-/voogdconsent waar dit wettelijk vereist is.
- Privacybeleid en gegevensretentiebeleid.
- Rate limiting op `/api/tutor`.
- Abuse monitoring en kostenlimieten.
- HTTPS.
- Striktere CORS-origins.
- Database back-ups.
- Geen persoonsgegevens in logs.
- Echte schools/curriculum-data alleen uit beheerde, actuele bronnen.
- Monitoring van AI-outputkwaliteit per leeftijdsgroep.


---

# V8 Studio AI testen

Dezelfde backend levert nu extra routes:

- `POST /api/studio/chat`
- `POST /api/studio/research`
- `POST /api/studio/report`
- `POST /api/studio/rewrite`
- `POST /api/studio/presentation`
- `POST /api/studio/poster`

Voor posters:
```env
OPENAI_IMAGE_MODEL=gpt-image-2
```

De frontend laadt:
- PptxGenJS voor `.pptx` export
- html2canvas voor poster `.png` export

Voor productie:
- pin CDN-versies of bundle dependencies lokaal
- implementeer rate limiting
- implementeer daily usage/quota per account
- beperk CORS tot je echte domein
- monitor AI/image kosten


---

# V9 Design Assist route

Nieuwe backendroute:

`POST /api/studio/design-edit`

Deze route verbetert slidecopy of posterconcepten op basis van een natuurlijke opdracht,
bijvoorbeeld:

- `Maak deze slide korter en krachtiger`
- `Maak deze poster chiquer en minder druk`
- `Maak de titel overtuigender`

De browser-editor zelf werkt ook zonder deze AI-route; alleen de AI Design Assist gebruikt de backend.


---

# V16 — aanbevolen start

V16 kan frontend en API vanaf één Node-service draaien.

```bash
npm install
cp backend/.env.example backend/.env
npm start
```

Open daarna `http://localhost:3000`. Voer eerst de nieuwste `backend/schema.sql` uit in Supabase. Plak nooit je OpenAI-key of een Supabase service-role key in `config.js`.
