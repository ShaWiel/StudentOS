# SCHOLARK V22 — Multilingual Rebrand

SCHOLARK is the new public brand for the former StudentOS project.

## Brand
- Name: SCHOLARK
- Logo: approved SCHOLARK S + graduation cap PNG
- Purple: #6d5dfc
- Lime: #c9ff6a
- Dark: #17191f

## Languages
- Nederlands (nl)
- English (en)
- Español (es)
- Português (pt)
- Français (fr)

The selected language is remembered locally and AI Tutor / Research / Studio prompts follow the selected language.

## Compatibility
Technical storage keys and database identifiers that would break existing user data are intentionally preserved. Public branding and runtime config use SCHOLARK.
