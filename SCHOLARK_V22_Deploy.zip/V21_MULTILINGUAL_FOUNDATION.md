# SCHOLARK — V21 Multilingual Beta

V21 rebrands the public product from SCHOLARK to **SCHOLARK** while keeping existing lowercase technical storage/database identifiers for backward compatibility.

## Languages
- Nederlands (default)
- English
- Español

The language selector persists locally. Core navigation, onboarding, pricing, account flows and major learning/studio controls are localized. Live Tutor and Studio AI receive the selected language and answer in that language by default. Missing deep-interface translations safely fall back to Dutch and can be expanded through `i18n.js`.

## Brand
**SCHOLARK — Your Learning OS.**

Plans:
- SCHOLARK Free — $0
- SCHOLARK Plus — $9.99/month
- SCHOLARK Pro — $14.99/month
