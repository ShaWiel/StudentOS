# SCHOLARK — V22 Multilingual Rebrand

V22 rebrands the user-facing product to **SCHOLARK** while preserving legacy technical storage/database identifiers for compatibility.

## Languages
- Nederlands
- English
- Español
- Português
- Français

The selected language is remembered locally and is also passed to Tutor, Research, reports, presentations and Studio AI so generated content follows the user's language.

## Compatibility
Legacy `studentos_*` storage keys, database fields and some internal DOM IDs remain intentionally unchanged so existing accounts, projects and progress continue to work.
