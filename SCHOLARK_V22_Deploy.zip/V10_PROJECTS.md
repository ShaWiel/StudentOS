# SCHOLARK — V10 Projects & Advanced Editors

V10 maakt Studio AI project-gebaseerd.

## Mijn Projecten
- Presentatieprojecten
- Posterprojecten
- Verslagprojecten
- zoeken
- filteren
- sorteren
- openen
- dupliceren
- verwijderen
- projectnaam wijzigen
- lokale autosave

## Undo / Redo
Een eenvoudige editor history-stack is toegevoegd.

## Presentation Editor
Naast V9:
- extra tekstblokken
- vormen
- eigen afbeeldingen
- eenvoudige tabellen
- eenvoudige grafieken
- element opacity
- element fill
- element verwijderen
- templates
- thema's
- undo/redo
- autosave als project

## Poster Editor
Naast V9:
- meerdere pagina's per posterproject
- pagina toevoegen
- dupliceren
- verwijderen
- project autosave
- poster templates

## Database
`backend/schema.sql` bevat nu ook een `projects` tabel met RLS.

## Productieready vervolgstappen
- Projectsync daadwerkelijk op Supabase aansluiten
- Resize handles voor canvas-elementen
- Crop/rotate
- Snapping/alignment guides
- Undo/redo voor iedere property wijziging
- Real charts uit data
- Rich-text editing
- Slide speaker notes
- Master themes
- Template marketplace
- Collaboration/comments
- Version history
- Share links
- PDF export
