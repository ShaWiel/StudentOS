import fs from "node:fs";
const files=["index.html","styles.css","app.js","education.js","education-data.js","backend/server.mjs","backend/schema.sql","package.json","Dockerfile","privacy.html","terms.html","safety.html","refunds.html"];
let fail=false;
for(const f of files){const ok=fs.existsSync(f);console.log(`${ok?"✓":"✗"} ${f}`);if(!ok)fail=true;}
for(const k of ["OPENAI_API_KEY","SUPABASE_URL","SUPABASE_PUBLISHABLE_KEY","SUPABASE_SERVICE_ROLE_KEY","PADDLE_API_KEY","PADDLE_CLIENT_TOKEN","PADDLE_WEBHOOK_SECRET","PADDLE_PLUS_PRICE_ID","PADDLE_PRO_PRICE_ID"]){console.log(`${process.env[k]?"✓":"○"} ENV ${k}`);}
if(fail)process.exit(1);
