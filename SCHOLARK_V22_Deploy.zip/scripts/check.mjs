import fs from "node:fs";
const must=["index.html","styles.css","app.js","education.js","education-data.js","backend/server.mjs","backend/schema.sql","privacy.html","terms.html","safety.html","refunds.html","V20_RELEASE_CANDIDATE.md"];
let failed=false;
for(const f of must){if(!fs.existsSync(f)){console.error("MISS",f);failed=true;}else console.log("OK  ",f);}
const html=fs.readFileSync("index.html","utf8");
for(const id of ["profileForm","authModal","view-dashboard","view-education","view-studio","view-projects"]){if(!html.includes(`id="${id}"`)){console.error("MISSING ID",id);failed=true;}}
if(failed)process.exit(1);
console.log("SCHOLARK V22 Multilingual Beta structure check passed.");
